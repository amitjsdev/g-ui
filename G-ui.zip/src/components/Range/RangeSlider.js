import React, { useState } from "react";
import Slider from "react-rangeslider";
import "react-rangeslider/lib/index.css";
import "./Range.scss";

const RangeSlider = () => {
  const [rvalue, setRvalue] = useState(0);

  const handleChange = (value) => {
    setRvalue(0);
  };
  const handleChangeComplete = (e) => {
    // console.log('handleChangeComplete',rvalue)
  };

  const horizontalLabels = {
    0: "",
    100: "|",
    200: "|",
    300: "|",
    400: "|",
    500: "|",
    600: "|",
    700: "|",
    800: "|",
    900: "|",
    1000: "",
  };

  return (
    <Slider
      min={0}
      max={1000}
      step={100}
      tooltip={false}
      value={rvalue}
      labels={horizontalLabels}
      // format={formatkg}
      // handleLabel={rvalue}
      onChange={handleChange}
      onChangeComplete={handleChangeComplete}
    />
  );
};

export default RangeSlider;
