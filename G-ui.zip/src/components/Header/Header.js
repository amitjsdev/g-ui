import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import "./Header.scss";
import togg from "../../assets/images/togg.svg";
import wallet_black from "../../assets/images/wallet_black.svg";
import exit from "../../assets/images/exit.png";
import { Dropdown } from "react-bootstrap";
import {
  getUserBalance,
  savePlayer,
  setCountDownEnable,
} from "../../redux/user/action";
import socket from "../../socket";
import { toast } from "react-toastify";
import { MARKET_PLACE_URL } from "../../utils/constant";

function Header() {
  const dispatch = useDispatch();
  const splitLocation = window.location.pathname.split("/");
  const countdown = useSelector((state) => state?.userReducer?.startCountDown);
  const matchedData = useSelector((state) => state?.userReducer?.matchedData);
  const enableDoneBtn = useSelector(
    (state) => state?.userReducer?.enableDoneBtn
  );

  const countDownEnable = useSelector(
    (state) => state?.userReducer?.countDownEnable
  );
  // const [countDown, setCountDown] = useState(30);
  const getBalance = useSelector((state) => state?.userReducer?.userBalance);

  useEffect(() => {
    window.history.pushState(null, null, window.location.href);
    window.onpopstate = function (event) {
      window.location.replace("/");
      window.history.go(1);
    };

    getUsersBalance();
  }, []);

  const getUsersBalance = () => {
    let param = {
      // member_id: "8ae1609f-3410-4a3e-bc9e-3d3b8c4b57ac",
    };
    dispatch(getUserBalance(param));
  };

  const sendNotification = () => {
    if (Object.keys(enableDoneBtn).length > 0) {
      dispatch(savePlayer(true));
    } else {
      // dispatch(savePlayer(false));
    }
  };

  // window.onbeforeunload = function () {
  //   return "Your work will be lost.";
  // };

  const leaveGame = () => {
    window.location.replace("/");
  };

  let minutes = 0;
  let seconds = 0;
  if (countdown > 60) {
    minutes = parseInt(countdown / 60);
    let secondsVal = countdown % 60;
    if (secondsVal < 10) {
      seconds = 0 + "" + secondsVal;
    } else {
      seconds = secondsVal;
    }
  } else {
    minutes = 0;
    seconds = countdown;
  }
  return (
    <div className="MobileHeader">
      <div className="sideNav">
        <Dropdown>
          <Dropdown.Toggle id="dropdown-basic">
            <img src={togg} alt="togg" className="togg" />
          </Dropdown.Toggle>
          <Dropdown.Menu>
            <Dropdown.Item key={1} href="/">
              Home
            </Dropdown.Item>
            {/* <Dropdown.Item key={2} href="/">
              Play
            </Dropdown.Item> */}
            <Dropdown.Item key={3} target="_blank" href={MARKET_PLACE_URL}>
              Marketplace
            </Dropdown.Item>
            <Dropdown.Item
              key={3}
              // target="_blank"
              href="/artefacts"
            >
              Boosters
            </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </div>
      {countDownEnable && (
        <>
          {splitLocation[1] == "ground" && (
            <div className={`TimerStart ${countdown < 6 ? "lstFvMnt" : ""}`}>
              <h2>00:{countdown}</h2>
            </div>
          )}
          {splitLocation[1] == "build-team" && (
            <div className={`TimerStart ${countdown < 6 ? "lstFvMnt" : ""}`}>
              <h2>
                0{minutes}:{seconds}
              </h2>
            </div>
          )}
        </>
      )}
      <div className="WalletDetails">
        {splitLocation[1] !== "ground" ? (
          <>
            <img
              src={wallet_black}
              alt="wallet_black"
              className="wallet_black"
            />
            <div className="amount">
              <h6>{getBalance?.balance} RUNS</h6>
              {/* <p>₹2365.33</p> */}
            </div>
          </>
        ) : (
          <>
            <botton
              disabled={Object.keys(enableDoneBtn).length == 0}
              onClick={sendNotification}
              className={`GameDone ${
                Object.keys(enableDoneBtn).length == 0 ? "disabled" : ""
              }`}
            >
              {" "}
              Done
            </botton>
            <botton onClick={leaveGame} className="GameExit">
              <img title="Exit Game" src={exit} alt="exit" className="exit" />
            </botton>
          </>
        )}
      </div>
    </div>
  );
}

export default Header;
