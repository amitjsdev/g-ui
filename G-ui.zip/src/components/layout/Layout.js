import React, { useEffect, useState } from "react";
import { Container } from "react-bootstrap";
import { Provider } from "react-redux";
import { store, persistor } from "../../redux/store/store";
import { BrowserRouter } from "react-router-dom";
import { Routers } from "../../Routers";
import Header from "../Header/Header";
import "./Layout.scss";
import { PersistGate } from "redux-persist/lib/integration/react";
import LoaderComponent from "../LoaderComponent";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { setToken } from "../../Helpers/storageHelper";
import {
  removeToken,
  setLocalStorage,
  getToken,
} from "../../Helpers/storageHelper";
import socket from "../../socket";

import { ACCESS_TOKEN } from "../../utils/constant";
import { MARKET_PLACE_URL } from "../../utils/constant";
socket.connect();

function Layout(props) {
  const [isAuthenticated, setIsAuthrnticated] = useState(false);
  const [reload, setReload] = useState(false);

  function preventBack() {
    window.history.forward();
  }
  setTimeout(preventBack(), 0);

  useEffect(() => {
    var url_string = window.location.href;
    var url = new URL(url_string);
    var hash = url.searchParams.get("hash");

    if (!!hash) {
      window.history.pushState("page2", "Title", "/");
      setToken(hash);
      setIsAuthrnticated(true);
      setReload(true);
    } else {
      if (getToken(ACCESS_TOKEN)) {
        setIsAuthrnticated(true);
      } else {
        setIsAuthrnticated(false);
        window.location.replace(MARKET_PLACE_URL);
      }
    }
  }, [isAuthenticated]);

  useEffect(() => {
    if (reload) {
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    }
  }, [reload]);

  return (
    <Provider store={store}>
      {/* <PersistGate loading={null} persistor={persistor}> */}
      <Container fluid>
        <ToastContainer />
        {isAuthenticated && (
          <div className="MainWrap">
            <BrowserRouter>
              <Header />
              <LoaderComponent />
              {!reload && (
                <div className="Containdata">
                  <Routers />
                </div>
              )}
            </BrowserRouter>
          </div>
        )}
      </Container>
      {/* </PersistGate> */}
    </Provider>
  );
}

export default Layout;
