import React, { Component } from 'react';
import ImagePicker from 'react-image-picker';
import 'react-image-picker/dist/index.css';
import "./ImagePick.scss";
//import images from local
import KL_Rahul from "../../assets/images/KL_Rahul.png";
import FafDu_Plessis from "../../assets/images/FafDu_Plessis.png";
import Kane_Williamso from "../../assets/images/Kane_Williamso.png";

const imageList = [KL_Rahul, FafDu_Plessis, Kane_Williamso, KL_Rahul, FafDu_Plessis, Kane_Williamso,]

class App extends Component {
    constructor(props) {
        super(props)
        this.state = {
            image: null
        }
        this.onPick = this.onPick.bind(this)
    }

    onPick(image) {
        this.setState({ image })
    }

    render() {
        return (
            <div>
                <ImagePicker
                    images={imageList.map((image, i) => ({ src: image, value: i }))}
                    onPick={this.onPick}
                />

            </div>
        )
    }
}

export default App