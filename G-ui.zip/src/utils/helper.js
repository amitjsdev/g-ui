export const getAccessToken = () => {
    if (typeof window !== 'undefined') {
      const accessToken = localStorage.getItem('at');
      return JSON.parse(accessToken);
    }
    return null;
  };