export const ENV_VAR = process.env.ENV_VAR;
export const ENCRYPT_KEY = process.env.REACT_APP_ENCRYPT_KEY;
export const DECRYPT_KEY = process.env.REACT_APP_DECRYPT_KEY;

export const API_HOST = process.env.REACT_APP_API_URL;
export const ACCESS_TOKEN = "token";

export const SOCKET_URL = process.env.REACT_APP_SOCKET_URL;

export const MARKET_PLACE_URL = process.env.REACT_APP_MARKET_PLACE_URL;
export const SOCKET_PATH = process.env.REACT_APP_SOCKET_PATH;

// export const DECRYPT_KEY = process.env.REACT_APP_DECRYPT_KEY

export const STATUS_CODE = {
  successful: 200,
  badRequest: 400,
  unAuthorized: 401,
  forbidden: 403,
  notFound: 404,
};
