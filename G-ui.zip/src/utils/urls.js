const API_URL = process.env.REACT_APP_API_URL;

const URLS = {
  // USER API's
  USER: {
    REGISTER: `${API_URL}users/user/login`,
    LOGIN: `${API_URL}users/user/register`,
    LOGOUT: `${API_URL}/user/logout`,
    NFT_LIST: `${API_URL}nft_list`,
    NFT_USER: `${API_URL}nft_user`,
    SAVE_PLAYER: `${API_URL}savePlayers`,
    COINS: `${API_URL}coins`,
    BALANCE: `${API_URL}balance`,
    COINS: `${API_URL}update_balance`,
    GET_COUNTRY: `${API_URL}getCountries`,
    GET_PLAYER_HISTORY: `${API_URL}getPlayersHistory`,
    GET_ARTEFACTS: `${API_URL}getArtefacts`,
    SAVE_ARTIFACTS: `${API_URL}saveArtefacts`,
    GET_USER_ARTEFACTS: `${API_URL}getUserArtefacts`,
    USER_DEDUCT_ARTIFACT: `${API_URL}deductArtefactQuantity`,
    SEARCHED_PLAYER_NFT:  `${API_URL}nft_list`,

    

  },
};

export default URLS;
