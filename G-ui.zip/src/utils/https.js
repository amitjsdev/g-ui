import axios from 'axios';
import {removeToken,setLocalStorage,getToken} from '../Helpers/storageHelper';

import {ACCESS_TOKEN} from "./constant";

/** Format URL */
const formatUrl = (url, params) => {
  const param =
    params && Object.keys(params)?.length > 0 ? `?${new URLSearchParams(params).toString()}` : '';
  return `${url}${param}`;
};

const instance = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
  withCredentials: true,
  headers: {
    'content-type': 'application/json',
    'access-token':  getToken(ACCESS_TOKEN),
    'Access-Control-Allow-Origin': '*',

  },
});

function setMehod(method, path, body, options, params) {
  let config = {};
  if (options) {
    if (options) {
      config.headers = {
        'content-type': 'application/json',
        'access-token': options,
        'Access-Control-Allow-Origin': '*',
      };
    }
  }
  
  params = params ? '?' + new URLSearchParams(params).toString() : '';
  if (method === 'get' || method === 'delete') {
    return axios[method](`${path}${params}`, config);
  }
  if (method === 'post' || method === 'put') {
    return axios[method](`${path}`, body, config);
  }
}


/** POST Request */
export const httpPost = (url, header, data, params = {}) =>
  new Promise((resolve) => {
    setMehod('post',url,data,header,params)
      .then((res) => {
        resolve(res);
      })
      .catch((error) => {
        resolve(error.response);
      });
  });

/** GET Request */
export const httpGet = async (url, header, data, params = {}) =>
  new Promise((resolve) => {
    setMehod('get',url,'',header,params)
      .then((res) => {
        resolve(res);
      })
      .catch((error) => {
        resolve(error.response);
      });
  });

/** PUT Request */
// export const httpPut = (url, data, params = {}) =>
//   new Promise((resolve) => {
//     instance
//       .get(formatUrl(url, params))
//       .then((res) => {
//         resolve(res?.data);
//       })
//       .catch((error) => {
//         resolve(error.response);
//       });
//   });

export const httpPut = (url, header, data, params = {}) =>
  new Promise((resolve) => {
    instance
      .put(formatUrl(url, params), data, {})
      .then((res) => {
        resolve(res);
      })
      .catch((error) => {
        resolve(error.response);
      });
  });

/** PATCH Request */
export const httpPatch = (url, data, params = {}) =>
  new Promise((resolve, reject) => {
    instance
      .patch(formatUrl(url, params), data)
      .then((res) => {
        resolve(res?.data);
      })
      .catch((error) => {
        reject(error.response);
      });
  });

/** DELETE Request */
export const httpDelete = (url, header, data, params = {}) =>
  new Promise((resolve, reject) => {
    instance
      .delete(formatUrl(url, params), {
        data,
      })
      .then((res) => {
        resolve(res?.data);
      })
      .catch((error) => {
        reject(error.response);
      });
  });
