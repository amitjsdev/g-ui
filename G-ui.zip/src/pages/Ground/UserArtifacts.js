import React, { useState, useEffect } from "react";
import Slider from "react-slick";
import drop from "../../assets/images/drop.svg";
import { useDispatch, useSelector } from "react-redux";
// import battt from "../../assets/images/battt.png";

const UserArtifacts = React.memo(
  ({
    selectedArtifacts,
    userArtifacts,
    playerASocketId,
    playerBSocketId,
    socket,
    showArtEffectHandler,
    inning,
    artifactList,
    boosterDisable,
  }) => {
    const [bottomHeight, setBottomHeight] = useState(false);

    const dispatch = useDispatch();

    const BottomBarHandler = () => {
      setBottomHeight(!bottomHeight);
    };

    var settings = {
      dots: true,
      infinite: false,
      speed: 500,
      slidesToShow: 5,
      slidesToScroll: 1,
      responsive: [
        {
          breakpoint: 680,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 350,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
          },
        },
      ],
    };
    return (
      <div className={`filings ${bottomHeight ? "setHeight" : ""}`}>
        <div onClick={() => BottomBarHandler()} className="arrowHeader">
          <img src={drop} alt="ballfire" className="Bat" />
        </div>
        <Slider {...settings}>
          {
            artifactList && artifactList.length > 0
              ? artifactList.map((item, index) => {
                  let usedArtifact =
                    selectedArtifacts &&
                    selectedArtifacts.length > 0 &&
                    selectedArtifacts.find((id) => id == item.ds_id);
                  let alreadyPlayed = usedArtifact
                    ? "alreadyPlayed"
                    : boosterDisable
                    ? "alreadyPlayed"
                    : "";
                  let card_type =
                    item?.usedByBatsman == 1
                      ? "usedByBatsman"
                      : item?.usedByBowler == 1
                      ? "usedByBowler"
                      : "ALL";
                  let checkUsed;
                  if (inning == "first") {
                    checkUsed =
                      playerASocketId == socket.id && inning == "first"
                        ? "usedByBatsman"
                        : "usedByBowler";
                  } else if (inning == "second") {
                    checkUsed =
                      playerBSocketId == socket.id && inning == "second"
                        ? "usedByBatsman"
                        : "usedByBowler";
                  }

                  if (card_type == checkUsed) {
                    return (
                      <li key={index} className={alreadyPlayed}>
                        <div
                          onClick={() =>
                            showArtEffectHandler(item.ds_id, card_type)
                          }
                          className="ballfire"
                        >
                          <img
                            src={item.image}
                            alt="ballfire"
                            className="bat"
                          />
                          {/* <p>{item.quantity}</p> */}
                          <h5>{item.title}</h5>
                          {/* <h6>Name:{item.title}</h6> */}
                        </div>
                      </li>
                    );
                  }
                  if (card_type == checkUsed) {
                    return (
                      <li key={index} className={alreadyPlayed}>
                        <div
                          onClick={() =>
                            showArtEffectHandler(item?.ds_id, card_type)
                          }
                          className="ballfire"
                        >
                          <img
                            src={item.image}
                            alt="ballfire"
                            className="edit"
                          />
                          {/* <p>{item.quantity}</p> */}
                          <h5>{item.title}</h5>
                          {/* <h6>Name:{item.title}</h6> */}
                        </div>
                      </li>
                    );
                  }
                })
              : ""
            // <p>Artefact not found!</p>
          }
        </Slider>
      </div>
    );
  },
  (prevProps, nextProps) => {
    // const A = JSON.stringify(prevProps);
    // const B = JSON.stringify(nextProps);
    // return (
    //   A === B
    //   // prevProps?.roundResult?.length === nextProps?.roundResult?.length &&
    //   // prevProps.selectedCard === nextProps.selectedCard
    // );
  }
);

export default UserArtifacts;
