import React, { useState, useEffect } from "react";
import Slider from "react-slick";
import ball from "../../assets/images/ball.svg";
import Bat from "../../assets/images/Bat.svg";

const FirstInningScores = React.memo(
  ({ roomData, playerASocketId, socket, opponent }) => {
    let playedBalls = roomData?.totalBallsPlayedByPlayerA;
    if (playedBalls > 60) {
      playedBalls = 60;
    }
    let overs = parseInt(playedBalls / 6) + "." + (playedBalls % 6);

    return (
      <>
        {opponent ? (
          <>
            <div className="opponent">
              {roomData?.RoundsInfo?.Inning1?.status == "PROGRESS" ? (
                playerASocketId != socket.id ? (
                  <img src={Bat} alt="Bat" className="Bat" />
                ) : (
                  <img src={ball} alt="ball" className="ball" />
                )
              ) : playerASocketId != socket.id ? (
                <img src={ball} alt="ball" className="ball" />
              ) : (
                <img src={Bat} alt="Bat" className="Bat" />
              )}

              <h6>
                {playerASocketId != socket.id
                  ? roomData?.playerAName?.name
                    ? roomData?.playerAName?.name
                    : "Opponent"
                  : roomData?.playerBName?.name
                  ? roomData?.playerBName?.name
                  : "Opponent"}
              </h6>
            </div>
            <div className="score">
              <p>
                Score{" "}
                <span>
                  {playerASocketId != socket.id
                    ? `${roomData?.totalScoreByPlayerA}/${
                        roomData?.totalWicketsPlayerA
                      } (${!!overs ? overs : 0})`
                    : "Yet To Bat"}
                </span>
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="your">
              {roomData?.RoundsInfo?.Inning1?.status == "PROGRESS" ? (
                playerASocketId == socket.id ? (
                  <img src={Bat} alt="Bat" className="Bat" />
                ) : (
                  <img src={ball} alt="ball" className="ball" />
                )
              ) : playerASocketId == socket.id ? (
                <img src={ball} alt="ball" className="ball" />
              ) : (
                <img src={Bat} alt="Bat" className="Bat" />
              )}

              <h6>
                {playerASocketId == socket.id
                  ? roomData?.playerAName?.name
                    ? roomData?.playerAName?.name
                    : "You"
                  : roomData?.playerBName?.name
                  ? roomData?.playerBName?.name
                  : "You"}
              </h6>
            </div>
            <div className="score">
              <p>
                Score{" "}
                <span>
                  {playerASocketId == socket.id
                    ? `${roomData?.totalScoreByPlayerA}/${
                        roomData?.totalWicketsPlayerA
                      } (${!!overs ? overs : 0})`
                    : `Yet To Bat`}
                </span>
              </p>
            </div>
          </>
        )}
      </>
    );
  },
  (prevProps, nextProps) => {
    // const A = JSON.stringify(prevProps);
    // const B = JSON.stringify(nextProps);
    // return (
    //   A === B
    //   // prevProps?.roundResult?.length === nextProps?.roundResult?.length &&
    //   // prevProps.selectedCard === nextProps.selectedCard
    // );
  }
);

export default FirstInningScores;
