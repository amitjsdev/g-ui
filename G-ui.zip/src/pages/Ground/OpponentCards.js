import React, { useState, useEffect } from "react";
import Slider from "react-slick";

const OpponentCard = React.memo(
  ({ playerMatchedData }) => {
    var settings = {
      dots: true,
      infinite: false,
      speed: 500,
      slidesToShow: 5,
      slidesToScroll: 1,
      responsive: [
        {
          breakpoint: 680,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 350,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
          },
        },
      ],
    };
    return (
      <div className="opponentCard">
        <Slider {...settings}>
          {playerMatchedData?.map((item, index) => {
            return (
              <div key={index} className="cards">
                <img src={item?.nftLogo} alt="Virat" className="Virat" />
              </div>
            );
          })}
        </Slider>
      </div>
    );
  },
  (prevProps, nextProps) => {
    const A = JSON.stringify(prevProps);
    const B = JSON.stringify(nextProps);
    return (
      A === B
      // prevProps?.roundResult?.length === nextProps?.roundResult?.length &&
      // prevProps.selectedCard === nextProps.selectedCard
    );
  }
);

export default OpponentCard;
