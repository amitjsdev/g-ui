import React, { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import "./Ground.scss";
import pitch from "../../assets/images/pitch.png";
import { useNavigate } from "react-router-dom";
import {
  startCountDown,
  enableDoneBtn,
  setCountDownEnable,
  getUserArtifacts,
  deductArtifact,
  savePlayer,
  setBowlerRecords,
  setBatBosterInningSecond,
  setBowlBosterInningSecond,
} from "../../redux/user/action";
import { useDispatch, useSelector } from "react-redux";
import socket from "../../socket";

import WaitingModal from "../../modals/WaitingModal";
import UserArtifacts from "./UserArtifacts";
import SecondInningScores from "./SecondInningScores";
import OpponentCard from "./OpponentCards";
import OpponentPlayer from "./OpponentPlayer";
import YourPlayer from "./YourPlayer";
import YourCards from "./YourCards";
import PlayerTurnModal from "../../modals/PlayerTurnModal";
import ScoreBoredModal from "../../modals/ScoreBoredModal";
import InningsChangeModal from "../../modals/InningChangeModal";
import { batBoosterFirstInning } from "../../redux/user/types";
import Matchsummary from "../YouWon/MatchSummary/Matchsummary";

let timerCount = 10;
let scoreStatus = 1;
function InningSecond(props) {
  const { playerMatchedData, artifactList } = props;
  let roomData = playerMatchedData?.roomData;
  let roundInfo = roomData?.RoundsInfo;

  if (!playerMatchedData) {
    navigate("/");
  }
  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [showStartGame, setShowStartGame] = useState(false);
  const [yourPlayer, setYourPlayer] = useState(false);
  const [showArtifact, setShowArtifact] = useState(false);
  const [selectedArtifacts, setSelectedArtifacts] = useState([]);
  const [battingPlayer, setBattingPlayer] = useState({});
  const [bowlingPlayer, setBowlingPlayer] = useState({});
  const [inningRound, setInningRound] = useState("round_1");
  // const [roundInfo, setRoundInfo] = useState({});
  const [timerclose, setTimerClose] = useState(true);
  const [bowlingMessage, setBowlingMessage] = useState("You're Bowling");
  const [battingMessage, setBattingMessage] = useState("You're Batting");
  const [WaitModalForScore, setWaitModalForScore] = useState(false);
  const [scoreShow, setScoreShow] = useState(false);
  const [currentRound, setCurrentRound] = useState({});
  const [checkInningRound, setCheckInningRound] = useState("PENDING");
  const [botSocket, setBotSocket] = useState(false);
  const randomTime = Math.floor(Math.random() * 5) + 1;
  const [counterRun, setCounterRun] = useState(false);

  const [changeBat, setChangeBat] = useState(false);
  const [boosterDisable, setBoosterDisable] = useState(false);
  const changeBatRef = useRef(changeBat);
  changeBatRef.current = changeBat;

  let playerASocketId = roomData?.playerASocketId;

  let playerBSocketId = roomData?.playerBSocketId;

  let socketPlayerList =
    playerBSocketId == socket.id ? playerBSocketId : playerASocketId;
  let opponetSocket =
    playerBSocketId == socket.id ? playerASocketId : playerBSocketId;

  let playerData =
    !!playerMatchedData &&
    !!playerMatchedData?.playerIds &&
    !!playerMatchedData?.playerIds[socketPlayerList] &&
    playerMatchedData?.playerIds[socketPlayerList].length > 0
      ? playerMatchedData?.playerIds[socketPlayerList]
      : [];

  const savePlayerInfo = useSelector(
    (state) => state?.userReducer?.informBowlingTeam
  );

  const bowlerRecords = useSelector(
    (state) => state?.userReducer?.bowlerRecords
  );

  const batBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.batBoosterFirstInning
  );
  const bowlBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.bowlBoosterFirstInning
  );

  const batBoosterSecondInning = useSelector(
    (state) => state?.userReducer?.batBoosterSecondInning
  );
  const bowlBoosterSecondInning = useSelector(
    (state) => state?.userReducer?.bowlBoosterSecondInning
  );

  const saveCurrentPlayer = useSelector(
    (state) => state?.userReducer?.enableDoneBtn
  );
  const [currentCount, setCount] = useState(timerCount);
  const timer = () => setCount(currentCount - 1);

  useEffect(() => {
    if (counterRun) {
      if (currentCount < 0) {
        if (Object.keys(battingPlayer).length > 0 && !savePlayerInfo) {
          // setWaitModalForScore(true);
          if (
            roomData?.RoundsInfo?.Inning2?.[roomData?.currentRound]
              ?.bowlerInfo !== null
          ) {
            setBattingMessage("");
          } else {
            setBattingMessage("Wait for opponent selection");
          }
          sendNotifyToBowlingTeam(
            "",
            { inning: "Inning2", round: inningRound },
            scoreStatus
          );
        } else if (
          playerBSocketId == socket.id &&
          !!playerMatchedData &&
          !savePlayerInfo
        ) {
          randomSelectPlayer("batsman");
        } else if (Object.keys(bowlingPlayer).length > 0 && !savePlayerInfo) {
          // setWaitModalForScore(true);
          if (
            roomData?.RoundsInfo?.Inning2[roomData?.currentRound]?.batInfo !==
            null
          ) {
            setBowlingMessage("");
          } else {
            setBowlingMessage("Wait for opponent selection");
          }
          sendNotifyToBattingTeam(
            "",
            { inning: "Inning2", round: inningRound },
            scoreStatus
          );
        } else if (playerASocketId == socket.id && !savePlayerInfo) {
          randomSelectPlayer("bowler");
        }
        // if (
        //   playerASocketId == socket.id &&
        //   !!playerMatchedData &&
        //   !savePlayerInfo
        // ) {
        //   sendNotifyToBattingTeam(
        //     1,
        //     { inning: "Inning2", round: inningRound },
        //     scoreStatus
        //   );
        // }

        return;
      } else {
        if (currentCount < 10) {
          dispatch(startCountDown(0 + "" + currentCount));
          if (
            !botSocket &&
            currentCount === 7 &&
            roomData?.isSecondPlayerBot &&
            counterRun &&
            roomData?.isBatSelected == 0
          ) {
            setBotSocket(true);
            setTimeout(() => {
              sendNotifyToBowlingTeam(
                "",
                { inning: "Inning2", round: inningRound },
                0
              );
            }, randomTime * 1000);
          } else if (currentCount == 0) {
            dispatch(enableDoneBtn({}));
          }
        } else {
          dispatch(startCountDown(currentCount));
        }
      }
      const id = setInterval(timer, 1000);
      return () => clearInterval(id);
    }
  }, [currentCount, counterRun]);

  useEffect(() => {
    if (savePlayerInfo) {
      setBoosterDisable(true);
      setCount(-1);
      dispatch(setCountDownEnable(false));
      if (playerBSocketId == socket.id) {
        // setWaitModalForScore(true);
        sendNotifyToBowlingTeam(
          saveCurrentPlayer?.playerInfoData,
          saveCurrentPlayer?.roundInfo,
          scoreStatus
        );
      }
      if (playerASocketId == socket.id) {
        // setWaitModalForScore(true);
        sendNotifyToBattingTeam(
          saveCurrentPlayer?.playerInfoData,
          saveCurrentPlayer?.roundInfo,
          scoreStatus
        );
      }
      dispatch(enableDoneBtn({}));
    }
  }, [savePlayerInfo]);

  //Now enable for  timer for second innging
  useEffect(() => {
    dispatch(getUserArtifacts());
    setTimeout(() => {
      setTimerClose(false);
      setShowStartGame(true);
    }, 3000);

    setTimeout(() => {
      setShowStartGame(false);

      if (roomData?.isSecondPlayerBot) {
        setCounterRun(true);
        dispatch(setCountDownEnable(false));
        setCount(timerCount);
      } else {
        if (playerBSocketId == socket.id) {
          setCounterRun(true);
          dispatch(setCountDownEnable(true));
          setCount(timerCount);
        } else if (playerASocketId == socket.id) {
          setCounterRun(false);
          dispatch(setCountDownEnable(false));
          // setCount(timerCount);
        }
      }
    }, 6000);
  }, [socket]);

  //send notification to  player2 (bowling team) for batsman is selected and save batsman record
  const sendNotifyToBowlingTeam = (batInfo, round, scoreVal) => {
    let batWithArt =
      Object.keys(battingPlayer).length > 0
        ? { ...battingPlayer, artifacts: selectedArtifacts }
        : {};

    let checkBot = roomData?.isSecondPlayerBot ? 1 : 0;
    let batRound = {};
    if (roomData?.isSecondPlayerBot) {
      batRound = {
        isBotResult: checkBot,
        isScore: scoreVal,
        roomId: playerMatchedData?.roomId,
        socketId: playerBSocketId,
        roundInfo:
          !!round && Object.keys(round).length > 0 ? round : currentRound,
      };
    } else {
      batRound = {
        isScore: scoreVal,
        roomId: playerMatchedData?.roomId,
        socketId: playerBSocketId,
        roundInfo:
          !!round && Object.keys(round).length > 0 ? round : currentRound,
        batInfo: Object.keys(batWithArt).length > 0 ? batWithArt : batInfo,
      };
    }
    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: batRound,
      }
    );
  };

  useEffect(() => {
    if (!playerMatchedData) {
      navigate("/");
      return;
    }
    getGroundUpdateSockte();
  }, [playerMatchedData?.roomData]);

  const getGroundUpdateSockte = () => {
    //get rounds updated data
    let inningChecked = roomData;
    let checkRound = roomData?.RoundsInfo?.Inning2?.[roomData?.currentRound];
    let roundVal = roomData?.currentRound.split("_")[1];
    let checkNextRound = "round_" + (+roundVal + +1);
    let currentRound = roomData?.currentRound;

    setCheckInningRound("PENDING");

    if (
      playerASocketId === socket.id &&
      roomData?.isBatSelected == 1 &&
      checkRound?.bowlerInfo == null &&
      checkRound?.batInfo != null
    ) {
      if (roomData?.isChanged == 1) {
        setInningRound(roomData?.currentRound);
      }
      setCount(timerCount);
      setBattingMessage("Select bowler");
      dispatch(setCountDownEnable(true));
      setCounterRun(true);
    } else if (
      (playerBSocketId == socket.id &&
        roomData?.isBatSelected == 0 &&
        roomData?.isChanged == 1 &&
        roundInfo?.Inning2[roomData?.currentRound]?.batInfo != null &&
        roundInfo?.Inning2[roomData?.currentRound]?.bowlerInfo != null) ||
      (playerASocketId == socket.id &&
        roomData?.isChanged == 1 &&
        roundInfo?.Inning2[roomData?.currentRound]?.batInfo != null)
    ) {
      setBowlingMessage("");
    } else if (
      (playerBSocketId == socket.id &&
        roomData?.isBatSelected == 1 &&
        roundInfo?.Inning2[roomData?.currentRound]?.bowlerInfo != null) ||
      (playerBSocketId == socket.id &&
        roomData?.isChanged == 1 &&
        roundInfo?.Inning2[roomData?.currentRound]?.bowlerInfo != null)
    ) {
      setBattingMessage("");
    }

    if (inningChecked?.MatchStatus == "TIMEOUT") {
      dispatch(setCountDownEnable(false));
      setCount(-1);
      navigate("/time-out");
    } else if (inningChecked?.MatchStatus == "COMPLETED") {
      if (
        (inningChecked?.WinnerId == "BOT" &&
          inningChecked?.isSecondPlayerBot &&
          checkRound?.bowlerInfo != null) ||
        (checkRound?.batInfo !== null &&
          checkRound?.bowlerInfo !== null &&
          inningChecked?.looserId == socket.id)
      ) {
        setScoreShow(true);
        setWaitModalForScore(false);

        setTimeout(() => {
          setScoreShow(true);
          dispatch(setCountDownEnable(false));
          setCount(-1);
          navigate("/you-lost");
        }, 5000);
      } else if (
        inningChecked?.winner == "TIE" &&
        checkRound?.batInfo == null &&
        checkRound?.bowlerInfo == null
      ) {
        navigate("/match-tie");
      } else if (
        (checkRound?.batInfo != null &&
          checkRound?.bowlerInfo == null &&
          inningChecked?.WinnerId == socket.id) ||
        (checkRound?.batInfo == null &&
          checkRound?.bowlerInfo != null &&
          inningChecked?.WinnerId == socket.id)
      ) {
        navigate("/you-won");
      } else if (
        (checkRound?.batInfo != null &&
          checkRound?.bowlerInfo == null &&
          inningChecked?.looserId == socket.id) ||
        (checkRound?.batInfo == null &&
          checkRound?.bowlerInfo != null &&
          inningChecked?.looserId == socket.id)
      ) {
        navigate("/you-lost");
      } else if (
        checkRound?.batInfo !== null &&
        checkRound?.bowlerInfo !== null &&
        inningChecked?.WinnerId == socket.id
      ) {
        setScoreShow(true);
        setWaitModalForScore(false);

        setTimeout(() => {
          setScoreShow(true);
          dispatch(setCountDownEnable(false));
          setCount(-1);
          navigate("/you-won");
        }, 5000);
      }
    } else {
      //complete round checks
      if (checkNextRound == "round_6" && currentRound == "round_5") {
        if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "COMPLETED"
        ) {
          setCurrentRound({ inning: "Inning2", round: "round_5" });
          setInningRound("round_5");
          setScoreShow(true);
          showScoreModal("fivethRound", inningChecked, checkRound?.roundStatus);
        } else if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "PROGRESS" &&
          roomData?.isBatSelected == 0 &&
          checkRound?.overFulfilled
        ) {
          setInningRound("round_5");
          setCurrentRound({ inning: "Inning2", round: "round_5" });
          setScoreShow(true);
          showScoreModal("forthRound", inningChecked, checkRound?.roundStatus);
        }
      } else {
        if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "COMPLETED" &&
          checkNextRound?.batInfo == null &&
          checkNextRound?.bowlerInfo == null &&
          checkRound?.overFulfilled
        ) {
          setBoosterDisable(false);
          if (currentRound == "round_1") {
            setInningRound("round_2");
            setCurrentRound({ inning: "Inning2", round: "round_2" });
            setScoreShow(true);
            showScoreModal(
              "firstRound",
              inningChecked,
              checkRound?.roundStatus
            );
          } else if (currentRound == "round_2") {
            setInningRound("round_3");
            setCurrentRound({ inning: "Inning2", round: "round_3" });
            setScoreShow(true);
            showScoreModal(
              "secondRound",
              inningChecked,
              checkRound?.roundStatus
            );
          } else if (currentRound == "round_3") {
            setInningRound("round_4");
            setCurrentRound({ inning: "Inning2", round: "round_4" });
            setScoreShow(true);
            showScoreModal(
              "thirdRound",
              inningChecked,
              checkRound?.roundStatus
            );
          } else if (currentRound == "round_4") {
            setInningRound("round_5");
            setCurrentRound({ inning: "Inning2", round: "round_5" });
            setScoreShow(true);
            showScoreModal(
              "forthRound",
              inningChecked,
              checkRound?.roundStatus
            );
          }
        } else if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "COMPLETED" &&
          checkNextRound?.batInfo == null &&
          checkNextRound?.bowlerInfo == null &&
          !checkRound?.overFulfilled
        ) {
          setInningRound("");
          setCurrentRound({});
          if (currentRound == "round_1") {
            setInningRound("round_2");
            setCurrentRound({ inning: "Inning2", round: "round_2" });
            setScoreShow(true);
            showScoreModal("firstRound", inningChecked, "PENDING", "round_2");
          } else if (currentRound == "round_2") {
            setInningRound("round_3");
            setCurrentRound({ inning: "Inning2", round: "round_3" });
            setScoreShow(true);
            showScoreModal("secondRound", inningChecked, "PENDING", "round_3");
          } else if (currentRound == "round_3") {
            setInningRound("round_4");
            setCurrentRound({ inning: "Inning2", round: "round_4" });
            setScoreShow(true);
            showScoreModal("thirdRound", inningChecked, "PENDING", "round_4");
          } else if (currentRound == "round_4") {
            setInningRound("round_5");
            setCurrentRound({ inning: "Inning2", round: "round_5" });
            setScoreShow(true);
            showScoreModal("forthRound", inningChecked, "PENDING", "round_5");
          }
        } else if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "PROGRESS" &&
          checkNextRound?.batInfo == null &&
          checkNextRound?.bowlerInfo == null &&
          roomData?.isBatSelected == 0 &&
          checkRound?.overFulfilled
        ) {
          setCurrentRound({});
          if (currentRound == "round_1") {
            setInningRound("round_1");
            // setCurrentRound({ inning: "Inning2", round: "round_1" });
            setScoreShow(true);
            showScoreModal("firstRound", inningChecked, "PROGRESS");
          } else if (currentRound == "round_2") {
            setInningRound("round_2");
            // setCurrentRound({ inning: "Inning2", round: "round_2" });
            setScoreShow(true);
            showScoreModal("secondRound", inningChecked, "PROGRESS");
          } else if (currentRound == "round_3") {
            setInningRound("round_3");
            // setCurrentRound({ inning: "Inning2", round: "round_3" });
            setScoreShow(true);
            showScoreModal("thirdRound", inningChecked, "PROGRESS");
          } else if (currentRound == "round_4") {
            setInningRound("round_4");
            // setCurrentRound({ inning: "Inning2", round: "round_4" });
            setScoreShow(true);
            showScoreModal("forthRound", inningChecked, "PROGRESS");
          }
        }
      }
    }
  };

  const checkPlyerChange = () => {
    if (!changeBatRef.current) {
      setBattingMessage("Wait for opponent selection");
      // setWaitModalForScore(true);
      sendNotifyToBowlingTeam(
        "",
        { inning: "Inning2", round: inningRound, again: 1 },
        1
      );
      setBoosterDisable(true);
    } else {
      let roundVal = roomData?.currentRound.split("_")[1];
      let checkNextRound = "round_" + (+roundVal + +1);
      setInningRound(checkNextRound);
      setYourPlayer(false);
      setShowArtifact(false);
      setSelectedArtifacts([]);
      setBattingPlayer({});
      setChangeBat(!changeBatRef.current);
      dispatch(startCountDown(timerCount));
      dispatch(setCountDownEnable(true));
      setCount(timerCount);
      setBattingMessage("Select Batsman");
      setCheckInningRound("COMPLETED");
      dispatch(savePlayer(false));
    }
  };
  const showScoreModal = (round, inningChecked, roundStatus, chkRound) => {
    dispatch(setCountDownEnable(false));
    setWaitModalForScore(false);
    if (roundStatus === "PENDING") {
      setBoosterDisable(true);
      dispatch(enableDoneBtn({}));
      if (playerASocketId == socket.id) {
        if (roomData?.isSecondPlayerBot) {
          setTimeout(() => {
            setBowlingMessage("");
            sendNotifyToBowlingTeam(
              "",
              { inning: "Inning2", round: chkRound },
              0
            );
          }, 6000);

          setTimeout(() => {
            setScoreShow(false);
            setBowlingMessage("Wait for opponent selection");
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning2", round: chkRound },
              0
            );
          }, 4000);
          setTimeout(() => {
            setBoosterDisable(true);
            setBotSocket(false);
            dispatch(savePlayer(false));
            // setScoreShow(false);
            setBowlingMessage("");
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning2", round: chkRound },
              scoreStatus
            );
          }, 9000);
        } else {
          setTimeout(() => {
            setScoreShow(false);
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning2", round: chkRound, again: 1 },
              0
            );
          }, 4000);
          setTimeout(() => {
            setBoosterDisable(true);
            setBotSocket(false);
            dispatch(savePlayer(false));
            // setScoreShow(false);
            setBowlingMessage("Wait for opponent selection");
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning2", round: chkRound, again: 1 },
              scoreStatus
            );
          }, 5000);
        }
      } else if (playerBSocketId == socket.id) {
        setBattingPlayer({});
        setTimeout(() => {
          setSelectedArtifacts([]);
          setBotSocket(false);
          // setCheckInningRound("COMPLETED");
          dispatch(savePlayer(false));
          // dispatch(enableDoneBtn({}));
          setScoreShow(false);
          dispatch(startCountDown(timerCount));
          dispatch(setCountDownEnable(true));
          setCount(timerCount);
          setBattingMessage("Select Batsman");
          setYourPlayer(true);
          setShowArtifact(false);
        }, 6000);
      }
    } else if (
      roundStatus === "PROGRESS" &&
      roomData?.isBatSelected == 0 &&
      inningChecked?.RoundsInfo?.Inning2?.status == "PROGRESS"
    ) {
      setTimeout(() => {
        setBotSocket(false);
        dispatch(savePlayer(false));
        setScoreShow(false);
        if (roomData?.isSecondPlayerBot) {
          setBoosterDisable(false);
          setSelectedArtifacts([]);
          dispatch(enableDoneBtn({}));
          setYourPlayer(true);
          setShowArtifact(false);
          setBowlingMessage("");
          setBowlingPlayer({});
          // setWaitModalForScore(true);
          sendNotifyToBowlingTeam(
            "",
            { inning: "Inning2", round: inningRound, again: 1 },
            1
          );
        } else {
          if (playerASocketId == socket.id) {
            setYourPlayer(false);
            setShowArtifact(false);
            // setCount(timerCount);
            // dispatch(setCountDownEnable(true));
            setBowlingMessage("Select Bowler");
            setSelectedArtifacts([]);
            setBowlingPlayer({});
          } else if (playerBSocketId == socket.id) {
            checkPlyerChange();
          }
        }
      }, 5000);
    } else {
      if (inningChecked?.RoundsInfo?.Inning2?.status == "COMPLETED") {
        setTimeout(() => {
          if (inningChecked?.winner == "TIE") {
            navigate("/match-tie");
          } else if (
            playerASocketId == socket.id &&
            inningChecked?.WinnerId == playerASocketId
          ) {
            navigate("/you-won");
          } else if (
            playerASocketId == socket.id &&
            inningChecked?.looserId == playerASocketId
          ) {
            navigate("/you-lost");
          }

          if (
            playerBSocketId == socket.id &&
            inningChecked?.WinnerId == playerBSocketId
          ) {
            navigate("/you-won");
          } else if (
            playerBSocketId == socket.id &&
            inningChecked?.looserId == playerBSocketId
          ) {
            navigate("/you-lost");
          }
        }, 5000);
      }

      setTimeout(() => {
        setSelectedArtifacts([]);
        setBotSocket(false);
        setCheckInningRound("COMPLETED");
        dispatch(savePlayer(false));
        dispatch(enableDoneBtn({}));
        setScoreShow(false);

        if (round == "fivethRound") {
          setBowlingMessage("Second inning is complete");
          setBattingMessage("Second inning is complete");
        } else {
          setBattingPlayer({});
          setBowlingPlayer({});
          // dispatch(startCountDown(timerCount));
          // dispatch(setCountDownEnable(false));
          // setCount(timerCount);

          if (playerBSocketId == socket.id) {
            dispatch(startCountDown(timerCount));
            dispatch(setCountDownEnable(true));
            setCount(timerCount);
          } else if (roomData?.isSecondPlayerBot) {
            dispatch(startCountDown(timerCount));
            dispatch(setCountDownEnable(false));
            setCount(timerCount);
          }
          setBowlingMessage("Select Bowler");
          setBattingMessage("Select Batsman");
        }
        setYourPlayer(true);
        setShowArtifact(false);
      }, 5000);
    }
  };

  //send notification to  player1 (batting team) for bowler is selected
  const sendNotifyToBattingTeam = (bowlerInfo, round, scoreVal) => {
    let bowlWithArt =
      Object.keys(bowlingPlayer).length > 0
        ? { ...bowlingPlayer, artifacts: selectedArtifacts }
        : bowlerInfo;
    if (scoreVal == 1 && roomData?.overCompleted) {
      dispatch(setBowlerRecords([...bowlerRecords, bowlWithArt?.nftId]));
    }
    // dispatch(setBowlerRecords([...bowlerRecords, bowlWithArt?.nftId]));

    let bowlerRound = {
      isScore: scoreVal,
      roomId: playerMatchedData?.roomId,
      socketId: playerASocketId,
      roundInfo:
        !!round && Object.keys(round).length > 0 ? round : currentRound,
      bowlerInfo: bowlWithArt,
    };
    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: bowlerRound,
      }
    );
  };

  const selectYourPlayer = (
    playerType,
    playerSocketId,
    cardId,
    playerInfo,
    card_Type
  ) => {
    setChangeBat(false);
    setBoosterDisable(false);
    if (roundInfo?.Inning2?.status == "PROGRESS") {
      let roundInfoPlayer = { inning: "Inning2", round: inningRound };
      setCurrentRound(roundInfoPlayer);

      if (playerType == "BAT" && playerSocketId == socket.id) {
        if (artifactList && artifactList.length > 0) {
          setBattingMessage("Select Boosters");
        } else {
          setBattingMessage("");
        }
        setYourPlayer(true);
        setShowArtifact(true);
        setBattingPlayer(playerInfo);
        sendNotifyToBowlingTeam(playerInfo, roundInfoPlayer, 0);
        dispatch(
          enableDoneBtn({
            playerInfoData: playerInfo,
            roundInfo: roundInfoPlayer,
          })
        );
        document.body.className = "noBackDrop";
      }

      if (playerType == "BOWL" && playerSocketId != socket.id) {
        if (roomData?.isBatSelected == 1) {
          if (artifactList && artifactList.length > 0) {
            setBowlingMessage("Select Booster");
          } else {
            setBowlingMessage("");
          }

          setBowlingPlayer(playerInfo);
          dispatch(
            enableDoneBtn({
              playerInfoData: playerInfo,
              roundInfo: roundInfoPlayer,
            })
          );
          sendNotifyToBattingTeam(playerInfo, roundInfoPlayer, 0);
          setYourPlayer(true);
          setShowArtifact(true);
          document.body.className = "noBackDrop";
        } else {
          toast.error("Wait for opponent select the batsman", {
            toastId: "error2",
          });
        }
      }
    }
  };

  const artifactCallBack = (data) => {
    if (data?.status == 200) {
      dispatch(getUserArtifacts());
    }
    return null;
  };

  useEffect(() => {
    if (selectedArtifacts.length > 0) {
      if (playerBSocketId == socket.id) {
        sendNotifyToBowlingTeam(
          "",
          { inning: "Inning2", round: inningRound },
          0
        );
      } else {
        sendNotifyToBattingTeam(
          "",
          { inning: "Inning2", round: inningRound },
          0
        );
      }
    }
  }, [selectedArtifacts]);

  const showArtEffectHandler = (id, card_type) => {
    if (
      playerASocketId == socket.id &&
      ((batBoosterFirstInning.length == 3 &&
        bowlBoosterSecondInning.length < 2) ||
        (batBoosterFirstInning.length < 3 &&
          bowlBoosterSecondInning.length <= 2))
    ) {
      if (selectedArtifacts.length < 1) {
        setSelectedArtifacts([...selectedArtifacts, id]);
        dispatch(setBowlBosterInningSecond([...bowlBoosterSecondInning, id]));
        dispatch(deductArtifact({ artefact_id: id }, artifactCallBack));
      }
    } else if (
      playerBSocketId == socket.id &&
      ((bowlBoosterFirstInning.length == 3 &&
        batBoosterSecondInning.length < 2) ||
        (bowlBoosterFirstInning.length < 3 &&
          batBoosterSecondInning.length <= 2))
    ) {
      if (selectedArtifacts.length < 1) {
        setSelectedArtifacts([...selectedArtifacts, id]);
        dispatch(setBatBosterInningSecond([...batBoosterSecondInning, id]));
        dispatch(deductArtifact({ artefact_id: id }, artifactCallBack));
      } else {
        toast.error("Choose one booster", {
          toastId: "error1",
        });
      }
      setBattingMessage("");
      setBowlingMessage("");
    } else {
      toast.error(
        "You can choose a maximum 3 boosters in a inning & 5 in a game.",
        {
          toastId: "error3",
        }
      );
    }
  };

  //change batsman
  const changeBatsman = () => {
    setYourPlayer(false);
    setShowArtifact(false);
    setSelectedArtifacts([]);
    setChangeBat(true);
  };

  //already played ids
  let batPlayerIds = [];
  let bowlerPlayedIds = [];

  for (let i = 1; i <= 5; i++) {
    let round = "round_" + i;
    if (roundInfo?.Inning2?.[round]?.batInfo) {
      batPlayerIds.push(roundInfo?.Inning2?.[round]?.batInfo?.nftId);
    }
    if (roundInfo?.Inning2?.[round]?.bowlerInfo) {
      bowlerPlayedIds.push(roundInfo?.Inning2?.[round]?.bowlerInfo?.nftId);
    }
  }

  //random bowler selection
  const randomSelectPlayer = (player) => {
    let cardsList = playerData;
    let boosterId = [];

    // const nftIndex = cardsList.findIndex(
    //   (item) => item?.nftId == roomData?.currentBowler
    // );

    if (player == "batsman") {
      batPlayerIds &&
        batPlayerIds.length > 0 &&
        batPlayerIds.map((e) => {
          const nftIndex = cardsList.findIndex((item) => item?.nftId == e);
          if (nftIndex !== -1) {
            cardsList.splice(nftIndex, 1);
          }
        });

      const randomIndex = Math.floor(Math.random() * cardsList.length);
      let nftData = cardsList[randomIndex];
      let usedByBatBooster = artifactList.filter(
        (item) => item?.usedByBatsman == 1
      );

      const randomBoosterIndex = Math.floor(
        Math.random() * usedByBatBooster.length
      );

      if (
        (bowlBoosterFirstInning.length == 3 &&
          batBoosterSecondInning.length < 2) ||
        (bowlBoosterFirstInning.length < 3 &&
          batBoosterSecondInning.length <= 2)
      ) {
        let artifactId = usedByBatBooster[randomBoosterIndex]?.ds_id;
        setSelectedArtifacts([artifactId]);
        dispatch(deductArtifact({ artefact_id: artifactId }, artifactCallBack));
        dispatch(
          setBatBosterInningSecond([...batBoosterSecondInning, artifactId])
        );
        boosterId = [artifactId];
      }
      let playerInfo = {
        outlineImage: nftData?.outlineImage,
        da_id: nftData?.da_id,
        nftId: nftData?.nftId,
        name: nftData?.title,
        gameTitle: nftData?.gameTitle,
        img: nftData?.nftLogo,
        artifacts: boosterId,
        isArtifact: 0,
      };
      setYourPlayer(true);
      setShowArtifact(true);
      setBattingPlayer(playerInfo);
      setBoosterDisable(true);

      sendNotifyToBowlingTeam(
        playerInfo,
        { inning: "Inning2", round: inningRound },
        0
      );

      setTimeout(() => {
        sendNotifyToBowlingTeam(
          playerInfo,
          { inning: "Inning2", round: inningRound },
          1
        );
      }, 3000);
      if (
        roomData?.RoundsInfo?.Inning2[roomData?.currentRound]?.bowlerInfo !==
        null
      ) {
        setBattingMessage("");
      } else {
        setBattingMessage("Wait for opponent selection");
      }
    } else if (player == "bowler") {
      const toFindDuplicates = bowlerRecords.filter(
        (item, index) => bowlerRecords.indexOf(item) !== index
      );

      //remove duplicate value
      toFindDuplicates &&
        toFindDuplicates.length > 0 &&
        toFindDuplicates.map((e) => {
          const cardsListIndex = cardsList.findIndex(
            (item) => item?.nftId == e
          );
          if (cardsListIndex !== -1) {
            cardsList.splice(cardsListIndex, 1);
          }
        });

      // if (nftIndex !== -1) {
      //   cardsList.splice(nftIndex, 1);
      // }

      const randomIndex = Math.floor(Math.random() * cardsList.length);
      const nftData = cardsList[randomIndex];
      let usedByBowlBooster = artifactList.filter(
        (item) => item?.usedByBowler == 1
      );
      const randomBoosterIndex = Math.floor(
        Math.random() * usedByBowlBooster.length
      );

      if (
        (batBoosterFirstInning.length == 3 &&
          bowlBoosterSecondInning.length < 2) ||
        (batBoosterFirstInning.length < 3 &&
          bowlBoosterSecondInning.length <= 2)
      ) {
        let artifactId = usedByBowlBooster[randomBoosterIndex]?.ds_id;
        setSelectedArtifacts([artifactId]);
        dispatch(deductArtifact({ artefact_id: artifactId }, artifactCallBack));
        dispatch(
          setBowlBosterInningSecond([...bowlBoosterSecondInning, artifactId])
        );
        boosterId = [artifactId];
      }

      let playerInfo = {
        outlineImage: nftData?.outlineImage,
        da_id: nftData?.da_id,
        nftId: nftData?.nftId,
        name: nftData?.title,
        gameTitle: nftData?.gameTitle,
        img: nftData?.nftLogo,
        artifacts: boosterId,
        isArtifact: 0,
      };
      setYourPlayer(true);
      setShowArtifact(true);
      setBowlingPlayer(playerInfo);
      setBoosterDisable(true);
      sendNotifyToBattingTeam(
        playerInfo,
        { inning: "Inning2", round: inningRound },
        0
      );
      setTimeout(() => {
        sendNotifyToBattingTeam(
          playerInfo,
          { inning: "Inning2", round: inningRound },
          1
        );
      }, 3000);
    }
    if (
      roomData?.RoundsInfo?.Inning2[roomData?.currentRound]?.batInfo !== null
    ) {
      setBowlingMessage("");
    } else {
      setBowlingMessage("Wait for opponent selection");
    }
  };

  return (
    <>
      <div className="Ground">
        <div className="opponentScore">
          {!!roomData && (
            <SecondInningScores
              roomData={roomData}
              playerBSocketId={playerBSocketId}
              socket={socket}
              opponent={true}
            />
          )}
        </div>
        <div className="opponentCard">
          {!!playerMatchedData &&
            !!playerMatchedData?.playerIds &&
            !!playerMatchedData?.playerIds[opponetSocket] &&
            playerMatchedData?.playerIds[opponetSocket].length > 0 && (
              <OpponentCard
                playerMatchedData={playerMatchedData?.playerIds[opponetSocket]}
              />
            )}
        </div>
        <div className="MainGround">
          {/* {!!roundInfo?.Inning2 && roundInfo?.Inning2?.[roomData?.currentRound] != null  && */}
          <OpponentPlayer
            playersSocketId={playerBSocketId}
            roundInfo={
              playerASocketId == socket.id && roomData?.isBatSelected == 1
                ? roundInfo?.Inning2[roomData?.currentRound]
                : playerBSocketId == socket.id
                ? !!roundInfo?.Inning2[roomData?.currentRound]
                  ? roundInfo?.Inning2[roomData?.currentRound]
                  : {}
                : playerASocketId == socket.id &&
                  roomData?.isBatSelected == 0 &&
                  roomData?.isChanged == 1 &&
                  roundInfo?.Inning2[roomData?.currentRound]?.batInfo != null &&
                  roundInfo?.Inning2[roomData?.currentRound]?.bowlerInfo != null
                ? roundInfo?.Inning2[roomData?.currentRound]
                : {}
            }
            roomData={roomData}
            socket={socket}
            artifactList={artifactList}
            selectedArtifacts={selectedArtifacts}
            checkInningRound={checkInningRound}
            // roundInfo={roundInfo}
          />

          <div className="stadiumName">
            <h2>{roomData?.stadiumName}</h2>
          </div>
          <div className="Pitch">
            {roomData?.RoundsInfo?.Inning2?.status == "PROGRESS" ? (
              playerBSocketId == socket.id ? (
                <p className="grondMesage">{battingMessage}</p>
              ) : (
                <p className="grondMesage">{bowlingMessage}</p>
              )
            ) : (
              <p className="grondMesage">Inning Complete</p>
            )}

            <img src={pitch} alt="pitch" className="pitch" />
          </div>
          <YourPlayer
            playersSocketId={playerBSocketId}
            socket={socket}
            bowlingPlayer={bowlingPlayer}
            battingPlayer={battingPlayer}
            yourPlayer={yourPlayer}
            artifactList={artifactList}
            selectedArtifacts={selectedArtifacts}
          />
        </div>
      </div>
      <div className="PlayerAdd">
        <div className="yourScore">
          {!!roomData && (
            <SecondInningScores
              roomData={roomData}
              playerBSocketId={playerBSocketId}
              socket={socket}
              opponent={false}
            />
          )}
        </div>

        {!showArtifact && playerData.length > 0 && (
          <YourCards
            playerMatchedData={playerData}
            roomData={roomData}
            roundInfo={roundInfo?.Inning2}
            playerASocketId={playerASocketId}
            playerBSocketId={playerBSocketId}
            socket={socket}
            selectYourPlayer={selectYourPlayer}
            inning="second"
            bowlerRecords={bowlerRecords}
            batPlayerIds={batPlayerIds}
          />
        )}

        {showArtifact && (
          <UserArtifacts
            boosterDisable={boosterDisable}
            selectedArtifacts={selectedArtifacts}
            artifactList={artifactList}
            playerASocketId={playerASocketId}
            playerBSocketId={playerBSocketId}
            inning="second"
            playersSocketId={playerBSocketId}
            socket={socket}
            showArtEffectHandler={showArtEffectHandler}
          />
        )}
      </div>
      {roundInfo?.Inning2?.round_1 == null && timerclose && (
        <InningsChangeModal
          playerType={playerBSocketId == socket.id ? "Batsman" : "Bowler"}
          roomData={roomData}
        />
      )}

      {roundInfo?.Inning2?.round_1 == null && showStartGame && (
        <PlayerTurnModal
          playerSocketId={playerBSocketId == socket.id ? "Batsman" : "Bowler"}
        />
      )}

      {WaitModalForScore ? (
        <WaitingModal message={"Wait for score!"} subMessage={""} />
      ) : (
        ""
      )}

      {scoreShow &&
        roomData?.RoundsInfo?.Inning2[roomData?.currentRound]?.batInfo && (
          <>
          <ScoreBoredModal
            changeBat={changeBat}
            changeBatsman={changeBatsman}
            playersSocketId={playerBSocketId}
            currentRound={roomData?.currentRound}
            inning="Second"
            roomData={roomData}
            roundInfo={roomData?.RoundsInfo?.Inning2[roomData?.currentRound]}
          />
    
          </>
        )}
    </>
  );
}

export default InningSecond;
