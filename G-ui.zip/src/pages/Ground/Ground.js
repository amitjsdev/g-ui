import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import "./Ground.scss";
import { useDispatch, useSelector } from "react-redux";
import InningFirst from "./InningFirst";
import InningSecond from "./InningSecond";
import { matchedData } from "../../redux/user/action";
import socket from "../../socket";
import { useNavigate } from "react-router-dom";
import { getArtifactsList } from "../../redux/user/action";

function Ground() {
  let navigate = useNavigate();
  const dispatch = useDispatch();

  const splitLocation = window.location.pathname.split("/");
  const [checkRound, setCheckRound] = useState("PROGRESS");
  const [socketInitialized, setSocketInitialized] = useState(false);
  const [artifactList, setArtifactList] = useState([]);

  const playerMatchedData = useSelector(
    (state) => state?.userReducer?.matchedData
  );
  console.log(playerMatchedData)
  const callback = (data) => {
    if (data) {
      setArtifactList(data?.data);
    }
    return null;
  };

  const fetchArtifactList = async () => {
    dispatch(getArtifactsList(callback));
  };

  // useEffect(() => {
  //   setInningStatus(checkRound);
  // }, [checkRound]);

  useEffect(() => {
    if (!playerMatchedData) {
      window.location.replace("/");
      return;
    }
    if (!socketInitialized) {
      socket.on("game_room_update_round_1", (data) => {
        // console.log("game_room_update_round_1", data);
        dispatch(matchedData(data));
      });
      //user refreesh
      socket.removeListener("room_destroyed");
      socket.on("room_destroyed", (data) => {
        if (data?.data?.roomData?.MatchStatus == "COMPLETED") {
          dispatch(matchedData(data));
          if (splitLocation[1] == "ground") {
            toast.error(data?.message);
            navigate("/you-won");

            setTimeout(() => {}, 2000);
          }
        }
      });

      setSocketInitialized(true);
    }
    if (artifactList.length === 0) {
      fetchArtifactList();
    }
  }, [socketInitialized]);

  return (
    <>
      {console.log("game=", playerMatchedData, checkRound)}
      {checkRound !== "COMPLETED" ? (
        <InningFirst
          setCheckRound={setCheckRound}
          playerMatchedData={playerMatchedData?.data}
          artifactList={artifactList}
        />
      ) : (
        <InningSecond
          artifactList={artifactList}
          checkRound={checkRound}
          playerMatchedData={playerMatchedData?.data}
        />
      )}
    </>
  );
}

export default Ground;
