import React, { useState, useEffect } from "react";
import hardik from "../../assets/images/hardik.png";

const OpponentPlayer = React.memo(
  ({
    roomData,
    playersSocketId,
    socket,
    roundInfo,
    checkInningRound,
    artifactList,
  }) => {
    return (
      <>
        {/* boosters display  start*/}

        {playersSocketId == socket.id && checkInningRound == "PENDING" ? (
          <div className="boosterOpp">
            {roundInfo?.bowlerInfo?.artifacts &&
              roundInfo?.bowlerInfo?.artifacts.length > 0 &&
              roundInfo?.bowlerInfo?.artifacts.map((id, index) => {
                let findBooster =
                  artifactList &&
                  artifactList.length > 0 &&
                  artifactList.find((item) => item.ds_id == id);
                return (
                  <div key={index} className="Opponentplay ball_icon">
                    <img src={findBooster?.image} alt={findBooster?.title} />
                  </div>
                );
              })}
          </div>
        ) : (
          checkInningRound == "PENDING" && (
            <div className="boosterOpp">
              {roundInfo?.batInfo?.artifacts &&
                roundInfo?.batInfo?.artifacts.length > 0 &&
                roundInfo?.batInfo?.artifacts.map((id, index) => {
                  let findBooster =
                    artifactList &&
                    artifactList.length > 0 &&
                    artifactList.find((item) => item.ds_id == id);
                  return (
                    <div className="Opponentplay bat_icon">
                      <img src={findBooster?.image} alt={findBooster?.title} />
                    </div>
                  );
                })}
            </div>
          )
        )}
        {/* boosters display  end*/}
        <div className="OppoPlayer">
          {playersSocketId == socket.id && checkInningRound == "PENDING" ? (
            <>
              {!!roomData?.currentRound ? (
                <>
                  <img
                    src={
                      roundInfo?.bowlerInfo?.outlineImage
                        ? roundInfo?.bowlerInfo?.outlineImage
                        : hardik
                    }
                    className="showVir playicon playerImg"
                  />
                  <h3>
                    {roundInfo?.bowlerInfo?.gameTitle
                      ? roundInfo?.bowlerInfo?.gameTitle
                      : "Opponent player"}
                  </h3>
                </>
              ) : (
                <>
                  <img src={hardik} className="showVir playicon playerImg" />
                  <h3>Opponent player</h3>
                </>
              )}
            </>
          ) : (
            <>
              {!!roomData?.currentRound && checkInningRound == "PENDING" ? (
                <>
                  <img
                    src={
                      roundInfo?.batInfo?.outlineImage
                        ? roundInfo?.batInfo?.outlineImage
                        : hardik
                    }
                    className="showVir playicon playerImg"
                  />
                  <h3>
                    {roundInfo?.batInfo?.gameTitle
                      ? roundInfo?.batInfo?.gameTitle
                      : "Opponent player"}
                  </h3>
                </>
              ) : (
                <>
                  <img
                    src={hardik}
                    alt="hardik"
                    className="showVir playicon playerImg"
                  />
                  <h3>Opponent player</h3>
                </>
              )}
            </>
          )}
        </div>
      </>
    );
  },
  (prevProps, nextProps) => {
    // const A = JSON.stringify(prevProps);
    // const B = JSON.stringify(nextProps);
    // return (
    //   A === B
    //   // prevProps?.roundResult?.length === nextProps?.roundResult?.length &&
    //   // prevProps.selectedCard === nextProps.selectedCard
    // );
  }
);

export default OpponentPlayer;
