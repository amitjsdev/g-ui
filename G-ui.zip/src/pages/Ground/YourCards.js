import React, { useState, useEffect } from "react";
import Slider from "react-slick";

const YourCards = React.memo(
  ({
    playerMatchedData,
    roomData,
    roundInfo,
    playerASocketId,
    playerBSocketId,
    socket,
    selectYourPlayer,
    inning,
    batPlayerIds,
    bowlerPlayedIds,
    bowlerRecords,
  }) => {
    var settings = {
      dots: true,
      infinite: false,
      speed: 500,
      slidesToShow: 5,
      slidesToScroll: 1,
      responsive: [
        {
          breakpoint: 680,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 350,
          settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
          },
        },
      ],
    };
    return (
      <div className="YourCard">
        <Slider {...settings}>
          {
            // first inning start
            inning == "first"
              ? playerMatchedData?.map((item, index) => {
                  let currentRound = roomData?.currentRound;
                  let infoInRound = roundInfo?.[currentRound];

                  const toFindDuplicates = bowlerRecords.filter(
                    (item, index) => bowlerRecords.indexOf(item) !== index
                  );

                  // let diableCard =
                  //   playerASocketId == socket.id && item?.card_type == "BOWL"
                  //     ? "disableBowl"
                  //     : playerBSocketId == socket.id && item?.card_type == "BAT"
                  //     ? "disableBat"
                  //     : "";
                  // let card_type;
                  // if (item?.card_type == "ALL") {
                  //   card_type = playerASocketId == socket.id ? "BAT" : "BOWL";
                  // } else {
                  //   card_type = item?.card_type;
                  // }

                  let card_type = playerASocketId == socket.id ? "BAT" : "BOWL";

                  let playerInfo = {
                    outlineImage: item?.outlineImage,
                    da_id: item?.da_id,
                    nftId: item?.nftId,
                    name: item?.title,
                    gameTitle: item?.gameTitle,
                    img: item?.nftLogo,
                    artifacts: [],
                    isArtifact: 0,
                  };

                  let alreadyPlayed;
                  if (infoInRound && playerASocketId == socket.id) {
                    alreadyPlayed =
                      batPlayerIds &&
                      batPlayerIds.length > 0 &&
                      batPlayerIds.includes(item?.nftId)
                        ? "alredyPlay"
                        : "";
                  }

                  if (infoInRound && playerBSocketId == socket.id) {
                    // alreadyPlayed =
                    //   bowlerPlayedIds &&
                    //   bowlerPlayedIds.length > 0 &&
                    //   bowlerPlayedIds.includes(item?.nftId)
                    //     ? "alredyPlay"
                    //     : "";
                    alreadyPlayed =
                      roomData?.previousBowler == item?.nftId
                        ? "alredyPlay"
                        : toFindDuplicates.includes(item?.nftId)
                        ? "alredyPlay"
                        : "";
                  }
                  return (
                    <>
                      <div
                        key={index}
                        onClick={() => {
                          selectYourPlayer(
                            card_type,
                            playerASocketId,
                            item?.nftId,
                            playerInfo,
                            item?.card_type
                          );
                        }}
                        className={`cards ${alreadyPlayed} ${card_type}`}
                      >
                        <img
                          src={item?.nftLogo}
                          alt={item?.name}
                          className="Virat"
                        />
                      </div>
                      {/* <p className="playerNameGnd">{item?.gameTitle}</p> */}
                    </>
                  );
                  // }
                })
              : // second inning start

                playerMatchedData?.map((item, index) => {
                  let currentRound = roomData?.currentRound;
                  let infoInRound = roundInfo?.[currentRound];

                  const toFindDuplicates = bowlerRecords.filter(
                    (item, index) => bowlerRecords.indexOf(item) !== index
                  );
                  // console.log("toFindDuplicates", toFindDuplicates);

                  // for (let i = 1; i <= 5; i++) {
                  //   let round = "round_" + i;
                  //   if (roundInfo?.[round]?.batInfo) {
                  //     batPlayerIds.push(roundInfo?.[round]?.batInfo?.nftId);
                  //   }
                  //   if (roundInfo?.[round]?.bowlerInfo) {
                  //     bowlerPlayedIds.push(
                  //       roundInfo?.[round]?.bowlerInfo?.nftId
                  //     );
                  //   }
                  // }
                  // let diableCard = playerBSocketId == socket.id && item?.card_type == "BOWL" ? 'disableBowl' : playerASocketId == socket.id  && item?.card_type == "BAT" ? 'disableBat' : '' ;

                  // let card_type;
                  // if(item?.card_type == 'ALL'){
                  //    card_type = playerBSocketId == socket.id ? 'BAT' : 'BOWL';
                  // }else{
                  //   card_type = item?.card_type
                  // }
                  let card_type = playerBSocketId == socket.id ? "BAT" : "BOWL";

                  let batInfo = {
                    outlineImage: item?.outlineImage,
                    da_id: item?.da_id,
                    nftId: item?.nftId,
                    name: item?.title,
                    gameTitle: item?.gameTitle,
                    img: item?.nftLogo,
                    artifacts: [],
                    isArtifact: 0,
                  };

                  let alreadyPlayed;
                  //check for batsman
                  if (infoInRound && playerBSocketId == socket.id) {
                    alreadyPlayed =
                      batPlayerIds &&
                      batPlayerIds.length > 0 &&
                      batPlayerIds.includes(item?.nftId)
                        ? "alredyPlay"
                        : "";
                  }
                  //check for bowler
                  if (infoInRound && playerASocketId == socket.id) {
                    // alreadyPlayed =
                    //   bowlerPlayedIds &&
                    //   bowlerPlayedIds.length > 0 &&
                    //   bowlerPlayedIds.includes(item?.nftId)
                    //     ? "alredyPlay"
                    //     : "";
                    alreadyPlayed =
                      roomData?.previousBowler == item?.nftId
                        ? "alredyPlay"
                        : toFindDuplicates.includes(item?.nftId)
                        ? "alredyPlay"
                        : "";
                  }
                  return (
                    <>
                      <div
                        key={index}
                        onClick={() => {
                          selectYourPlayer(
                            card_type,
                            playerBSocketId,
                            item?.nftId,
                            batInfo,
                            item?.card_type
                          );
                        }}
                        className={`cards ${alreadyPlayed} ${card_type}`}
                      >
                        <img
                          src={item?.nftLogo}
                          alt={item?.name}
                          className="Virat"
                        />
                      </div>
                      {/* <p className="playerNameGnd">{item?.gameTitle}</p> */}
                    </>
                  );
                  // }
                })
          }
        </Slider>
      </div>
    );
  },
  (prevProps, nextProps) => {
    // const A = JSON.stringify(prevProps);
    // const B = JSON.stringify(nextProps);
    // return (
    //   A === B
    //   // prevProps?.roundResult?.length === nextProps?.roundResult?.length &&
    //   // prevProps.selectedCard === nextProps.selectedCard
    // );
  }
);

export default YourCards;
