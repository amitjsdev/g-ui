import React, { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import "./Ground.scss";
import pitch from "../../assets/images/pitch.png";
import ballfire from "../../assets/images/ballfire.png";
import Rocket from "../../assets/images/Rocket.png";
import { useNavigate } from "react-router-dom";
import {
  startCountDown,
  enableDoneBtn,
  setCountDownEnable,
  getUserArtifacts,
  deductArtifact,
  savePlayer,
  setBatBosterInningFirst,
  setBowlBosterInningFirst,
  setBowlerRecords,
} from "../../redux/user/action";
import { useDispatch, useSelector } from "react-redux";
import socket from "../../socket";
import WaitingModal from "../../modals/WaitingModal";
import OpponentCard from "./OpponentCards";
import UserArtifacts from "./UserArtifacts";
import YourCards from "./YourCards";
import OpponentPlayer from "./OpponentPlayer";
import YourPlayer from "./YourPlayer";
import FirstInningScores from "./FirstInningScores";
import TimeOutModal from "../../modals/TimeOutModal";
import ScoreBoredModal from "../../modals/ScoreBoredModal";

let timerCount = 10;
let scoreStatus = 1;
function InningFirst(props) {
  const { playerMatchedData, setCheckRound, artifactList } = props;
  let roomData = playerMatchedData?.roomData;
  let roundInfo = roomData?.RoundsInfo;
  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [showStartGame, setShowStartGame] = useState(false);
  const [yourPlayer, setYourPlayer] = useState(false);
  const [showArtifact, setShowArtifact] = useState(false);
  const [battingPlayer, setBattingPlayer] = useState({});
  const [bowlingPlayer, setBowlingPlayer] = useState({});
  const [cardType, setCartType] = useState();
  const [currentRound, setCurrentRound] = useState({});
  const [timerclose, setTimerClose] = useState(true);
  const [bowlingMessage, setBowlingMessage] = useState("You're Bowling");
  const [battingMessage, setBattingMessage] = useState("You're Batting");
  const [WaitModalForScore, setWaitModalForScore] = useState(false);
  const [scoreShow, setScoreShow] = useState(false);
  const [inningRound, setInningRound] = useState("round_1");
  const [timeOut, setTimeoutMatch] = useState(false);
  const [checkInningRound, setCheckInningRound] = useState("PENDING");
  const [botSocket, setBotSocket] = useState(false);
  const [counterRun, setCounterRun] = useState(false);
  const [bowlerBot, setBowlerBot] = useState(false);

  const [changeBat, setChangeBat] = useState(false);
  const [boosterDisable, setBoosterDisable] = useState(false);
  const changeBatRef = useRef(changeBat);
  changeBatRef.current = changeBat;

  let playerASocketId = roomData?.playerASocketId;
  let playerBSocketId = roomData?.playerBSocketId;
  let socketPlayerList =
    playerASocketId == socket.id ? playerASocketId : playerBSocketId;
  let opponetSocket =
    playerASocketId == socket.id ? playerBSocketId : playerASocketId;

  let playerData =
    !!playerMatchedData &&
    !!playerMatchedData?.playerIds &&
    !!playerMatchedData?.playerIds[socketPlayerList] &&
    playerMatchedData?.playerIds[socketPlayerList].length > 0
      ? playerMatchedData?.playerIds[socketPlayerList]
      : [];

  const savePlayerInfo = useSelector(
    (state) => state?.userReducer?.informBowlingTeam
  );
  const saveCurrentPlayer = useSelector(
    (state) => state?.userReducer?.enableDoneBtn
  );
  const [selectedArtifacts, setSelectedArtifacts] = useState([]);
  const randomTime = Math.floor(Math.random() * 3) + 1;

  const batBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.batBoosterFirstInning
  );

  const bowlBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.bowlBoosterFirstInning
  );

  // console.log("boosterFirstInning", boosterFirstInning);
  const bowlerRecords = useSelector(
    (state) => state?.userReducer?.bowlerRecords
  );

  useEffect(() => {
    if (!playerMatchedData) {
      navigate("/");
      return;
    }
    dispatch(getUserArtifacts());
    dispatch(enableDoneBtn({}));
    setTimeout(() => {
      setTimerClose(false);
      setShowStartGame(true);
    }, 3000);

    setTimeout(() => {
      setShowStartGame(false);
      if (playerASocketId == socket.id) {
        setCounterRun(true);
        dispatch(setCountDownEnable(true));
        setCount(timerCount);
      }
      if (playerBSocketId == socket.id) {
        setCounterRun(false);
        dispatch(setCountDownEnable(false));
        // setCount(timerCount);
      }
    }, 6000);
  }, [socket]);

  useEffect(() => {
    if (savePlayerInfo) {
      setBoosterDisable(true);
      setCount(-1);
      dispatch(setCountDownEnable(false));
      if (playerASocketId == socket.id) {
        sendNotifyToBowlingTeam(
          saveCurrentPlayer?.playerInfoData,
          saveCurrentPlayer?.roundInfo,
          scoreStatus
        );
      }
      if (playerBSocketId == socket.id) {
        // setWaitModalForScore(true);
        sendNotifyToBattingTeam(
          saveCurrentPlayer?.playerInfoData,
          saveCurrentPlayer?.roundInfo,
          scoreStatus
        );
      }
      dispatch(enableDoneBtn({}));
    }
  }, [savePlayerInfo]);

  const [currentCount, setCount] = useState(timerCount);
  const timer = () => setCount(currentCount - 1);

  useEffect(() => {
    if (counterRun) {
      if (currentCount < 0) {
        if (Object.keys(battingPlayer).length > 0 && !savePlayerInfo) {
          setBoosterDisable(true);
          if (
            roomData?.RoundsInfo?.Inning1?.[roomData?.currentRound]
              ?.bowlerInfo !== null
          ) {
            setBattingMessage("");
          } else {
            setBattingMessage("Wait for opponent selection");
          }
          sendNotifyToBowlingTeam(
            "",
            { inning: "Inning1", round: inningRound },
            1
          );
        } else if (
          playerASocketId == socket.id &&
          !!playerMatchedData &&
          !savePlayerInfo
        ) {
          randomSelectPlayer("batsman");
        }
        //For bowling auto sunmit
        if (Object.keys(bowlingPlayer).length > 0 && !savePlayerInfo) {
          if (
            roomData?.RoundsInfo?.Inning1[roomData?.currentRound]?.batInfo !==
            null
          ) {
            setBowlingMessage("");
          } else {
            setBowlingMessage("Wait for opponent selection");
          }
          setWaitModalForScore(true);
          sendNotifyToBattingTeam(
            "",
            { inning: "Inning1", round: inningRound },
            1
          );
        } else if (
          playerBSocketId == socket.id &&
          !!playerMatchedData &&
          !savePlayerInfo
        ) {
          randomSelectPlayer("bowler");
        }
        return;
      } else {
        if (currentCount < 10) {
          dispatch(startCountDown(0 + "" + currentCount));
          // console.log("timerCount=", timerCount);

          if (
            !botSocket &&
            currentCount === 7 &&
            roomData?.isSecondPlayerBot &&
            counterRun &&
            roomData?.isBatSelected == 1
          ) {
            setBotSocket(true);
            setTimeout(() => {
              sendNotifyToBattingTeam(
                "",
                { inning: "Inning1", round: inningRound },
                0
              );
            }, randomTime * 1000);
            return;
          } else if (currentCount == 0) {
            dispatch(enableDoneBtn({}));
          }
        } else {
          dispatch(startCountDown(currentCount));
        }
      }
    }
    const id = setInterval(timer, 1000);
    return () => clearInterval(id);
  }, [currentCount]);

  //useEffect for send bot final sunbmit for score
  useEffect(() => {
    if (bowlerBot) {
      setBattingMessage("");
      setTimeout(() => {
        sendNotifyToBattingTeam(
          "",
          { inning: "Inning1", round: inningRound },
          scoreStatus
        );
        setWaitModalForScore(true);
        setBowlerBot(false);
      }, [3000]);
    }
  }, [bowlerBot]);

  //send notification to  player2 (bowling team) for batsman is selected and save batsman record
  const sendNotifyToBowlingTeam = (batInfo, round, scoreVal) => {
    let batWithArt =
      Object.keys(battingPlayer).length > 0
        ? { ...battingPlayer, artifacts: selectedArtifacts }
        : batInfo;
    let batRound = {
      isScore: scoreVal,
      roomId: playerMatchedData?.roomId,
      socketId: playerASocketId,
      roundInfo:
        !!round && Object.keys(round).length > 0 ? round : currentRound,
      batInfo: batWithArt,
    };
    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: batRound,
      }
    );
  };

  useEffect(() => {
    if (!playerMatchedData) {
      navigate("/");
      return;
    }
    getGroundUpdateSockte();
  }, [playerMatchedData?.roomData]);

  const getGroundUpdateSockte = () => {
    //get rounds updated data
    let inningChecked = roomData;
    let inningStatus = roomData?.RoundsInfo?.Inning1?.status;
    let checkRound = roomData?.RoundsInfo?.Inning1?.[roomData?.currentRound];
    let roundVal = roomData?.currentRound.split("_")[1];
    let checkNextRound = "round_" + (+roundVal + +1);
    let currentRound = roomData?.currentRound;

    setCheckInningRound("PENDING");
    if (
      inningChecked?.isSecondPlayerBot &&
      roomData?.isBatSelected == 1 &&
      playerASocketId == socket.id
    ) {
      if (checkRound?.bowlerInfo == null) {
        setBattingMessage("Wait for opponent selection");
        dispatch(setCountDownEnable(false));
        setCount(timerCount);
      } else if (checkRound?.bowlerInfo !== null) {
        setBowlerBot(true);
        setBattingMessage("");
        // setCount(timerCount);
      }
    } else if (
      roomData?.isBatSelected == 1 &&
      playerBSocketId == socket.id &&
      checkRound?.bowlerInfo == null
    ) {
      if (roomData?.isChanged == 1) {
        setInningRound(roomData?.currentRound);
      }
      setCount(timerCount);
      setBattingMessage("Select bowler");
      dispatch(setCountDownEnable(true));
      setCounterRun(true);
    } else if (
      (playerASocketId == socket.id &&
        roomData?.isBatSelected == 0 &&
        roomData?.isChanged == 1 &&
        roundInfo?.Inning1[roomData?.currentRound]?.batInfo != null &&
        roundInfo?.Inning1[roomData?.currentRound]?.bowlerInfo != null) ||
      (playerBSocketId == socket.id &&
        roomData?.isChanged == 1 &&
        roundInfo?.Inning1[roomData?.currentRound]?.batInfo != null)
    ) {
      setBowlingMessage("");
    } else if (
      (playerASocketId == socket.id &&
        roomData?.isBatSelected == 1 &&
        roundInfo?.Inning1[roomData?.currentRound]?.bowlerInfo != null) ||
      (playerASocketId == socket.id &&
        roomData?.isChanged == 1 &&
        roundInfo?.Inning1[roomData?.currentRound]?.bowlerInfo != null)
    ) {
      setBattingMessage("");
    }
    if (inningChecked?.MatchStatus == "TIMEOUT") {
      dispatch(setCountDownEnable(false));
      setCount(-1);
      navigate("/time-out");
    } else if (inningChecked?.MatchStatus == "COMPLETED") {
      if (
        inningChecked?.WinnerId == "BOT" &&
        inningChecked?.isSecondPlayerBot &&
        checkRound?.batInfo == null
      ) {
        dispatch(setCountDownEnable(false));
        setCount(-1);
        navigate("/you-lost");
      } else if (
        inningChecked?.winner == "TIE" &&
        checkRound?.batInfo == null &&
        checkRound?.bowlerInfo == null
      ) {
        navigate("/match-tie");
      } else if (
        (checkRound?.batInfo != null &&
          checkRound?.bowlerInfo == null &&
          playerASocketId == socket.id) ||
        (checkRound?.batInfo == null &&
          checkRound?.bowlerInfo != null &&
          playerBSocketId == socket.id)
      ) {
        navigate("/you-won");
      } else if (
        (checkRound?.batInfo == null &&
          checkRound?.bowlerInfo != null &&
          playerASocketId == socket.id) ||
        (checkRound?.batInfo != null &&
          checkRound?.bowlerInfo == null &&
          playerBSocketId == socket.id)
      ) {
        navigate("/you-lost");
      }
    }

    //complete round checks
    if (checkNextRound == "round_6" && currentRound == "round_5") {
      if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED"
      ) {
        setBoosterDisable(false);
        setCurrentRound({ inning: "Inning1", round: "round_5" });
        // setInningRound("round_5");
        setScoreShow(true);
        showScoreModal("fivethRound", inningStatus, checkRound?.roundStatus);
      } else if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "PROGRESS" &&
        roomData?.isBatSelected == 0 &&
        checkRound?.overFulfilled
      ) {
        setInningRound("round_5");
        setCurrentRound({ inning: "Inning1", round: "round_5" });
        setScoreShow(true);
        showScoreModal("forthRound", inningStatus, checkRound?.roundStatus);
      }
    } else {
      if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        checkRound?.overFulfilled
      ) {
        setBoosterDisable(false);
        if (currentRound == "round_1") {
          setInningRound("round_2");
          setCurrentRound({ inning: "Inning1", round: "round_2" });
          setScoreShow(true);
          showScoreModal("firstRound", inningStatus, checkRound?.roundStatus);
        } else if (currentRound == "round_2") {
          setInningRound("round_3");
          setCurrentRound({ inning: "Inning1", round: "round_3" });
          setScoreShow(true);
          showScoreModal("secondRound", inningStatus, checkRound?.roundStatus);
        } else if (currentRound == "round_3") {
          setInningRound("round_4");
          setCurrentRound({ inning: "Inning1", round: "round_4" });
          setScoreShow(true);
          showScoreModal("thirdRound", inningStatus, checkRound?.roundStatus);
        } else if (currentRound == "round_4") {
          setInningRound("round_5");
          setCurrentRound({ inning: "Inning1", round: "round_5" });
          setScoreShow(true);
          showScoreModal("forthRound", inningStatus, checkRound?.roundStatus);
        }
      } else if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        !checkRound?.overFulfilled
        // &&
        // !inningChecked?.isSecondPlayerBot
      ) {
        setInningRound("");
        setCurrentRound({});
        if (currentRound == "round_1") {
          setInningRound("round_2");
          setCurrentRound({ inning: "Inning1", round: "round_2" });
          setScoreShow(true);
          showScoreModal("firstRound", inningStatus, "PENDING", "round_2");
        } else if (currentRound == "round_2") {
          setInningRound("round_3");
          setCurrentRound({ inning: "Inning1", round: "round_3" });
          setScoreShow(true);
          showScoreModal("secondRound", inningStatus, "PENDING", "round_3");
        } else if (currentRound == "round_3") {
          setInningRound("round_4");
          setCurrentRound({ inning: "Inning1", round: "round_4" });
          setScoreShow(true);
          showScoreModal("thirdRound", inningStatus, "PENDING", "round_4");
        } else if (currentRound == "round_4") {
          setInningRound("round_5");
          setCurrentRound({ inning: "Inning1", round: "round_5" });
          setScoreShow(true);
          showScoreModal("forthRound", inningStatus, "PENDING", "round_5");
        }
      } else if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "PROGRESS" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        roomData?.isBatSelected == 0 &&
        checkRound?.overFulfilled
      ) {
        setCurrentRound({});
        if (currentRound == "round_1") {
          setInningRound("round_1");
          // setCurrentRound({ inning: "Inning1", round: "round_1", again: 1 });
          setScoreShow(true);
          showScoreModal("firstRound", inningStatus, "PROGRESS");
        } else if (currentRound == "round_2") {
          setInningRound("round_2");
          // setCurrentRound({ inning: "Inning1", round: "round_2", again: 1 });
          setScoreShow(true);
          showScoreModal("secondRound", inningStatus, "PROGRESS");
        } else if (currentRound == "round_3") {
          setInningRound("round_3");
          // setCurrentRound({ inning: "Inning1", round: "round_3", again: 1 });
          setScoreShow(true);
          showScoreModal("thirdRound", inningStatus, "PROGRESS");
        } else if (currentRound == "round_4") {
          setInningRound("round_4");
          // setCurrentRound({ inning: "Inning1", round: "round_4", again: 1 });
          setScoreShow(true);
          showScoreModal("forthRound", inningStatus, "PROGRESS");
        }
      }
    }
  };

  const checkPlyerChange = () => {
    console.log("changeBatRef", changeBatRef.current);
    if (!changeBatRef.current) {
      setBattingMessage("Wait for opponent selection");
      // setWaitModalForScore(true);
      sendNotifyToBowlingTeam(
        "",
        { inning: "Inning1", round: inningRound, again: 1 },
        1
      );
      setBoosterDisable(true);
    } else {
      let roundVal = roomData?.currentRound.split("_")[1];
      let checkNextRound = "round_" + (+roundVal + +1);
      setInningRound(checkNextRound);
      setYourPlayer(false);
      setShowArtifact(false);
      setSelectedArtifacts([]);
      setBattingPlayer({});
      setChangeBat(!changeBatRef.current);
      dispatch(startCountDown(timerCount));
      dispatch(setCountDownEnable(true));
      setCount(timerCount);
      // setBowlingMessage("Select Bowler");
      setBattingMessage("Select Batsman");
      setCheckInningRound("COMPLETED");
      dispatch(savePlayer(false));
    }
  };

  const showScoreModal = (round, inningStatus, roundStatus, chkRound) => {
    dispatch(setCountDownEnable(false));
    setWaitModalForScore(false);
    if (roundStatus === "PENDING") {
      setBoosterDisable(true);
      dispatch(enableDoneBtn({}));
      if (playerASocketId == socket.id) {
        if (roomData?.isSecondPlayerBot) {
          // setCheckInningRound("COMPLETED");

          setTimeout(() => {
            // setScoreShow(false);
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning1", round: chkRound },
              0
            );
          }, 5000);
        }
        setBattingPlayer({});
        setSelectedArtifacts([]);
        dispatch(savePlayer(false));
        // setTimeout(() => {
        //   // setScoreShow(false);
        //   setBowlingMessage("Wait for opponent selection");
        // }, 4000);
        setTimeout(() => {
          setBotSocket(false);
          setScoreShow(false);
          setYourPlayer(false);
          setShowArtifact(false);
          setCount(timerCount);
          dispatch(setCountDownEnable(true));
          setBattingMessage("Select Batsman");
        }, 6000);
      } else if (playerBSocketId == socket.id) {
        // setTimeout(() => {
        //   setScoreShow(false);
        //   // setBowlingMessage("Wait for opponent selection");
        // }, 4000);

        setTimeout(() => {
          setBowlingMessage("Wait for opponent selection");
          setScoreShow(false);
          sendNotifyToBattingTeam(
            "",
            { inning: "Inning1", round: chkRound, again: 1 },
            0
          );
        }, 4000);

        setTimeout(() => {
          setBowlingMessage("Wait for opponent selection");
          sendNotifyToBattingTeam(
            "",
            { inning: "Inning1", round: chkRound, again: 1 },
            scoreStatus
          );
        }, 5000);
      }

      // setTimeout(() => {
      //   sendNotifyToBattingTeam("", { inning: "Inning1", round: chkRound }, 1);
      // }, 9000);
    } else if (roundStatus == "PROGRESS" && roomData?.isBatSelected == 0) {
      setTimeout(() => {
        setBotSocket(false);
        dispatch(savePlayer(false));
        dispatch(enableDoneBtn({}));
        setScoreShow(false);

        if (playerASocketId == socket.id) {
          checkPlyerChange();
        } else if (playerBSocketId == socket.id) {
          setYourPlayer(false);
          setShowArtifact(false);
          // setCount(timerCount);
          // dispatch(setCountDownEnable(true));
          setBowlingMessage("Select Bowler");
          setSelectedArtifacts([]);
          setBowlingPlayer({});
        }
      }, 5000);
    } else if (roundStatus == "COMPLETED") {
      setYourPlayer(false);
      setShowArtifact(false);
      setSelectedArtifacts([]);
      if (inningStatus == "COMPLETED") {
        setTimeout(() => {
          setCheckRound(inningStatus);
          dispatch(savePlayer(false));
          dispatch(enableDoneBtn({}));
          dispatch(setBowlerRecords([]));
        }, 4000);
      }
      setTimeout(() => {
        setBotSocket(false);
        setCheckInningRound("COMPLETED");
        dispatch(savePlayer(false));
        dispatch(enableDoneBtn({}));
        setScoreShow(false);
        if (round == "fivethRound") {
          setBowlingMessage("First inning is complete");
          setBattingMessage("First inning is complete");
        } else {
          setBattingPlayer({});
          setBowlingPlayer({});
          if (playerASocketId == socket.id) {
            dispatch(startCountDown(timerCount));
            dispatch(setCountDownEnable(true));
            setCount(timerCount);
          }
          setBowlingMessage("Select Bowler");
          setBattingMessage("Select Batsman");
        }
      }, 5000);
    }
  };

  //send notification to  player1 (batting team) for bowler is selected
  const sendNotifyToBattingTeam = (bowlerInfo, round, scoreVal) => {
    // setCount(-1);
    let bowlWithArt =
      Object.keys(bowlingPlayer).length > 0
        ? { ...bowlingPlayer, artifacts: selectedArtifacts }
        : bowlerInfo;
    if (scoreVal == 1 && roomData?.overCompleted) {
      dispatch(setBowlerRecords([...bowlerRecords, bowlWithArt?.nftId]));
    }

    let checkBot = roomData?.isSecondPlayerBot ? 1 : 0;
    let bowlerRound = {};
    if (roomData?.isSecondPlayerBot) {
      bowlerRound = {
        isBotResult: checkBot,
        isScore: scoreVal,
        roomId: playerMatchedData?.roomId,
        socketId: playerBSocketId,
        roundInfo:
          !!round && Object.keys(round).length > 0 ? round : currentRound,
      };
    } else {
      bowlerRound = {
        isScore: scoreVal,
        roomId: playerMatchedData?.roomId,
        socketId: playerBSocketId,
        roundInfo:
          !!round && Object.keys(round).length > 0 ? round : currentRound,
        bowlerInfo: bowlWithArt,
      };
    }

    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: bowlerRound,
      }
    );
  };

  const selectYourPlayer = (
    playerType,
    playerSocketId,
    cardId,
    playerInfo,
    card_Type
  ) => {
    setBoosterDisable(false);
    setCartType(card_Type);
    if (roundInfo?.Inning1?.status == "PROGRESS") {
      let roundInfoPlayer = { inning: "Inning1", round: inningRound };
      setCurrentRound(roundInfoPlayer);
      if (playerType == "BAT" && playerSocketId == socket.id) {
        setYourPlayer(true);
        setShowArtifact(true);
        setBattingPlayer(playerInfo);

        sendNotifyToBowlingTeam(playerInfo, roundInfoPlayer, 0);
        dispatch(
          enableDoneBtn({
            playerInfoData: playerInfo,
            roundInfo: roundInfoPlayer,
          })
        );
        document.body.className = "noBackDrop";
        if (artifactList && artifactList.length > 0) {
          setBattingMessage("Select Booster");
        } else {
          setBattingMessage("");
        }
      }
      if (playerType == "BOWL" && playerSocketId != socket.id) {
        if (roomData?.isBatSelected == 1) {
          if (artifactList && artifactList.length > 0) {
            setBowlingMessage("Select Booster");
          } else {
            setBowlingMessage("");
          }
          setBowlingPlayer(playerInfo);
          dispatch(
            enableDoneBtn({
              playerInfoData: playerInfo,
              roundInfo: roundInfoPlayer,
            })
          );
          sendNotifyToBattingTeam(playerInfo, roundInfoPlayer, 0);
          setYourPlayer(true);
          setShowArtifact(true);
          document.body.className = "noBackDrop";
        } else {
          toast.error("Wait for opponent select the batsman", {
            toastId: "error2",
          });
        }
      }
    }
  };

  //deducted artifact call back
  const artifactCallBack = (data) => {
    if (data?.status == 200) {
      dispatch(getUserArtifacts());
    }
    return null;
  };
  let count = 0;

  useEffect(() => {
    if (selectedArtifacts.length > 0) {
      if (playerASocketId == socket.id) {
        sendNotifyToBowlingTeam(
          "",
          { inning: "Inning1", round: inningRound },
          0
        );
      } else {
        sendNotifyToBattingTeam(
          "",
          { inning: "Inning1", round: inningRound },
          0
        );
      }
    }
  }, [selectedArtifacts]);

  const showArtEffectHandler = (id) => {
    if (
      (batBoosterFirstInning.length > 2 && playerASocketId == socket.id) ||
      (bowlBoosterFirstInning.length > 2 && playerBSocketId == socket.id)
    ) {
      toast.error("You can choose a maximum 3 boosters in a inning", {
        toastId: "error2",
      });
    } else {
      // if (id) {
      if (selectedArtifacts.length < 1) {
        if (playerASocketId == socket.id) {
          dispatch(setBatBosterInningFirst([...batBoosterFirstInning, id]));
        } else if (playerBSocketId == socket.id) {
          dispatch(setBowlBosterInningFirst([...bowlBoosterFirstInning, id]));
        }

        // dispatch(setUseBosterInningFirst([...boosterFirstInning, id]));
        setSelectedArtifacts([...selectedArtifacts, id]);
        dispatch(deductArtifact({ artefact_id: id }, artifactCallBack));
        setBattingMessage("");
        setBowlingMessage("");
      } else {
        toast.error("Choose one booster", {
          toastId: "error1",
        });
      }
      // }
    }
  };

  //change batsman
  const changeBatsman = () => {
    setYourPlayer(false);
    setShowArtifact(false);
    setSelectedArtifacts([]);
    setChangeBat(true);
  };
  //change batsman
  // const continueGame = () => {
  //   setContinueBtn(true);
  //   console.log("changeBatsman", continueBtn);
  // };

  //already played ids
  let batPlayerIds = [];
  let bowlerPlayedIds = [];

  for (let i = 1; i <= 5; i++) {
    let round = "round_" + i;
    if (roundInfo?.Inning1?.[round]?.batInfo) {
      batPlayerIds.push(roundInfo?.Inning1?.[round]?.batInfo?.nftId);
    }
    if (roundInfo?.Inning1?.[round]?.bowlerInfo) {
      bowlerPlayedIds.push(roundInfo?.Inning1?.[round]?.bowlerInfo?.nftId);
    }
  }

  //random batsman selection
  const randomSelectPlayer = (player) => {
    let cardsList = playerData;
    let boosterId = [];

    if (player == "batsman") {
      batPlayerIds &&
        batPlayerIds.length > 0 &&
        batPlayerIds.map((e) => {
          const nftIndex = cardsList.findIndex((item) => item?.nftId == e);
          if (nftIndex !== -1) {
            cardsList.splice(nftIndex, 1);
          }
        });

      const randomIndex = Math.floor(Math.random() * cardsList.length);
      let nftData = cardsList[randomIndex];
      let usedByBatBooster = artifactList.filter(
        (item) => item?.usedByBatsman == 1
      );

      const randomBoosterIndex = Math.floor(
        Math.random() * usedByBatBooster.length
      );

      if (batBoosterFirstInning.length < 3) {
        let artifactId = usedByBatBooster[randomBoosterIndex]?.ds_id;
        setSelectedArtifacts([artifactId]);
        dispatch(deductArtifact({ artefact_id: artifactId }, artifactCallBack));
        dispatch(
          setBatBosterInningFirst([...batBoosterFirstInning, artifactId])
        );
        boosterId = [artifactId];
      }
      let playerInfo = {
        outlineImage: nftData?.outlineImage,
        da_id: nftData?.da_id,
        nftId: nftData?.nftId,
        name: nftData?.title,
        gameTitle: nftData?.gameTitle,
        img: nftData?.nftLogo,
        artifacts: boosterId,
        isArtifact: 0,
      };
      setYourPlayer(true);
      setShowArtifact(true);
      setBattingPlayer(playerInfo);
      setBoosterDisable(true);

      sendNotifyToBowlingTeam(
        playerInfo,
        { inning: "Inning1", round: inningRound },
        0
      );

      setTimeout(() => {
        sendNotifyToBowlingTeam(
          playerInfo,
          { inning: "Inning1", round: inningRound },
          1
        );
      }, 3000);
      if (
        roomData?.RoundsInfo?.Inning1[roomData?.currentRound]?.bowlerInfo !==
        null
      ) {
        setBattingMessage("");
      } else {
        setBattingMessage("Wait for opponent selection");
      }
    } else if (player == "bowler") {
      const toFindDuplicates = bowlerRecords.filter(
        (item, index) => bowlerRecords.indexOf(item) !== index
      );

      //remove duplicate value
      toFindDuplicates &&
        toFindDuplicates.length > 0 &&
        toFindDuplicates.map((e) => {
          const cardsListIndex = cardsList.findIndex(
            (item) => item?.nftId == e
          );
          if (cardsListIndex !== -1) {
            cardsList.splice(cardsListIndex, 1);
          }
        });

      const randomIndex = Math.floor(Math.random() * cardsList.length);
      const nftData = cardsList[randomIndex];
      let usedByBowlBooster = artifactList.filter(
        (item) => item?.usedByBowler == 1
      );
      const randomBoosterIndex = Math.floor(
        Math.random() * usedByBowlBooster.length
      );

      if (bowlBoosterFirstInning < 3) {
        let artifactId = usedByBowlBooster[randomBoosterIndex]?.ds_id;
        setSelectedArtifacts([artifactId]);
        dispatch(deductArtifact({ artefact_id: artifactId }, artifactCallBack));
        dispatch(
          setBowlBosterInningFirst([...bowlBoosterFirstInning, artifactId])
        );

        boosterId = [artifactId];
      }

      let playerInfo = {
        outlineImage: nftData?.outlineImage,
        da_id: nftData?.da_id,
        nftId: nftData?.nftId,
        name: nftData?.title,
        gameTitle: nftData?.gameTitle,
        img: nftData?.nftLogo,
        artifacts: boosterId,
        isArtifact: 0,
      };
      setYourPlayer(true);
      setShowArtifact(true);
      setBowlingPlayer(playerInfo);
      setBoosterDisable(true);
      sendNotifyToBattingTeam(
        playerInfo,
        { inning: "Inning1", round: inningRound },
        0
      );
      setTimeout(() => {
        sendNotifyToBattingTeam(
          playerInfo,
          { inning: "Inning1", round: inningRound },
          1
        );
      }, 3000);
    }

    if (
      roomData?.RoundsInfo?.Inning1[roomData?.currentRound]?.batInfo !== null
    ) {
      setBowlingMessage("");
    } else {
      setBowlingMessage("Wait for opponent selection");
    }
  };

  // console.log("batPlayerIds", batPlayerIds, bowlerPlayedIds);
  return (
    <>
      <div className="Ground">
        <div className="opponentScore">
          {/* show player name and current socre */}
          {!!roomData && (
            <FirstInningScores
              roomData={roomData}
              playerASocketId={playerASocketId}
              socket={socket}
              opponent={true}
            />
          )}
        </div>

        <div className="opponentCard">
          {!!playerMatchedData &&
            !!playerMatchedData?.playerIds &&
            !!playerMatchedData?.playerIds[opponetSocket] &&
            playerMatchedData?.playerIds[opponetSocket].length > 0 && (
              <OpponentCard
                playerMatchedData={playerMatchedData?.playerIds[opponetSocket]}
                // playerBSocketId={playerBSocketId}
              />
            )}
        </div>
        <div className="MainGround">
          <OpponentPlayer
            playersSocketId={playerASocketId}
            roundInfo={
              playerBSocketId == socket.id && roomData?.isBatSelected == 1
                ? roundInfo?.Inning1[roomData?.currentRound]
                : playerASocketId == socket.id
                ? !!roundInfo?.Inning1[roomData?.currentRound]
                  ? roundInfo?.Inning1[roomData?.currentRound]
                  : {}
                : playerBSocketId == socket.id &&
                  roomData?.isBatSelected == 0 &&
                  roomData?.isChanged == 1 &&
                  roundInfo?.Inning1[roomData?.currentRound]?.batInfo != null &&
                  roundInfo?.Inning1[roomData?.currentRound]?.bowlerInfo != null
                ? roundInfo?.Inning1[roomData?.currentRound]
                : {}
            }
            roomData={roomData}
            socket={socket}
            artifactList={artifactList}
            selectedArtifacts={selectedArtifacts}
            checkInningRound={checkInningRound}
          />

          <div className="stadiumName">
            <h2>{roomData?.stadiumName}</h2>
          </div>

          <div className="Pitch">
            {roomData?.RoundsInfo?.Inning1?.status == "PROGRESS" ? (
              playerASocketId == socket.id ? (
                <p className="grondMesage">{battingMessage}</p>
              ) : (
                <p className="grondMesage">{bowlingMessage}</p>
              )
            ) : playerASocketId != socket.id ? (
              <p className="grondMesage">{battingMessage}</p>
            ) : (
              <p className="grondMesage">{bowlingMessage}</p>
            )}
            <img src={pitch} alt="pitch" className="pitch" />
          </div>

          <YourPlayer
            playersSocketId={playerASocketId}
            socket={socket}
            bowlingPlayer={bowlingPlayer}
            battingPlayer={battingPlayer}
            yourPlayer={yourPlayer}
            artifactList={artifactList}
            selectedArtifacts={selectedArtifacts}
            inning="first"
          />
        </div>
      </div>
      <div className="d-flex justify-content-center">
        <div className="PlayerAdd">
          <div className="yourScore">
            {!!roomData && (
              <FirstInningScores
                roomData={roomData}
                playerASocketId={playerASocketId}
                socket={socket}
                opponent={false}
              />
            )}
          </div>

          {!showArtifact && playerData.length > 0 && (
            <YourCards
              batPlayerIds={batPlayerIds}
              bowlerPlayedIds={bowlerPlayedIds}
              playerMatchedData={playerData}
              roomData={roomData}
              roundInfo={roundInfo?.Inning1}
              playerASocketId={playerASocketId}
              playerBSocketId={playerBSocketId}
              socket={socket}
              selectYourPlayer={selectYourPlayer}
              inning="first"
              bowlerRecords={bowlerRecords}
            />
          )}
          {showArtifact && (
            <UserArtifacts
              boosterDisable={boosterDisable}
              selectedArtifacts={selectedArtifacts}
              artifactList={artifactList}
              playerASocketId={playerASocketId}
              playerBSocketId={playerBSocketId}
              inning="first"
              socket={socket}
              disable={true}
              showArtEffectHandler={showArtEffectHandler}
              // boosterFirstInning={boosterFirstInning}
            />
          )}
        </div>
      </div>

      {timeOut && (
        <TimeOutModal
          timeOut={timeOut}
          message={"Time Out"}
          subMessage={"You have not select the player!"}
        />
      )}

      {!!playerMatchedData &&
        roundInfo?.Inning1?.round_1 == null &&
        timerclose && <WaitingModal message={"First Inning"} subMessage={""} />}

      {roundInfo?.Inning1?.round_1 == null && showStartGame && (
        <WaitingModal
          message={"Game about to start"}
          subMessage={
            playerASocketId == socket.id ? "Select Batsman" : "Select Bowler"
          }
        />
      )}

      {WaitModalForScore ? (
        <WaitingModal message={"Wait for score!"} subMessage={""} />
      ) : (
        ""
      )}

      {scoreShow &&
        roomData?.RoundsInfo?.Inning1[roomData?.currentRound]?.batInfo && (
          <ScoreBoredModal
            changeBat={changeBat}
            // continueBtn={continueBtn}
            changeBatsman={changeBatsman}
            // continueGame={continueGame}
            playersSocketId={playerASocketId}
            currentRound={roomData?.currentRound}
            inning="First"
            roomData={roomData}
            roundInfo={roomData?.RoundsInfo?.Inning1[roomData?.currentRound]}
          />
        )}
    </>
  );
}

export default InningFirst;
