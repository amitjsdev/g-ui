import React, { useState, useEffect } from "react";
import Slider from "react-slick";
import ball from "../../assets/images/ball.svg";
import Bat from "../../assets/images/Bat.svg";

const SecondInningScores = React.memo(
  ({ roomData, playerBSocketId, socket, opponent }) => {
    let playedBalls = roomData?.totalBallsPlayedByPlayerB;
    if (playedBalls > 60) {
      playedBalls = 60;
    }
    let overs = parseInt(playedBalls / 6) + "." + (playedBalls % 6);

    return (
      <>
        {opponent ? (
          <>
            <div className="opponent">
              {playerBSocketId != socket.id ? (
                <img src={Bat} alt="Bat" className="Bat" />
              ) : (
                <img src={ball} alt="ball" className="ball" />
              )}

              <h6>
                {playerBSocketId == socket.id
                  ? roomData?.playerAName?.name
                    ? roomData?.playerAName?.name
                    : "Opponent"
                  : roomData?.playerBName?.name
                  ? roomData?.playerBName?.name
                  : "Opponent"}
              </h6>
            </div>
            <div className="score">
              <p>
                Score{" "}
                <span>
                  {playerBSocketId == socket.id ? (
                    <span>Target({roomData?.totalScoreByPlayerA + 1})</span>
                  ) : (
                    `${roomData?.totalScoreByPlayerB}/${
                      roomData?.totalWicketsPlayerB
                    } (${!!overs ? overs : 0})`
                  )}
                </span>
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="your">
              {playerBSocketId == socket.id ? (
                <img src={Bat} alt="Bat" className="Bat" />
              ) : (
                <img src={ball} alt="ball" className="ball" />
              )}

              <h6>
                {playerBSocketId != socket.id
                  ? roomData?.playerAName?.name
                    ? roomData?.playerAName?.name
                    : "You"
                  : roomData?.playerBName?.name
                  ? roomData?.playerBName?.name
                  : "You"}
              </h6>
            </div>
            <div className="score">
              {/* <p>
              Score{" "}
              <span>
                {playerBSocketId != socket.id
                  ? roomData?.totalScoreByPlayerA
                  : roomData?.totalScoreByPlayerB}
              </span>
            </p> */}

              <p>
                Score{" "}
                <span>
                  {playerBSocketId == socket.id ? (
                    `${roomData?.totalScoreByPlayerB}/${
                      roomData?.totalWicketsPlayerB
                    } (${!!overs ? overs : 0})`
                  ) : (
                    <span>Target({roomData?.totalScoreByPlayerA + 1})</span>
                  )}
                </span>
              </p>
            </div>
          </>
        )}
      </>
    );
  },
  (prevProps, nextProps) => {
    // const A = JSON.stringify(prevProps);
    // const B = JSON.stringify(nextProps);
    // return (
    //   A === B
    //   // prevProps?.roundResult?.length === nextProps?.roundResult?.length &&
    //   // prevProps.selectedCard === nextProps.selectedCard
    // );
  }
);

export default SecondInningScores;
