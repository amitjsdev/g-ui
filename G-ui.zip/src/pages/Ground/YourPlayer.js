import React, { useState, useEffect } from "react";
import hardik from "../../assets/images/hardik.png";

const YourPlayer = React.memo(
  ({
    playersSocketId,
    socket,
    yourPlayer,
    bowlingPlayer,
    battingPlayer,
    selectedArtifacts,
    artifactList,
    inning
  }) => {
    return (
      <>
        <div className="BoosterYour">
          {selectedArtifacts &&
            selectedArtifacts.length > 0 &&
            selectedArtifacts.map((id, index) => {
              let findBooster =
                artifactList &&
                artifactList.length > 0 &&
                artifactList.find((item) => item.ds_id == id);
              return (
                <div key={index} className={`firstball ${playersSocketId == socket.id ? "bat_icon" : "bowl_icon" }`}>
                  <img src={findBooster?.image} alt={findBooster?.title} />
                </div>
              );
            })}
        </div>
        <div className="selectbal">
          {/* <img src={Rocket} alt="Rocket" /> */}
        </div>
        <div className="thirdbal">
          {/* <img src={ballfire} alt="ballfire" /> */}
        </div>
        <div className="YourPlayer">
          {yourPlayer ? (
            playersSocketId == socket.id ? (
              <img
                src={
                  battingPlayer && Object.keys(battingPlayer).length > 0
                    ? battingPlayer?.outlineImage
                    : hardik
                }
                alt="Virat"
                className="playicon playerImg"
              />
            ) : (
              <img
                src={
                  bowlingPlayer && Object.keys(bowlingPlayer).length > 0
                    ? bowlingPlayer?.outlineImage
                    : hardik
                }
                alt="Virat"
                className="playicon playerImg"
              />
            )
          ) : (
            <img
              src={hardik}
              alt="hardik"
              className="showVir playicon playerImg"
            />
          )}
          <h3>
            {playersSocketId == socket.id
              ? battingPlayer?.gameTitle
              : bowlingPlayer?.gameTitle}
          </h3>
        </div>
      </>
    );
  },
  (prevProps, nextProps) => {
    // const A = JSON.stringify(prevProps);
    // const B = JSON.stringify(nextProps);
    // return (
    //   A === B
    //   // prevProps?.roundResult?.length === nextProps?.roundResult?.length &&
    //   // prevProps.selectedCard === nextProps.selectedCard
    // );
  }
);

export default YourPlayer;
