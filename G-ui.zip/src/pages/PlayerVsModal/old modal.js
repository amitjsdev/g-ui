<Modal.Body className="LookOppo">
    <div className="playerMatch">
        <h3 className="text-center">Game Starting</h3>
        <div className="Cards">
            <div className="Player">
                <div className="Match">
                    {/* <img src={Bat} alt="Bat" className="Bat" /> &nbsp; &nbsp; */}
                    <h6>
                        {socket.id === playerMatchedData?.playerASocketId
                            ? playerMatchedData?.playerAName?.name
                                ? playerMatchedData?.playerAName?.name
                                : "You"
                            : playerMatchedData?.playerBName?.name
                                ? playerMatchedData?.playerBName?.name
                                : "You"}{" "}
                    </h6>
                </div>
                <img
                    src={
                        socket.id === playerMatchedData?.playerASocketId
                            ? playerMatchedData?.playerAName?.profile_image
                                ? playerMatchedData?.playerAName?.profile_image
                                : Avtar
                            : playerMatchedData?.playerBName?.profile_image
                                ? playerMatchedData?.playerBName?.profile_image
                                : Avtar
                    }
                    alt="ViratVe"
                    className="ViratVe"
                />
            </div>
            <div className="vs">
                {/* <img src={vs} alt="vs" className="vs" /> */}
                <Lottie
                    options={timeAnimation}
                    height={250}
                    className="changes"
                />
            </div>
            <div className="Player_Opponent">
                <div className="Match">
                    {/* <img src={ball} alt="Bat" className="ball" /> &nbsp; &nbsp; */}
                    <h6>
                        {socket.id !== playerMatchedData?.playerASocketId
                            ? playerMatchedData?.playerAName?.name
                                ? playerMatchedData?.playerAName?.name
                                : "Opponent"
                            : playerMatchedData?.playerBName?.name
                                ? playerMatchedData?.playerBName?.name
                                : "Opponent"}
                    </h6>
                </div>
                <img
                    src={
                        socket.id !== playerMatchedData?.playerASocketId
                            ? playerMatchedData?.playerAName?.profile_image
                                ? playerMatchedData?.playerAName?.profile_image
                                : Avtar
                            : playerMatchedData?.playerBName?.profile_image
                                ? playerMatchedData?.playerBName?.profile_image
                                : Avtar
                    }
                    alt="Kane"
                    className="Kane"
                />
            </div>
        </div>
        <div className="GroundImage">
            <h3>{playerMatchedData?.stadiumName}</h3>
            <div className="stadium">
                <img
                    src={
                        playerMatchedData?.stadiumImage
                            ? playerMatchedData?.stadiumImage
                            : Stadium
                    }
                    alt="Stadium"
                />
            </div>
        </div>
        {/* <div className='Playgame'>
                            <button>
                                Play Now
                            </button>
                        </div> */}
    </div>
</Modal.Body>