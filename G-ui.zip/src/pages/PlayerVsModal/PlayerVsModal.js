import React, { useState } from "react";
import Stadium from "../../assets/images/Stadium.png";
import ViratVe from "../../assets/images/ViratVe.png";
import Avtar from "../../assets/images/avtar.png";
import Kane from "../../assets/images/Kane2.png";
// import Bat from "../../assets/images/Bat.svg";
// import ball from "../../assets/images/ball.svg";
import vs from "../../assets/images/vs.png";
import "./PlayerVsModal.scss";
import { Modal } from "react-bootstrap";
import Lottie from "react-lottie";
import * as animationData from "../../assets/images/VSjson.json";

function PlayerVsModal({ showVsModal, matchedData, socket }) {
  let playerMatchedData = matchedData?.roomData;
  // const timerclose = () => setShowVsModal(false);
  const timeAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  return (
    <>
      <Modal
        // className="second"
        show={showVsModal}
        centered={true}
        className="PlayerMatch"
        // onHide={timerclose}
      >
        {/* second modal */}

        <Modal.Body className="LookOppo">
          <div className="playerMatch">
            <h3 className="text-center">Game Starting</h3>
            <div className="GroundImage">
              <h3>{playerMatchedData?.stadiumName}</h3>
              <div className="stadium">
                <img
                  src={
                    playerMatchedData?.stadiumImage
                      ? playerMatchedData?.stadiumImage
                      : Stadium
                  }
                  alt="Stadium"
                />
              </div>
            </div>
            <div className="heading">
              <h4>{playerMatchedData?.stadiumDesc}</h4>
            </div>
            <div className="Cards">
              <div className="Player">
                <div className="Match">
                  {/* <img src={Bat} alt="Bat" className="Bat" /> &nbsp; &nbsp; */}
                  <h6>
                    {socket.id === playerMatchedData?.playerASocketId
                      ? playerMatchedData?.playerAName?.name
                        ? playerMatchedData?.playerAName?.name
                        : "You"
                      : playerMatchedData?.playerBName?.name
                      ? playerMatchedData?.playerBName?.name
                      : "You"}{" "}
                  </h6>
                </div>
                <div className="Profile_Image">
                  <img
                    src={
                      socket.id === playerMatchedData?.playerASocketId
                        ? playerMatchedData?.playerAName?.profile_image
                          ? playerMatchedData?.playerAName?.profile_image
                          : Avtar
                        : playerMatchedData?.playerBName?.profile_image
                        ? playerMatchedData?.playerBName?.profile_image
                        : Avtar
                    }
                    alt="ViratVe"
                    className="ViratVe"
                  />
                </div>
              </div>
              <div className="vs">
                {/* <img src={vs} alt="vs" className="vs" /> */}
                <Lottie
                  options={timeAnimation}
                  height={250}
                  className="changes"
                />
              </div>
              <div className="Player_Opponent">
                <div className="Match">
                  {/* <img src={ball} alt="Bat" className="ball" /> &nbsp; &nbsp; */}
                  <h6>
                    {socket.id !== playerMatchedData?.playerASocketId
                      ? playerMatchedData?.playerAName?.name
                        ? playerMatchedData?.playerAName?.name
                        : "Opponent"
                      : playerMatchedData?.playerBName?.name
                      ? playerMatchedData?.playerBName?.name
                      : "Opponent"}
                  </h6>
                </div>
                <img
                  src={
                    socket.id !== playerMatchedData?.playerASocketId
                      ? playerMatchedData?.playerAName?.profile_image
                        ? playerMatchedData?.playerAName?.profile_image
                        : Avtar
                      : playerMatchedData?.playerBName?.profile_image
                      ? playerMatchedData?.playerBName?.profile_image
                      : Avtar
                  }
                  alt="Kane"
                  className="Kane"
                />
              </div>
            </div>
            {/* <div className='Playgame'>
                            <button>
                                Play Now
                            </button>
                        </div> */}
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default PlayerVsModal;
