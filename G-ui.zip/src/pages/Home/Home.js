import React, { useEffect, useState } from "react";
import greeCirc from "../../assets/images/greeCirc.svg";
import EpicGround from "../../assets/images/Stadium/EpicGround.png";
import RareGround from "../../assets/images/Stadium/RareGround.png";
import SuperRareGround from "../../assets/images/Stadium/SuperRareGround.png";
import RangeSlider from "../../components/Range/RangeSlider";
import Slider from "react-slick";
import { Link, useNavigate } from "react-router-dom";
import "./Home.scss";
import {
  setCurrentStadiumRarity,
  startCountDown,
  matchedData,
} from "../../redux/user/action";
import { useDispatch, useSelector } from "react-redux";
import { getStadiumList, getLastFivePlayer } from "../../redux/user/action";
import socket from "../../socket";
import { getToken } from "../../Helpers/storageHelper";
import { ACCESS_TOKEN } from "../../utils/constant";
import MatchingModal from "../../modals/MatchingModal";
import * as animationData from "../../assets/images/Planet.json";
import { toast } from "react-toastify";
function Home() {
  let timerCount = 30;

  const dispatch = useDispatch();
  const [stadiumData, setStadiumData] = useState([]);
  const [initialised, setInitialised] = useState(false);
  const [onlineUser, setOnlineUser] = useState({});
  const [socketInitialized, setSocketrInitialized] = useState(false);
  const [intervalIntialized, setIntervalIntialized] = useState(false);
  const [opponent, setOpponent] = useState(false);
  const [socketId, setSocketId] = useState(socket.id);
  const [counterEnable, setCounterEnable] = useState(false);

  const stadiumRarity = useSelector(
    (state) => state?.userReducer?.currentStadiumRarity
  );

  let stadiumCategory = [
    { rarity: "Rare", color: "orangeColor", img: RareGround, online: "Rare" },
    { rarity: "Epic", color: "redColor", img: EpicGround, online: "Epic" },
    {
      rarity: "SuperRare",
      color: "blueColor",
      img: SuperRareGround,
      online: "Common",
    },
  ];

  let settings = {
    dots: false,
    arrows: true,
    centerMode: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    afterChange: (current) => {
      let val = stadiumCategory[current]?.rarity;
      if (val) {
        dispatch(setCurrentStadiumRarity(val));
      }
    },
  };

  const timeAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  const [currentCount, setCount] = useState(0);
  let timeToLapse = timerCount;

  let pMInterval = null;
  useEffect(() => {
    if (counterEnable) {
      if (currentCount < 1) {
        if (pMInterval) {
          clearInterval(pMInterval);
        }
        if (opponent) {
          setOpponent(false);
          toast.error("Opponent not available, try again later", {
            toastId: "errorHome1",
          });

          setCounterEnable(false);
        }
        return;
      } else if (currentCount === 25) {
        socketFunc(true);
        // setCountDown(currentCount);
      }
      if (!intervalIntialized) {
        pMInterval = setInterval(() => {
          // console.log("pmInterval", pMInterval, currentCount, timeToLapse);
          timeToLapse -= 1;
          if (timeToLapse === 0) {
            if (pMInterval) {
              clearInterval(pMInterval);
              setIntervalIntialized(false);
            }
          }
          setCount(timeToLapse);
        }, 1000);
        setIntervalIntialized(true);
      }
    }
  }, [currentCount]);

  //get last five player according to stadium
  // const callbackLastFivePlayer = (data) => {
  //   if (data) {
  //     let res = data?.data?.nfts;
  //     return setLastFivePlayer(res);
  //   }
  //   return null;
  // };

  //get list direct from generator function
  const callback = async (data) => {
    if (data) {
      let res = data?.data?.nfts;
      let val = res && res.length > 0 && res[0];
      // dispatch(
      //   getLastFivePlayer({ stadium_id: val?.nftId }, callbackLastFivePlayer)
      // );
      await dispatch(setCurrentStadiumRarity(stadiumCategory[0]?.rarity));
      await dispatch(startCountDown(0));
      return setStadiumData(res);
    }
    return null;
  };

  const fetchStadiumList = async () => {
    let param = {
      mintType: "STADIUM",
    };
    await dispatch(getStadiumList(param, callback));
    // dispatch(getLastFivePlayer(callbackLastFivePlayer));
  };
  let interval = null;
  useEffect(() => {
    interval = setInterval(() => {
      if (!socket?.id) {
        socket.connect();
      } else if (interval) {
        setSocketId(socket?.id);
        clearInterval(interval);
      }
    }, 1000);
    if (stadiumData && stadiumData.length == 0) {
      fetchStadiumList();
    }
    return () => {
      if (pMInterval) {
        clearInterval(pMInterval);
      }
    };
  }, []);

  useEffect(() => {
    if (!!socket?.id && !socketInitialized) {
      socket.emit("get_online_users", {});
      socket.on(`online_user_${socket?.id}`, (data) => {
        setOnlineUser(data?.data);
      });
      socket.on("online_users", (data) => {
        setOnlineUser(data?.data);
      });
      setSocketrInitialized(true);
    }
  }, [socket?.id]);

  let navigate = useNavigate();

  const socketFunc = async (key) => {
    socket.emit(key ? "play_bot_game_cric5" : "play_game_cric5", {
      token: getToken(ACCESS_TOKEN),
      amount: 0,
      rarity: stadiumRarity,
      players: [],
      isConfirmd: 0,
    });
    setInitialised(true);
    if (!counterEnable) {
      setCounterEnable(true);
      setOpponent(true);
      setCount(timerCount);
      // setInitialised(true);
    }
  };

  useEffect(() => {
    dispatch(matchedData(""));
    if (initialised) {
      let joined = false;
      socket.removeListener("game_status");
      socket.removeListener("match_detail");
      socket.on("game_status", (data) => {
        if (data.status === "waiting") {
          socket.emit("join_game_room", {
            roomId: data.roomId,
          });
          joined = true;
        } else if (data.status === "processing" && !joined) {
          socket.emit("join_game_room", {
            roomId: data.roomId,
          });
          if (pMInterval) {
            clearInterval(pMInterval);
          }
        } else if (data.error) {
          setCounterEnable(false);
          setIntervalIntialized(false);
          setOpponent(false);
          setCount(0);
          toast.error(data.status, {
            toastId: "errorHome2",
          });
          if (pMInterval) {
            clearInterval(pMInterval);
          }
        }
      });

      socket.on("match_detail", (data) => {
        // console.log("match_detail", data);
        setOpponent(false);
        dispatch(matchedData(data));
        navigate("/build-team");
      });
      setInitialised(false);
    } else {
      //   socket.emit("disconnect", {
      //     socketId: socket.id
      //  });
    }
  }, [initialised]);

  return (
    <>
      <MatchingModal
        countDown={currentCount}
        opponent={opponent}
        timeAnimation={timeAnimation}
      />

      <div className="homeEdit">
        <div className="sliderWrap">
          <p className="stadimHeading">Select Stadium Rarity</p>
          <Slider {...settings}>
            {stadiumCategory &&
              stadiumCategory.length > 0 &&
              stadiumCategory.map((item, index) => {
                return (
                  <div className={`grounImage`} key={index}>
                    <div
                      className={`Stadium_Image ${stadiumCategory[index]?.color}`}
                    >
                      <img
                        src={stadiumCategory[index]?.img}
                        alt="ground"
                        className="ground"
                      />
                    </div>
                    <div className="texting">
                      <h1>{stadiumCategory[index]?.rarity}</h1>
                      <p>
                        <img
                          src={greeCirc}
                          alt="greeCirc"
                          className="grreCirc"
                        />{" "}
                        &nbsp;{" "}
                        {onlineUser?.[stadiumCategory[index]?.online]
                          ? onlineUser?.[stadiumCategory[index]?.online]
                          : 0}{" "}
                        Online
                      </p>
                    </div>
                  </div>
                );
              })}
          </Slider>
        </div>
        {/* <div className="listingFile">
        <ul>
          {lastFivePlayer &&
            lastFivePlayer.length > 0 &&
            lastFivePlayer.map((item) => {
              return (
                <li>
                  <img src={item?.nftLogo} alt="Virat" className="showVir" />
                </li>
              );
            })}
        </ul>
      </div> */}
        {/* <div className="rangebar">
          <RangeSlider />
        </div> */}
        <div className="editbutton">
          {!!socket.id ? (
            <button onClick={() => socketFunc()}>Free Play</button>
          ) : (
            <button disabled={true}>Please wait...</button>
          )}
        </div>
      </div>
    </>
  );
}

export default Home;
