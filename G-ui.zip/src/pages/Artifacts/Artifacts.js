import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./artifacts.scss";
import {
  getArtifactsList,
  buyArtifacts,
  getUserArtifacts,
} from "../../redux/user/action";
import { useDispatch, useSelector } from "react-redux";
import ballfire from "../../assets/images/ballfire.gif";
import BuyModal from "./BuyModal";

function Artifacts() {
  let navigate = useNavigate();
  const dispatch = useDispatch();
  const [artifactList, setArtifactList] = useState();
  const [quantity, setQuantity] = useState(1);
  const [artifactItem, setArtifactItem] = useState({});
  const [showModal, setShowModal] = useState(false);

  const stadium = useSelector((state) => state?.userReducer?.currentStadium);

  const userArtifacts = useSelector(
    (state) => state?.userReducer?.userArtifacts
  );

  // if(!stadium?.nftId){
  //   navigate("/");
  // }

  const callback = (data) => {
    if (data) {
      dispatch(getUserArtifacts());
      setArtifactList(data?.data);
    }
    return null;
  };

  const buyCallback = (data) => {
    if (data?.status == 200) {
      dispatch(getUserArtifacts());
    }
    return null;
  };

  const fetchArtifactList = async () => {
    dispatch(getArtifactsList(callback));
  };

  const buyArtifact = (item) => {
    let artifact = {
      artefact_id: item.ds_id.toString(),
      quantity: quantity.toString(),
      image: item.image,
      title: item.title,
      price: item.price.toString(),
      isactive: item.isActive ? 1 : 0,
      usedByBatsman: item.usedByBatsman,
      usedByBowler: item.usedByBowler,
    };

    dispatch(buyArtifacts(artifact, buyCallback));

    // saveArtefacts;
  };

  const handleChangeInput = (e) => {
    setQuantity(e.target.value);
  };

  useEffect(() => {
    fetchArtifactList();
  }, []);

  return (
    <>
      <div className="BuildTeam">
        <h3>BOOSTERS</h3>
        <div className="country">
          <div className="imagepick arift">
            {artifactList &&
              artifactList.length > 0 &&
              artifactList?.map((item, index) => {
                let artifactCount =
                  userArtifacts &&
                  userArtifacts.length > 0 &&
                  userArtifacts.find(
                    (artItem) => artItem.artefact_id == item.id
                  );

                let count = !!artifactCount?.quantity
                  ? artifactCount?.quantity
                  : 0;

                return (
                  <div className="first" key={index}>
                    <div className="booster_arti">
                      <span>{count}</span>
                      <div className="artifi_booster">
                        <img src={item?.image} alt="ballfire" />
                      </div>
                    </div>
                    <p>{item?.title}</p>
                    <button
                      onClick={() => {
                        setShowModal(true);
                        setArtifactItem(item);
                        setQuantity(1);
                      }}
                      className="buyBtn"
                    >
                      Buy
                    </button>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      {showModal && (
        <BuyModal
          quantity={quantity}
          artifactItem={artifactItem}
          handleChangeInput={handleChangeInput}
          setShowModal={setShowModal}
          buyArtifact={buyArtifact}
        />
      )}
    </>
  );
}

export default Artifacts;
