import React from "react";
import { Modal } from "react-bootstrap";

function BuyModal({
  quantity,
  artifactItem,
  handleChangeInput,
  setShowModal,
  buyArtifact,
}) {
  // const leaveGame = () => {
  //     window.location.replace('/')
  //   }
  return (
    <Modal
      className="second"
      show={true}
      centered={true}
      onHide={() => {
        setShowModal(false);
      }}
    >
      <Modal.Body className="LookOppo">
        <div className="looking">
          <div className="opponent waitng">
            <div className="artifactselect">
              <img src={artifactItem?.image} alt="KL_Rahul" />
            </div>
            <input
              onChange={handleChangeInput}
              type="number"
              value={quantity}
              min={1}
            />
            <p className="buyPrice">Price: {artifactItem?.price}</p>
            <p className="buyPrice">{artifactItem?.title}</p>
          </div>
          <div className="btns">
            <button
              disabled={quantity < 1}
              onClick={() => {
                buyArtifact(artifactItem);
                setShowModal(false);
              }}
              className="buyBtnModal"
            >
              Buy
            </button>

            <button
              onClick={() => {
                setShowModal(false);
              }}
              className="buyBtnModal cancel"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

export default BuyModal;
