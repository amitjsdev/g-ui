import React from 'react';
import Modalcard from './Modal/Modalcard';
import "./Cardinfo.scss";

const Cardinfo = () => {
    return (
        <>
            <Modalcard />
        </>
    )
}

export default Cardinfo