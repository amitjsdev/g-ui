import React, { useEffect, useState } from 'react';
import { Button, Modal } from 'react-bootstrap';
import "../Cardinfo.scss";
import PlayerCard from "../../../assets/images/PlayerCard.png";
import { getStadiumList } from '../../../redux/user/action';
import { useDispatch, useSelector } from "react-redux";

const Modalcard = ({show,playerStats,handleClose}) => {
  
   

    const fifty='50s'
    const hundred='100s'
    return (
        <>
           

                <Modal show={show} onHide={handleClose} centered className='cardModal'>
                    <div className="bgdetails">
                        <Modal.Header closeButton>
                            <Modal.Title></Modal.Title>
                        </Modal.Header>
                        <Modal.Body>
                           
                              <div className='Containt'>
                              <div className='cardImg'>
                                  <img src={playerStats?.nftLogo} alt="PlayerCard" />
                              </div>
                              <div className='scoreBorde'>
                              <ul>
                                            <li>
                                          <h4>{playerStats?.stats[0]?.Runs}</h4>
                                          <p>Runs</p>
                                          </li>
                                          <li>
                                          <h4>{playerStats?.stats[0]?.Inns}</h4>
                                          <p>Matches</p>
                                      </li>
                                      <li>
                                          <h4>{playerStats?.stats[0]?.[fifty]}/{playerStats?.stats[0]?.[hundred]}</h4>
                                          <p>50/100</p>
                                      </li>
                                      <li>
                                          <h4></h4>
                                          <p>Highest Score</p>
                                      </li>
                                      <li>
                                          <h4>{playerStats?.stats[0]?.SR}</h4>
                                          <p>Strike Rate</p>
                                      </li>
                                      <li>
                                          <h4>{playerStats?.stats[0]?.Avg}</h4>
                                          <p>Batting Avg</p>
                                      </li>
                                      </ul>
                                      
                                         
                                     
                              </div>
                          </div> 
                        </Modal.Body>
                    </div>
                </Modal>
            
        </>
    )
}

export default Modalcard