import React, { useState, useEffect } from "react";
import "./YouWon.scss";
import { useSelector } from "react-redux";
import TimeOutModal from "../../modals/TimeOutModal";

function MatchTie() {
  const playerMatchedData = useSelector(
    (state) => state?.userReducer?.matchedData
  );
  useEffect(() => {
    if (!playerMatchedData) {
      window.location.replace("/");
      return;
    }
  }, []);

  return (
    <div>
      <TimeOutModal />
    </div>
  );
}

export default MatchTie;
