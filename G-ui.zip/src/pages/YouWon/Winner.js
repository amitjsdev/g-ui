import React, { useState, useEffect } from "react";
import "./winner.scss";
import Stadium from "../../assets/images/Stadium.png";
import boostTimer from "../../assets/images/boostTimer.png";
import BowledCoin from "../../assets/images/BowledCoin.png";
import wallet_black from "../../assets/images/wallet_black.svg";
import flash from "../../assets/images/flash.png";
import Matchsummary from "./MatchSummary/Matchsummary";
import { useDispatch, useSelector } from "react-redux";
import socket from "../../socket";
import { useNavigate } from "react-router-dom";

const Winner = () => {
  let navigate = useNavigate();

  const playerMatchedData = useSelector(
    (state) => state?.userReducer?.matchedData
  );
  useEffect(() => {
    if (!playerMatchedData) {
      window.location.replace("/");
      return;
    }
  }, []);

  if (!playerMatchedData) {
    navigate("/");
    return;
  }
  const navigateHome = () => {
    window.location.replace("/");
  };

  let roomData = playerMatchedData?.data?.roomData;
  console.log(roomData);
  let playerASocketId = roomData?.playerASocketId;
  let playerBSocketId = roomData?.playerBSocketId;

  return (
    <>
      <div className="wiiner">
        <div className="winntr">
          <img src={flash} alt="flash" />
        </div>
        <div className="stad">
          <img src={Stadium} alt="Stadium" />
        </div>
        <div className="screening">
          <div className="winning">
            <h6>
              You Won
              <img src={boostTimer} alt="boostTimer" />
            </h6>
          </div>
          <div className="scoreing">
            {playerASocketId == socket.id &&
            roomData?.WinnerId == playerASocketId ? (
              <h5>
                {!!roomData?.playerAName?.name
                  ? `Team ${roomData?.playerAName?.name} `
                  : "You "}
                won by{" "}
                {+roomData?.totalScoreByPlayerA -
                  +roomData?.totalScoreByPlayerB ==
                1
                  ? "1 Run."
                  : `${
                      roomData?.totalScoreByPlayerA -
                      roomData?.totalScoreByPlayerB
                    } Runs.`}
              </h5>
            ) : playerBSocketId == socket.id &&
              roomData?.WinnerId == playerBSocketId ? (
              <h5>
                {!!roomData?.playerBName?.name
                  ? `Team ${roomData?.playerBName?.name} `
                  : "You "}
                won by {5 - +roomData?.totalWicketsPlayerB} wicket.
              </h5>
            ) : (
              ""
            )}
            {/* <h5>You: <span>204/2 in 9.2 overs</span></h5>
                        <h5>Opponent: <span>201/3 in 10 overs</span></h5> */}
            <div className="Earbed">
              <h5>
                Earned: <span>0 RUN$</span>{" "}
                <img src={BowledCoin} alt="BowledCoin" />
              </h5>
            </div>
          </div>
          {/* <div className='wallet'>
                        <img src={wallet_black} alt="wallet_black" />
                        <div>
                            <h6>1268 RUN$</h6>
                            <p>₹2365.33</p>
                        </div>
                    </div> */}
          <div className="PlayButton">
            <button onClick={navigateHome} className="playingbtn shake">
              Play Again
            </button>
          </div>
        </div>
        <Matchsummary playerMatchedData={playerMatchedData?.data} />
      </div>
    </>
  );
};

export default Winner;
