import React from "react";
import { Col, Row } from "react-bootstrap";
import "./Matchsummary.scss";
import { useSelector } from "react-redux";

const Matchsummary = ({ playerMatchedData }) => {
  const roomData = playerMatchedData?.roomData;
  const playerAName = roomData?.playerAName?.name;
  const playerBName = roomData?.playerBName;
  const totalBallsPlayedByPlayerA = roomData?.totalBallsPlayedByPlayerA;
  const totalBallsPlayedByPlayerB = roomData?.totalBallsPlayedByPlayerB;
  const totalOversByPlayerA = (
    Number(totalBallsPlayedByPlayerA) / 6 +
    (Number(totalBallsPlayedByPlayerA) % 6) / 10
  ).toFixed(1);
  const totalOversByPlayerB = (
    Number(totalBallsPlayedByPlayerB) / 6 +
    (Number(totalBallsPlayedByPlayerB) % 6) / 10
  ).toFixed(1);

  const roundsInfo1 = [];
  const roundsInfo2 = [];
  roundsInfo1.push(
    roomData?.RoundsInfo?.Inning1?.round_1,
    roomData?.RoundsInfo?.Inning1?.round_2,
    roomData?.RoundsInfo?.Inning1?.round_3,
    roomData?.RoundsInfo?.Inning1?.round_4,
    roomData?.RoundsInfo?.Inning1?.round_5
  );
  roundsInfo2.push(
    roomData?.RoundsInfo?.Inning2?.round_1,
    roomData?.RoundsInfo?.Inning2?.round_2,
    roomData?.RoundsInfo?.Inning2?.round_3,
    roomData?.RoundsInfo?.Inning2?.round_4,
    roomData?.RoundsInfo?.Inning2?.round_5
  );

  const filteredArrayforInning1 = roundsInfo1.filter((el) => el != null);
  const filteredArrayforInning2 = roundsInfo2.filter((el) => el != null);

  const x = roomData?.matchSummaryBowlerIng1.reduce((accu, r) => {
    const { score, nftId, wicketOut, balls, name } = r;
    accu[nftId] = accu[nftId] || {
      score: 0,
      wicketOut: 0,
      balls: 0,
      nftId,
      name,
    };
    accu[nftId].score += score;
    accu[nftId].wicketOut += wicketOut;
    accu[nftId].balls += balls;
    return accu;
  }, {});
  const bowlerData1 = Object.values(x);
  console.log(bowlerData1);
  console.log(filteredArrayforInning1);
  const y = roomData?.matchSummaryBowlerIng2.reduce((accu, r) => {
    const { score, nftId, wicketOut, balls, name } = r;
    accu[nftId] = accu[nftId] || {
      score: 0,
      wicketOut: 0,
      balls: 0,
      nftId,
      name,
    };
    accu[nftId].score += score;
    accu[nftId].wicketOut += wicketOut;
    accu[nftId].balls += balls;
    return accu;
  }, {});
  const bowlerData2 = Object.values(y);
  console.log(bowlerData2);
  let sortForBat1 = filteredArrayforInning1.sort((a, b) =>
    a.score < b.score ? 1 : -1
  );

  if (filteredArrayforInning1.length > 2) {
    filteredArrayforInning1.splice(2);
  }
  console.log(roundsInfo1);
  console.log(filteredArrayforInning1);

  let sortForBowl1 = bowlerData1.sort((a, b) =>
    a.wicketOut < b.wicketOut
      ? 1
      : a.wicketOut === b.wicketOut
        ? a.score > b.score
          ? 1
          : -1
        : -1
  );
  if (bowlerData1.length > 2) {
    bowlerData1.splice(2);
  }
  console.log(bowlerData1);
  let sortForBat2 = filteredArrayforInning2.sort((a, b) =>
    a.score < b.score ? 1 : -1
  );
  if (filteredArrayforInning2.length > 2) {
    filteredArrayforInning2.splice(2);
  }
  console.log(roundsInfo2);
  console.log(filteredArrayforInning2);
  let sortForBowl2 = bowlerData2.sort((a, b) =>
    a.wicketOut < b.wicketOut
      ? 1
      : a.wicketOut === b.wicketOut
        ? a.score > b.score
          ? 1
          : -1
        : -1
  );
  if (bowlerData2.length > 2) {
    bowlerData2.splice(2);
  }
  return (
    <>
      <div className="matchSummary">
        <div className="heading">
          <h5>Match Summary</h5>
        </div>
        <div className="teamone">
          <h5>
            First Inning :{" "}
            <span>
              {roomData?.totalScoreByPlayerA}/{roomData?.totalWicketsPlayerA}
            </span>{" "}
            in <span>{totalOversByPlayerA} overs</span>
          </h5>
          <Row className="mb-5">
            <Col md={6} xs={6}>
              {filteredArrayforInning1.map((batsman, index) => {
                return (
                  <div className="playerdeta" key="index">
                    <h6>{batsman.batInfo?.gameTitle.split(" ")[0]}</h6>
                    <h6>
                      {batsman?.score}
                      {batsman.WicketOut === 0 ? <span>*</span> : ""}(
                      {batsman?.ballsPlayed})
                    </h6>
                  </div>
                );
              })}
            </Col>
            <Col md={6} xs={6}>
              {bowlerData1.map((bowler, index) => {
                return (
                  <div className="playerdeta">
                    <h6>{bowler?.name.split(" ")[0]}</h6>
                    <h6>
                      {(
                        Number(bowler?.balls) / 6 +
                        (Number(bowler?.balls) % 6) / 10
                      ).toFixed(1)}
                      -{bowler?.score}-{bowler?.wicketOut}
                    </h6>
                  </div>
                );
              })}
            </Col>
          </Row>
          <h5>
            Second Inning :{" "}
            <span>
              {roomData?.totalScoreByPlayerB}/{roomData?.totalWicketsPlayerB}
            </span>{" "}
            in <span>{totalOversByPlayerB} overs</span>
          </h5>
          <Row>
            <Col md={6} xs={6}>
              {filteredArrayforInning2.map((batsman, item) => {
                return (
                  <div className="playerdeta" key="item">
                    <h6>{batsman.batInfo?.gameTitle.split(" ")[0]}</h6>
                    <h6>
                      {batsman?.score}
                      {batsman.WicketOut === 0 ? <span>*</span> : ""}(
                      {batsman?.ballsPlayed})
                    </h6>
                  </div>
                );
              })}
            </Col>
            <Col md={6} xs={6}>
              {bowlerData2.map((bowler, index) => {
                return (
                  <div className="playerdeta">
                    <h6>{bowler?.name.split(" ")[0]}</h6>
                    <h6>
                      {(
                        Number(bowler?.balls) / 6 +
                        (Number(bowler?.balls) % 6) / 10
                      ).toFixed(1)}
                      -{bowler?.score}-{bowler?.wicketOut}
                    </h6>
                  </div>
                );
              })}
            </Col>
          </Row>
        </div>
      </div>
    </>
  );
};

export default Matchsummary;
