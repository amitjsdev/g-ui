import React, { useState, useEffect } from "react";
import trphy from "../../assets/images/trphy.png";
import wonBg from "../../assets/images/wonBg.png";
import ground from "../../assets/images/ground.png";
import "./YouWon.scss";
import { Button, Modal } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import socket from "../../socket";
import feedback from "../../assets/images/feedback.png";
import Matchsummary from "./MatchSummary/Matchsummary";

function MatchTie() {
  const [show, setShow] = useState(true);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  let navigate = useNavigate();
  const playerMatchedData = useSelector(
    (state) => state?.userReducer?.matchedData
  );
  useEffect(() => {
    if (!playerMatchedData) {
      window.location.replace("/");
      return;
    }
  }, []);

  const navigateHome = () => {
    window.location.replace("/");
  };

  let roomData = playerMatchedData?.data?.roomData;
  console.log(roomData)
  let playerASocketId = roomData?.playerASocketId;
  let playerBSocketId = roomData?.playerBSocketId;

  return (
    <div>
      <Modal show={show} onHide={handleClose} className="WinningScreens">
        <Modal.Body>
          <div className="YouWon">
            <div className="groungWon">
              <div className="grou">
                <div className="trophy">
                  <img src={trphy} alt="trphy" className="trphy" />
                </div>
                <div className="won_ground_img">
                  <div className="Won">
                    <img src={wonBg} alt="wonBg" className="wonBg" />
                    <h3>Match Tie</h3>
                  </div>

                  <div className="stadiam_Selected">
                    <img src={ground} alt="ground" className="ground" />
                  </div>
                  {/* <img src={ground} alt="ground" className="ground" />
                                    <div className='YourScore'>
                                        <h4>Your Score</h4>
                                    </div> */}
                </div>
              </div>

              <div className="scoretotal">
                <div className="scoreDetails">
                  <div className="YourScore">
                    <h4>Your Score</h4>
                  </div>
                  <div className="score">
                    <h2>
                      {playerASocketId == socket.id
                        ? roomData?.totalScoreByPlayerA
                        : roomData?.totalScoreByPlayerB}
                    </h2>
                  </div>
                </div>
                <div className="scoreDetails">
                  <div className="YourScore">
                    <h4>Opponent Score</h4>
                  </div>
                  <div className="score">
                    <h2>
                      {playerASocketId == socket.id
                        ? roomData?.totalScoreByPlayerB
                        : roomData?.totalScoreByPlayerA}
                    </h2>
                  </div>
                </div>
              </div>
              {/* <div className='scoretotal'>
                                <div className='score'>
                                    <h2>{roomData?.winner == "playerBName" ? roomData?.totalScoreByPlayerB : roomData?.totalScoreByPlayerA }</h2>
                                </div>
                            </div> */}
              <div className="PlayButton">
                <button onClick={() => navigateHome()}>Play New Game</button>
              </div>
              {/* <div className="ChallengeButton">
                                <button onClick={() => navigate('/')}>Challenge Again</button>
                            </div> */}

              <div className="feedback">
                <a href="https://tally.so/r/w81dLl" target="_blank">
                  <button>Submit your feedback</button>
                </a>
              </div>
              <Matchsummary/>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default MatchTie;
