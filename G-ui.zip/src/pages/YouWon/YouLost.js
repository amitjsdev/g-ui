import React, { useState, useEffect } from "react";
// import Lost from "../../assets/images/Lost.png";
import wonBg from "../../assets/images/wonBg.png";
import ground from "../../assets/images/ground.png";
import "./YouWon.scss";
import { Modal } from "react-bootstrap";
import { useSelector } from "react-redux";
import socket from "../../socket";
import feedback from "../../assets/images/feedback.png";
import Lottie from "react-lottie";
import * as animationData from "../../assets/images/Loserscreen.json";
import Matchsummary from "./MatchSummary/Matchsummary";

function YouLost() {
  const playerMatchedData = useSelector(
    (state) => state?.userReducer?.matchedData
  );

  useEffect(() => {
    if (!playerMatchedData) {
      window.location.replace("/");
      return;
    }
  }, []);

  const navigateHome = () => {
    window.location.replace("/");
  };
  const timeAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  let roomData = playerMatchedData?.data?.roomData;
  console.log(roomData);
  let playerASocketId = roomData?.playerASocketId;
  let playerBSocketId = roomData?.playerBSocketId;

  return (
    <div>
      <Modal show={true} className="WinningScreens">
        <Modal.Body>
          <div className="YouWon">
            <div className="groungWon">
              <div className="grou">
                <div className="trophy">
                  {/* <img src={Lost} alt="Lost" className="Lost" /> */}
                  {/* <Lottie options={timeAnimation} /> */}
                  <Lottie options={timeAnimation} />
                </div>
                <div className="won_ground_img">
                  <div className="Won">
                    <img src={wonBg} alt="wonBg" className="wonBg" />
                    <h3>YOU LOST</h3>
                  </div>
                  <div className="stadiam_Selected">
                    <img src={ground} alt="ground" className="ground" />
                  </div>
                </div>
              </div>

              {playerASocketId == socket.id &&
              roomData?.playerBDisconnected == 1 ? (
                <div className="scoretotal">
                  <div className="scoreDetails">
                    <div className="score">
                      <h2>OPPONENT TIMEOUT</h2>
                    </div>{" "}
                  </div>
                </div>
              ) : playerBSocketId == socket.id &&
                roomData?.playerBDisconnected == 1 ? (
                <div className="scoretotal">
                  <div className="scoreDetails">
                    <div className="score">
                      <h2>TIMEOUT</h2>
                    </div>{" "}
                  </div>
                </div>
              ) : playerASocketId == socket.id &&
                roomData?.playerADisconnected == 1 ? (
                <div className="scoretotal">
                  <div className="scoreDetails">
                    <div className="score">
                      <h2>TIMEOUT</h2>
                    </div>{" "}
                  </div>
                </div>
              ) : playerBSocketId == socket.id &&
                roomData?.playerADisconnected == 1 ? (
                <div className="scoretotal">
                  <div className="scoreDetails">
                    <div className="score">
                      <h2>OPPONENT TIMEOUT</h2>
                    </div>{" "}
                  </div>
                </div>
              ) : (
                ""
                // <div className="scoretotal">
                //   <div className="scoreDetails">
                //     <div className="YourScore">
                //       <h4>Your Score</h4>
                //     </div>
                //     <div className="score">
                //       <h2>
                //         {playerASocketId == socket.id
                //           ? roomData?.totalScoreByPlayerA
                //           : roomData?.totalScoreByPlayerB}
                //       </h2>
                //     </div>
                //   </div>
                //   <div className="scoreDetails">
                //     <div className="YourScore">
                //       <h4>Opponent Score</h4>
                //     </div>
                //     <div className="score">
                //       <h2>
                //         {playerASocketId == socket.id
                //           ? roomData?.totalScoreByPlayerB
                //           : roomData?.totalScoreByPlayerA}
                //       </h2>
                //     </div>
                //   </div>
                // </div>
              )}

              <div className="PlayButton">
                <button onClick={() => navigateHome()}>Play New Game</button>
              </div>
              <div className="feedback">
                <a href="https://tally.so/r/w81dLl" target="_blank">
                  <button>Submit your feedback</button>
                </a>
              </div>
              <Matchsummary />
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default YouLost;
