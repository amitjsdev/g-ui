import React from "react";
import Screenplayer from "./GroundCards/Screenplayer";

const MatchGround = () => {
  return (
    <>
      <div className="Matchground">
        <Screenplayer />
      </div>
    </>
  );
};

export default MatchGround;
