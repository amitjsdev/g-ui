import React from "react";
import "../Playing/playing.scss";
import Lottie from "react-lottie";
import * as animationFrame from "../../../assets/images/grounsplay.json";
import addground from "../../../assets/images/addground.png";

const Message = ({ message }) => {
  const frameAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationFrame,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  return (
    <>
      <p>{message}</p>
    </>
  );
};

export default Message;
