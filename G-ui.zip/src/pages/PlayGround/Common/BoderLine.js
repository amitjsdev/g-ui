import React from "react";

const BoderLine = ({ borderCount }) => {
  return (
    <div className="bordgrd">
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="292"
        height="239"
        viewBox="0 0 292 239"
      >
        <g
          id="Rectangle_12196"
          data-name="Rectangle 12196"
          fill="none"
          stroke="#2bff2f"
          stroke-width="5"
        >
          <rect id="path" width="292" height="239" rx="20" stroke="none" />
          <rect
            id="num"
            x="1"
            y="1"
            width="290"
            height="237"
            rx="20"
            fill="none"
            style={{
              strokeDasharray: "1020",
              strokeDashoffset: "1020",
              animation: `dash ${borderCount}s linear infinite`,
            }}
          />
        </g>
      </svg>
    </div>
  );
};
export default BoderLine;
