import React from "react";
import googly_ball from "../../../assets/images/booster/googly_ball.png";
import Pink_ball from "../../../assets/images/booster/Pink_ball.png";
import bouncer from "../../../assets/images/booster/bouncer.png";
import Yorker from "../../../assets/images/booster/Yorker.png";
import "./Booster.scss";

const OpponentBooster = () => {
  const listOpponent = [
    {
      title: "Artifact 1",
      img: googly_ball,
    },
    {
      title: "Artifact 2",
      img: Pink_ball,
    },
    {
      title: "Artifact 3",
      img: bouncer,
    },
    {
      title: "Artifact 4",
      img: Yorker,
    },
    {
      title: "Artifact 5",
      img: googly_ball,
    },
    {
      title: "Artifact 6",
      img: Pink_ball,
    },
    {
      title: "Artifact 7",
      img: bouncer,
    },
    {
      title: "Artifact 8",
      img: Yorker,
    },
  ];
  return (
    <>
      <div className="boosters">
        {listOpponent.map((item) => (
          <li>
            <div className="boosterList">
              <div className="booserBowler active">
                <img className="cards" src={item?.img} />
              </div>
              <p>{item?.title}</p>
            </div>
          </li>
        ))}
      </div>
    </>
  );
};

export default OpponentBooster;
