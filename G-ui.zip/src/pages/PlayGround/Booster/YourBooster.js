import React from "react";
import Defend from "../../../assets/images/booster/Defend.png";
import PowerPlay from "../../../assets/images/booster/PowerPlay.png";
import Time from "../../../assets/images/booster/Time.png";
import aggression from "../../../assets/images/booster/aggression.png";
import "./Booster.scss";

const YourBooster = ({
  selectedArtifacts,
  userArtifacts,
  playerASocketId,
  playerBSocketId,
  socket,
  showArtEffectHandler,
  inning,
  artifactList,
  boosterDisable,
}) => {
  return (
    <>
      <div className="boosters">
        {artifactList &&
          artifactList.length > 0 &&
          artifactList.map((item, index) => {
            let usedArtifact =
              selectedArtifacts &&
              selectedArtifacts.length > 0 &&
              selectedArtifacts.find((id) => id == item.ds_id);
            let alreadyPlayed = usedArtifact
              ? "alreadyPlayed"
              : boosterDisable
              ? "alreadyPlayed"
              : "";
            let card_type =
              item?.usedByBatsman == 1
                ? "usedByBatsman"
                : item?.usedByBowler == 1
                ? "usedByBowler"
                : "ALL";
            let checkUsed;
            if (inning == "first") {
              checkUsed =
                playerASocketId == socket.id && inning == "first"
                  ? "usedByBatsman"
                  : "usedByBowler";
            } else if (inning == "second") {
              checkUsed =
                playerBSocketId == socket.id && inning == "second"
                  ? "usedByBatsman"
                  : "usedByBowler";
            }

            if (card_type == checkUsed) {
              return (
                <li className={alreadyPlayed} key={index}>
                  <div
                    onClick={() => showArtEffectHandler(item.ds_id, card_type)}
                    className="boosterList"
                  >
                    <div className="booserBats active">
                      <img className="cards" src={item?.image} />
                    </div>
                    <p>{item?.title}</p>
                  </div>
                </li>
              );
            }
          })}
      </div>
    </>
  );
};

export default YourBooster;
