import React from "react";
import "./Booster.scss";
import PowerPlay from "../../../assets/images/booster/PowerPlay.png";
import Time from "../../../assets/images/booster/Time.png";
import Defend from "../../../assets/images/booster/Defend.png";
import aggression from "../../../assets/images/booster/aggression.png";
import crose from "../../../assets/images/crose.svg";
import Slider from "react-slick";

const SelectedBooster = ({
  selectedArtifacts,
  artifactList,
  removeArtifact,
}) => {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  let boosterData = [];
  selectedArtifacts &&
    selectedArtifacts.length > 0 &&
    selectedArtifacts.map((id, index) => {
      let findBooster =
        artifactList &&
        artifactList.length > 0 &&
        artifactList.find((item) => item.ds_id == id);
      if (findBooster) {
        boosterData = findBooster;
      }
    });

  return (
    <div>
      <Slider {...settings}>
        <div className="selectboost">
          <div className="head">
            <div className="headings">
              {console.log("boosterData", boosterData)}
              <h6>{boosterData?.boosterData}</h6>
            </div>
            <button onClick={removeArtifact} className="cross">
              <img src={crose} alt="crose" />
            </button>
          </div>
          <div className="boostImg">
            <img src={boosterData?.image} alt="PowerPlay" />
          </div>
          <div className="texting">
            <p>{boosterData?.description}</p>
          </div>
        </div>
      </Slider>
    </div>
  );
};

export default SelectedBooster;
