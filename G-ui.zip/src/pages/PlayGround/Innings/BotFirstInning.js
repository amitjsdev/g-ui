import React, { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import "../../Ground/Ground.scss";
import { useNavigate } from "react-router-dom";
import {
  startCountDown,
  setCountDownEnable,
  getUserArtifacts,
  deductArtifact,
  setBatBosterInningFirst,
  setBowlerRecords,
} from "../../../redux/user/action";
import { useDispatch, useSelector } from "react-redux";
import socket from "../../../socket";
import WaitingModal from "../../../modals/WaitingModal";
import ScoreBoredModal from "../../../modals/ScoreBoredModal";

// new flow files
import Oppolistcard from "../GroundCards/Oppolistcard";
import Yourlistcard from "../GroundCards/Yourlistcard";
import YourBooster from "../Booster/YourBooster";
import SelectedBooster from "../Booster/SelectedBooster";
import SelectedYourPlayer from "../Playing/SelectedYourPlayer";

import SelectedOpponentPlayer from "../Playing/SelectedOpponentplayer";
import BorderLine from "../Common/BoderLine";
import addground from "../../../assets/images/addground.png";
import Overlist from "../Playing/Overlist";

let timerCount = 15;
let scoreStatus = 1;
function BotInningFirst(props) {
  const { playerMatchedData, setCheckRound, artifactList } = props;
  let roomData = playerMatchedData?.roomData;
  let roundInfo = roomData?.RoundsInfo;
  let currentRoundData = roomData?.RoundsInfo?.Inning1[roomData?.currentRound];

  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [borderCount, setBorderCount] = useState(0);

  const [showStartGame, setShowStartGame] = useState(false);
  const [yourPlayer, setYourPlayer] = useState(false);
  const [showArtifact, setShowArtifact] = useState(false);
  const [battingPlayer, setBattingPlayer] = useState({});
  const [bowlingPlayer, setBowlingPlayer] = useState({});
  const [cardType, setCartType] = useState();
  const [currentRound, setCurrentRound] = useState({});
  const [timerclose, setTimerClose] = useState(true);
  const [battingMessage, setBattingMessage] = useState(
    "Select a batsman below"
  );
  const [scoreShow, setScoreShow] = useState(false);
  const [ballShow, setBallShow] = useState(false);
  const [inningRound, setInningRound] = useState("round_1");
  const [checkInningRound, setCheckInningRound] = useState("PENDING");
  const [botSocket, setBotSocket] = useState(false);
  const [counterRun, setCounterRun] = useState(false);
  const [bowlerBot, setBowlerBot] = useState(false);

  const [changeBat, setChangeBat] = useState(false);
  const [playerDisable, setPlayerDisable] = useState(false);
  const changeBatRef = useRef(changeBat);
  const [isChangeBooster, setIsChangeBooster] = useState(false);
  const [emptyArtifact, setEmptyArtifact] = useState(false);
  const [everyBallData, setEveryBallData] = useState([]);

  changeBatRef.current = changeBat;

  let playerASocketId = roomData?.playerASocketId;
  let playerBSocketId = roomData?.playerBSocketId;
  let socketPlayerList =
    playerASocketId == socket.id ? playerASocketId : playerBSocketId;
  let opponetSocket =
    playerASocketId == socket.id ? playerBSocketId : playerASocketId;

  let playerData =
    !!playerMatchedData &&
    !!playerMatchedData?.playerIds &&
    !!playerMatchedData?.playerIds[socketPlayerList] &&
    playerMatchedData?.playerIds[socketPlayerList].length > 0
      ? playerMatchedData?.playerIds[socketPlayerList]
      : [];

  const [selectedArtifacts, setSelectedArtifacts] = useState([]);
  const randomTime = Math.floor(Math.random() * 3) + 1;

  const batBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.batBoosterFirstInning
  );
  const bowlerRecords = useSelector(
    (state) => state?.userReducer?.bowlerRecords
  );

  useEffect(() => {
    if (!playerMatchedData) {
      navigate("/");
      return;
    }
    dispatch(getUserArtifacts());
    setTimeout(() => {
      setTimerClose(false);
      setShowStartGame(true);
    }, 3000);

    setTimeout(() => {
      setShowStartGame(false);
      if (playerASocketId == socket.id) {
        setCounterRun(true);
        dispatch(setCountDownEnable(true));
        setCount(timerCount);
        setBorderCount(timerCount);
      }
    }, 6000);
  }, [socket]);

  const [currentCount, setCount] = useState(timerCount);
  const timer = () => setCount(currentCount - 1);

  useEffect(() => {
    if (counterRun) {
      console.log("------current count-------", currentCount);
      if (currentCount < 0) {
        if (
          currentRoundData?.roundStatus == "PROGRESS" &&
          currentRoundData?.bowlerInfo != null &&
          !currentRoundData?.overFulfilled
        ) {
          setBattingMessage("");
          sendNotifyToBowlingTeam(
            "",
            { inning: "Inning1", round: inningRound },
            0
          );
          setTimeout(() => {
            sendNotifyToBowlingTeam(
              "",
              { inning: "Inning1", round: inningRound },
              scoreStatus
            );
          }, 1000);
          // setCounterRun(false)
          // setTimeout(() => {
          //   setCounterRun(true)
          // }, 6000)
        } else if (Object.keys(battingPlayer).length > 0) {
          setPlayerDisable(true);
          if (
            roomData?.RoundsInfo?.Inning1?.[roomData?.currentRound]
              ?.bowlerInfo !== null
          ) {
            // setBattingMessage("");
          } else {
            setBattingMessage("Wait for opponent selection");
          }

          if (
            playerASocketId == socket.id &&
            selectedArtifacts &&
            selectedArtifacts.length > 0
          ) {
            if (
              playerASocketId == socket.id &&
              roomData?.RoundsInfo?.Inning1?.[roomData?.currentRound]
                ?.bowlerAgain == 0
            ) {
              dispatch(
                setBatBosterInningFirst([
                  ...batBoosterFirstInning,
                  selectedArtifacts[0],
                ])
              );
              dispatch(
                deductArtifact(
                  { artefact_id: selectedArtifacts[0] },
                  artifactCallBack
                )
              );
            }
            sendNotifyToBowlingTeam(
              "",
              { inning: "Inning1", round: inningRound },
              0
            );
          }

          setTimeout(() => {
            sendNotifyToBowlingTeam(
              "",
              { inning: "Inning1", round: inningRound },
              scoreStatus
            );
          }, 1000);

          setShowArtifact(false);
        }

        return;
      } else {
        if (currentCount == 8) {
          if (roomData?.isBatSelected == 0) {
            if (Object.keys(battingPlayer).length == 0) {
              setBattingMessage("");
              if (playerASocketId == socket.id) {
                randomSelectPlayer("batsman");
              }
            }
          }
        } else if (currentCount == 5) {
          if (
            currentRoundData?.roundStatus == "PROGRESS" &&
            currentRoundData?.bowlerInfo != null &&
            !currentRoundData?.overFulfilled
          ) {
            setCount(-1);
            setBorderCount(0);
          } else {
            setShowArtifact(true);
            setBattingMessage("Select a booster below");
          }
          setPlayerDisable(true);
        } else if (currentCount == 0) {
          setBorderCount(0);
          setShowArtifact(false);
          setBattingMessage("Wait for opponent selection");
        } else if (currentCount == 6) {
          if (playerASocketId == socket.id) {
            sendNotifyToBowlingTeam(
              battingPlayer,
              { inning: "Inning1", round: inningRound },
              0
            );
          }
        } else if (
          !botSocket &&
          currentCount === 13 &&
          roomData?.isSecondPlayerBot &&
          counterRun &&
          roomData?.isBatSelected == 1
        ) {
          setBotSocket(true);
          setTimeout(() => {
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning1", round: inningRound },
              0
            );
          }, randomTime * 1000);
          return;
        }
      }
    }
    const id = setInterval(timer, 1000);
    return () => clearInterval(id);
  }, [currentCount]);

  //useEffect for send bot final sunbmit for score
  useEffect(() => {
    if (bowlerBot) {
      // setBattingMessage("");
      setTimeout(() => {
        sendNotifyToBattingTeam(
          "",
          { inning: "Inning1", round: inningRound },
          scoreStatus
        );
        setBowlerBot(false);
      }, [3000]);
    }
  }, [bowlerBot]);

  //5 second select booster for same batsman
  const [boosterCount, setBoosterCount] = useState(0);
  const timerBooster = () => setBoosterCount(boosterCount - 1);

  useEffect(() => {
    console.log("isChangeBooster=", isChangeBooster, boosterCount);
    if (isChangeBooster) {
      if (boosterCount < 0) {
        sendNotifyToBowlingTeam(
          "",
          { inning: "Inning1", round: inningRound, again: 1 },
          1,
          "withBooster"
        );
        setIsChangeBooster(false);

        return;
      } else {
        if (boosterCount == 0) {
          setShowArtifact(false);
          setBorderCount(0);
        }
      }
      // setBattingMessage("");

      const id = setInterval(timerBooster, 1000);
      return () => clearInterval(id);
    }
  }, [boosterCount]);

  //empty booster selected for is again batsman
  useEffect(() => {
    if (selectedArtifacts && selectedArtifacts.length == 0 && emptyArtifact) {
      setBattingMessage("Wait for opponent selection");
      setTimeout(() => {
        sendNotifyToBowlingTeam(
          "",
          { inning: "Inning1", round: inningRound, again: 1 },
          1
        );
      }, 1000);
    }
  }, [emptyArtifact]);

  //send notification to  player2 (bowling team) for batsman is selected and save batsman record
  const sendNotifyToBowlingTeam = (
    batInfoData,
    round,
    scoreVal,
    withBooster
  ) => {
    let batWithArt =
      Object.keys(battingPlayer).length > 0
        ? { ...battingPlayer, artifacts: selectedArtifacts }
        : batInfoData;

    let roundInfoData =
      !!round && Object.keys(round).length > 0 ? round : currentRound;

    if (
      roundInfoData?.again == 1 &&
      scoreVal == 1 &&
      playerASocketId == socket.id &&
      selectedArtifacts &&
      selectedArtifacts.length > 0 &&
      !!withBooster
    ) {
      dispatch(
        setBatBosterInningFirst([
          ...batBoosterFirstInning,
          selectedArtifacts[0],
        ])
      );
      dispatch(
        deductArtifact({ artefact_id: selectedArtifacts[0] }, artifactCallBack)
      );
    }

    let batRound = {
      isScore: scoreVal,
      roomId: playerMatchedData?.roomId,
      socketId: playerASocketId,
      roundInfo: roundInfoData,
      batInfo: batWithArt,
    };
    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: batRound,
      }
    );
  };

  useEffect(() => {
    if (!playerMatchedData) {
      navigate("/");
      return;
    }
    getGroundUpdateSocket();
  }, [playerMatchedData?.roomData]);

  const getTotalBowls = (checkRound) => {
    checkRound?.everyBall.length > 0 &&
      checkRound?.everyBall.map((item) => {
        return item;
      });
  };
  const getGroundUpdateSocket = async () => {
    //get rounds updated data
    let inningChecked = roomData;
    let inningStatus = roomData?.RoundsInfo?.Inning1?.status;
    let checkRound = roomData?.RoundsInfo?.Inning1?.[roomData?.currentRound];
    let roundVal = roomData?.currentRound.split("_")[1];
    let checkNextRound = "round_" + (+roundVal + +1);
    let currentRound = roomData?.currentRound;

    setCheckInningRound("PENDING");
    if (
      inningChecked?.isSecondPlayerBot &&
      roomData?.isBatSelected == 1 &&
      playerASocketId == socket.id
    ) {
      if (checkRound?.bowlerInfo == null) {
        setBattingMessage("Wait for opponent selection");
        setBorderCount(0);
        dispatch(setCountDownEnable(false));
        setCount(timerCount);
      } else if (checkRound?.bowlerInfo !== null) {
        setBowlerBot(true);
        setBattingMessage("");
      }
    }

    if (inningChecked?.MatchStatus == "TIMEOUT") {
      dispatch(setCountDownEnable(false));
      setCount(-1);
      navigate("/time-out");
    } else if (inningChecked?.MatchStatus == "COMPLETED") {
      if (
        inningChecked?.WinnerId == "BOT" &&
        inningChecked?.isSecondPlayerBot &&
        checkRound?.batInfo == null
      ) {
        dispatch(setCountDownEnable(false));
        setCount(-1);
        navigate("/lost");
      } else if (
        inningChecked?.winner == "TIE" &&
        checkRound?.batInfo == null &&
        checkRound?.bowlerInfo == null
      ) {
        navigate("/match-tie");
      } else if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo == null &&
        playerASocketId == socket.id
      ) {
        navigate("/winner");
      } else if (
        checkRound?.batInfo == null &&
        checkRound?.bowlerInfo != null &&
        playerASocketId == socket.id
      ) {
        navigate("/lost");
      }
    }

    //complete round checks
    if (checkNextRound == "round_6" && currentRound == "round_5") {
      //
      if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED"
      ) {
        let totalBalls =
          checkRound?.everyBall.length > 0 ? checkRound?.everyBall : [];
        setEveryBallData(totalBalls);
        setPlayerDisable(false);
        setCurrentRound({ inning: "Inning1", round: "round_5" });
        // setInningRound("round_5");
        // setScoreShow(true);
        // showScoreModal("fivethRound", inningStatus, checkRound?.roundStatus);
        handleBowlWithScore(
          totalBalls,
          "fivethRound",
          inningStatus,
          checkRound?.roundStatus
        );
      } else if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "PROGRESS" &&
        roomData?.isBatSelected == 0 &&
        checkRound?.overFulfilled
      ) {
        let totalBalls =
          checkRound?.everyBall.length > 0 ? checkRound?.everyBall : [];
        setEveryBallData(totalBalls);
        setInningRound("round_5");
        setCurrentRound({ inning: "Inning1", round: "round_5" });
        // setScoreShow(true);
        // showScoreModal("forthRound", inningStatus, checkRound?.roundStatus);
        handleBowlWithScore(
          totalBalls,
          "forthRound",
          inningStatus,
          checkRound?.roundStatus
        );
      }
    } else {
      if (
        //This case is for 2 over is completed, also wicket is down (i.e current round is completed)
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        checkRound?.overFulfilled
      ) {
        let totalBalls =
          checkRound?.everyBall.length > 0 ? checkRound?.everyBall : [];
        setEveryBallData(totalBalls);
        setPlayerDisable(false);
        if (currentRound == "round_1") {
          setInningRound("round_2");
          setCurrentRound({ inning: "Inning1", round: "round_2" });
          // setScoreShow(true);
          handleBowlWithScore(
            totalBalls,
            "firstRound",
            inningStatus,
            checkRound?.roundStatus
          );
        } else if (currentRound == "round_2") {
          setInningRound("round_3");
          setCurrentRound({ inning: "Inning1", round: "round_3" });
          // setScoreShow(true);
          handleBowlWithScore(
            totalBalls,
            "secondRound",
            inningStatus,
            checkRound?.roundStatus
          );
        } else if (currentRound == "round_3") {
          setInningRound("round_4");
          setCurrentRound({ inning: "Inning1", round: "round_4" });
          // setScoreShow(true);
          handleBowlWithScore(
            totalBalls,
            "thirdRound",
            inningStatus,
            checkRound?.roundStatus
          );
        } else if (currentRound == "round_4") {
          setInningRound("round_5");
          setCurrentRound({ inning: "Inning1", round: "round_5" });
          handleBowlWithScore(
            totalBalls,
            "forthRound",
            inningStatus,
            checkRound?.roundStatus
          );
        }
      } else if (
        //This case is for 2 over not completed, but wicket is down (i.e current round is completed)
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        !checkRound?.overFulfilled
        // &&
        // !inningChecked?.isSecondPlayerBot
      ) {
        let totalBalls =
          checkRound?.everyBall.length > 0 ? checkRound?.everyBall : [];
        setEveryBallData(totalBalls);
        setInningRound("");
        setCurrentRound({});
        if (currentRound == "round_1") {
          setInningRound("round_2");
          setCurrentRound({ inning: "Inning1", round: "round_2" });
          // setScoreShow(true);
          handleBowlWithScore(
            totalBalls,
            "firstRound",
            inningStatus,
            "PENDING",
            "round_2"
          );
        } else if (currentRound == "round_2") {
          setInningRound("round_3");
          setCurrentRound({ inning: "Inning1", round: "round_3" });
          // setScoreShow(true);
          handleBowlWithScore(
            totalBalls,
            "secondRound",
            inningStatus,
            "PENDING",
            "round_3"
          );
        } else if (currentRound == "round_3") {
          setInningRound("round_4");
          setCurrentRound({ inning: "Inning1", round: "round_4" });
          // setScoreShow(true);
          handleBowlWithScore(
            totalBalls,
            "thirdRound",
            inningStatus,
            "PENDING",
            "round_4"
          );
        } else if (currentRound == "round_4") {
          setInningRound("round_5");
          setCurrentRound({ inning: "Inning1", round: "round_5" });
          // setScoreShow(true);
          handleBowlWithScore(
            totalBalls,
            "forthRound",
            inningStatus,
            "PENDING",
            "round_5"
          );
        }
      } else if (
        //This case is for 2 over completed without any wicket (i.e current round is still pending)
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "PROGRESS" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        roomData?.isBatSelected == 0 &&
        checkRound?.overFulfilled
      ) {
        let totalBalls =
          checkRound?.everyBall.length > 0 ? checkRound?.everyBall : [];
        setEveryBallData(totalBalls);
        setCurrentRound({});
        if (currentRound == "round_1") {
          setInningRound("round_1");
          // setCurrentRound({ inning: "Inning1", round: "round_1", again: 1 });
          handleBowlWithScore(
            totalBalls,
            "firstRound",
            inningStatus,
            "PROGRESS"
          );
        } else if (currentRound == "round_2") {
          setInningRound("round_2");
          // setCurrentRound({ inning: "Inning1", round: "round_2", again: 1 });
          handleBowlWithScore(
            totalBalls,
            "secondRound",
            inningStatus,
            "PROGRESS"
          );
        } else if (currentRound == "round_3") {
          setInningRound("round_3");
          // setCurrentRound({ inning: "Inning1", round: "round_3", again: 1 });
          handleBowlWithScore(
            totalBalls,
            "thirdRound",
            inningStatus,
            "PROGRESS"
          );
        } else if (currentRound == "round_4") {
          setInningRound("round_4");
          // setCurrentRound({ inning: "Inning1", round: "round_4", again: 1 });
          handleBowlWithScore(
            totalBalls,
            "forthRound",
            inningStatus,
            "PROGRESS"
          );
        }
      }
    }
  };

  const checkPlayerChange = () => {
    if (!changeBatRef.current) {
      setCheckInningRound("COMPLETED");
      if (batBoosterFirstInning.length > 2 && playerASocketId == socket.id) {
        setEmptyArtifact(true);
      } else {
        setBorderCount(5);
        setBattingMessage("Select a booster below");
        setShowArtifact(true);
        setIsChangeBooster(true);
        setBoosterCount(5);
      }
      setPlayerDisable(true);
    } else {
      setBorderCount(timerCount);
      let roundVal = roomData?.currentRound.split("_")[1];
      let checkNextRound = "round_" + (+roundVal + +1);
      setInningRound(checkNextRound);
      setYourPlayer(false);
      setShowArtifact(false);
      setSelectedArtifacts([]);
      setBattingPlayer({});
      setChangeBat(!changeBatRef.current);
      setCount(timerCount);
      setBattingMessage("Select a Batsman below");
      setCheckInningRound("COMPLETED");
      setPlayerDisable(false);
    }
  };

  const showScoreModal = (round, inningStatus, roundStatus, chkRound) => {
    // ballShow(false);
    dispatch(setCountDownEnable(false));
    if (roundStatus === "PENDING") {
      setPlayerDisable(false);
      if (playerASocketId == socket.id) {
        if (roomData?.isSecondPlayerBot) {
          // setCheckInningRound("COMPLETED");
          setTimeout(() => {
            // setScoreShow(false);
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning1", round: chkRound },
              0
            );
          }, 5000);
        }
        setBattingPlayer({});
        // setSelectedArtifacts([]);
        setBattingMessage("Select a Batsman below");
        setTimeout(() => {
          setBotSocket(false);
          setScoreShow(false);
          setYourPlayer(false);
          setShowArtifact(false);
          setCount(timerCount);
          setBorderCount(10);
          dispatch(setCountDownEnable(true));
        }, 6000);
      }

      // setTimeout(() => {
      //   sendNotifyToBattingTeam("", { inning: "Inning1", round: chkRound }, 1);
      // }, 9000);
    } else if (roundStatus == "PROGRESS" && roomData?.isBatSelected == 0) {
      setPlayerDisable(true);
      setTimeout(() => {
        setBotSocket(false);
        setScoreShow(false);

        if (playerASocketId == socket.id) {
          setSelectedArtifacts([]);
          checkPlayerChange();
        }
      }, 5000);
    } else if (roundStatus == "COMPLETED") {
      setYourPlayer(false);
      setShowArtifact(false);
      setSelectedArtifacts([]);
      if (inningStatus == "COMPLETED") {
        setTimeout(() => {
          setCheckRound(inningStatus);
          dispatch(setBowlerRecords([]));
        }, 4000);
      }
      setTimeout(() => {
        setPlayerDisable(false);
        setBotSocket(false);
        setCheckInningRound("COMPLETED");
        setScoreShow(false);
        if (round == "fivethRound") {
          setBattingMessage("First inning is complete");
        } else {
          setBattingPlayer({});
          setBowlingPlayer({});
          if (playerASocketId == socket.id) {
            dispatch(startCountDown(timerCount));
            dispatch(setCountDownEnable(true));
            setCount(timerCount);
            setBorderCount(timerCount);
          }
          setBattingMessage("Select a Batsman below");
        }
      }, 5000);
    }
  };

  //send notification to  player1 (batting team) for bowler is selected
  const sendNotifyToBattingTeam = (bowlerInfo, round, scoreVal) => {
    let checkBot = roomData?.isSecondPlayerBot ? 1 : 0;
    let bowlerRound = {};
    if (roomData?.isSecondPlayerBot) {
      bowlerRound = {
        isBotResult: checkBot,
        isScore: scoreVal,
        roomId: playerMatchedData?.roomId,
        socketId: playerBSocketId,
        roundInfo:
          !!round && Object.keys(round).length > 0 ? round : currentRound,
      };
    }

    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: bowlerRound,
      }
    );
  };

  const selectYourPlayer = (
    playerType,
    playerSocketId,
    cardId,
    playerInfo,
    card_Type,
    alreadyPlayed
  ) => {
    if (alreadyPlayed == "alredyPlay") {
      return;
    }
    // setPlayerDisable(false);
    setCartType(card_Type);
    if (roundInfo?.Inning1?.status == "PROGRESS") {
      let roundInfoPlayer = { inning: "Inning1", round: inningRound };
      setCurrentRound(roundInfoPlayer);
      if (playerType == "BAT" && playerSocketId == socket.id) {
        setYourPlayer(true);
        setBattingPlayer(playerInfo);

        document.body.className = "noBackDrop";
        setBattingMessage("");
        // if (artifactList && artifactList.length > 0) {
        //   setBattingMessage("");
        // } else {
        //   // setBattingMessage("");
        // }
      }
    }
  };

  //deducted artifact call back
  const artifactCallBack = (data) => {
    if (data?.status == 200) {
      dispatch(getUserArtifacts());
    }
    return null;
  };
  const showArtEffectHandler = (id) => {
    if (batBoosterFirstInning.length > 2 && playerASocketId == socket.id) {
      toast.error("You can choose a maximum 3 boosters in a inning", {
        toastId: "error2",
      });
    } else {
      // if (id) {
      if (selectedArtifacts.length < 1) {
        console.log("id--", id);
        setBattingMessage("");
        setSelectedArtifacts([id]);
      } else {
        toast.error("Choose one booster", {
          toastId: "error1",
        });
      }
      // }
    }
  };

  //change batsman
  const changeBatsman = () => {
    setYourPlayer(false);
    setShowArtifact(false);
    setSelectedArtifacts([]);
    setChangeBat(true);
  };

  //already played ids
  let batPlayerIds = [];
  let bowlerPlayedIds = [];

  for (let i = 1; i <= 5; i++) {
    let round = "round_" + i;
    if (roundInfo?.Inning1?.[round]?.batInfo) {
      let batRound = roundInfo?.Inning1?.[round]?.batInfo;
      batPlayerIds.push({
        playerId: batRound?.nftId,
        checkOutStatus: roundInfo?.Inning1?.[round]?.WicketOut,
      });
    }
    if (roundInfo?.Inning1?.[round]?.bowlerInfo) {
      let bowlRound = roundInfo?.Inning1?.[round]?.bowlerInfo;

      bowlerPlayedIds.push({
        playerId: bowlRound?.nftId,
        checkOutStatus: bowlRound?.WicketOut,
      });
    }
  }

  const removeArtifact = () => {
    setBattingMessage("Select a booster below");
    setSelectedArtifacts([]);
  };
  //random batsman selection
  const randomSelectPlayer = (player) => {
    let cardsList = [...playerData];
    let boosterId = [];

    if (player == "batsman") {
      let roundInfoPlayer = { inning: "Inning1", round: inningRound };
      setYourPlayer(true);
      setCurrentRound(roundInfoPlayer);
      batPlayerIds &&
        batPlayerIds.length > 0 &&
        batPlayerIds.map((e) => {
          const nftIndex = cardsList.findIndex(
            (item) => item?.nftId == e?.playerId
          );
          if (nftIndex !== -1) {
            cardsList.splice(nftIndex, 1);
          }
        });

      const randomIndex = Math.floor(Math.random() * cardsList.length);
      let nftData = cardsList[randomIndex];
      // let nftData = cardsList[0];
      let playerInfo = {
        outlineImage: nftData?.outlineImage,
        da_id: nftData?.da_id,
        nftId: nftData?.nftId,
        name: nftData?.title,
        gameTitle: nftData?.gameTitle,
        img: nftData?.nftLogo,
        artifacts: boosterId,
        isArtifact: 0,
      };

      setBattingPlayer(playerInfo);

      if (
        currentRoundData?.roundStatus == "PROGRESS" &&
        currentRoundData?.bowlerInfo != null &&
        !currentRoundData?.overFulfilled
      ) {
        setTimeout(() => {
          setCount(-1);
          setBorderCount(0);
        }, 3000);

        // sendNotifyToBowlingTeam(playerInfo, roundInfoPlayer, scoreStatus);
      } else {
        sendNotifyToBowlingTeam(playerInfo, roundInfoPlayer, 0);
      }
      setPlayerDisable(true);
    }
  };

  // Wait function to hold the game till Over ball Data is displayed
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  //handling Over ball-by-ball Data along with continuing the game
  const handleBowlWithScore = (
    roundInfo,
    round,
    inningStatus,
    roundStatus,
    chkRound
  ) => {
    const len = roundInfo[1]?.ballData
      ? roundInfo[0]?.ballData.length + roundInfo[1]?.ballData.length
      : roundInfo[0]?.ballData.length;
    // console.log("-------------balllll info----", round, roundStatus)
    setBallShow(true);
    len <= 4
      ? wait(5000).then(() => {
          setBallShow(false);
          if (chkRound) {
            showScoreModal(round, inningStatus, roundStatus, chkRound);
          } else {
            showScoreModal(round, inningStatus, roundStatus);
          }
        })
      : wait(len * 1000).then(() => {
          setBallShow(false);
          if (chkRound) {
            showScoreModal(round, inningStatus, roundStatus, chkRound);
          } else {
            showScoreModal(round, inningStatus, roundStatus);
          }
        });

    // if(roundStatus === "PENDING"){
    //   setBorderCount(10);
    //   setPlayerDisable(false);
    //   setYourPlayer(true);
    //   setYourPlayer(true)
    // }
  };

  return (
    <>
      {console.log("batBoosterFirstInning", batBoosterFirstInning)}
      <div className="Firstplayer">
        {!!playerMatchedData &&
          !!playerMatchedData?.playerIds &&
          !!playerMatchedData?.playerIds[opponetSocket] &&
          playerMatchedData?.playerIds[opponetSocket].length > 0 && (
            <Oppolistcard
              playerMatchedData={playerMatchedData?.playerIds[opponetSocket]}
            />
          )}
        <div className="grounPlay">
          <SelectedOpponentPlayer
            playersSocketId={playerASocketId}
            roundInfo={
              playerASocketId == socket.id
                ? !!roundInfo?.Inning1[roomData?.currentRound]
                  ? roundInfo?.Inning1[roomData?.currentRound]
                  : {}
                : ""
            }
            roomData={roomData}
            socket={socket}
            artifactList={artifactList}
            selectedArtifacts={selectedArtifacts}
            checkInningRound={checkInningRound}
            inning={"first"}
          />

          <div>
            <div className="plaer">
              <div className="ground">
                {borderCount > 0 && <BorderLine borderCount={borderCount} />}

                <img src={addground} alt="addground" />
              </div>
              <div className="main_Contint">
                {battingPlayer &&
                  Object.keys(battingPlayer).length > 0 &&
                  yourPlayer &&
                  !showArtifact &&
                  battingMessage == "" && (
                    <SelectedYourPlayer
                      roomData={roomData}
                      opponent={false}
                      playersSocketId={playerASocketId}
                      socket={socket}
                      bowlingPlayer={bowlingPlayer}
                      battingPlayer={battingPlayer}
                      yourPlayer={yourPlayer}
                      artifactList={artifactList}
                      selectedArtifacts={selectedArtifacts}
                      inning="first"
                      checkInningRound={checkInningRound}
                    />
                  )}

                {showArtifact &&
                  battingMessage == "" &&
                  selectedArtifacts &&
                  selectedArtifacts.length > 0 && (
                    <SelectedBooster
                      removeArtifact={removeArtifact}
                      selectedArtifacts={selectedArtifacts}
                      artifactList={artifactList}
                    />
                  )}

                {battingMessage != "" && <p>{battingMessage}</p>}
              </div>
            </div>
          </div>
        </div>
        {ballShow && !showArtifact && (
          <Overlist
            overList={roomData?.RoundsInfo?.Inning1}
            round={roomData?.currentRound}
          />
        )}
        {!ballShow && !showArtifact && playerData.length > 0 && (
          <Yourlistcard
            playerDisable={playerDisable}
            batPlayerIds={batPlayerIds}
            bowlerPlayedIds={bowlerPlayedIds}
            playerMatchedData={playerData}
            roomData={roomData}
            roundInfo={roundInfo?.Inning1}
            playerASocketId={playerASocketId}
            playerBSocketId={playerBSocketId}
            socket={socket}
            selectYourPlayer={selectYourPlayer}
            inning="first"
            bowlerRecords={bowlerRecords}
          />
        )}
        {!ballShow && showArtifact && (
          <YourBooster
            // playerDisable={playerDisable}
            selectedArtifacts={selectedArtifacts}
            artifactList={artifactList}
            playerASocketId={playerASocketId}
            playerBSocketId={playerBSocketId}
            inning="first"
            socket={socket}
            disable={true}
            showArtEffectHandler={showArtEffectHandler}
            // boosterFirstInning={boosterFirstInning}
          />
        )}
      </div>
      {scoreShow && currentRoundData?.batInfo && (
        <ScoreBoredModal
          changeBat={changeBat}
          // continueBtn={continueBtn}
          changeBatsman={changeBatsman}
          // continueGame={continueGame}
          playersSocketId={playerASocketId}
          currentRound={roomData?.currentRound}
          inning="First"
          roomData={roomData}
          roundInfo={currentRoundData}
        />
      )}

      {!!playerMatchedData &&
        roundInfo?.Inning1?.round_1 == null &&
        timerclose && <WaitingModal message={"First Inning"} subMessage={""} />}

      {roundInfo?.Inning1?.round_1 == null && showStartGame && (
        <WaitingModal
          message={"Game about to start"}
          subMessage={
            playerASocketId == socket.id ? "Select Batsman" : "Select Bowler"
          }
        />
      )}
    </>
  );
}

export default BotInningFirst;
