import React, { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import "../../Ground/Ground.scss";
import pitch from "../../../assets/images/pitch.png";
import { useNavigate } from "react-router-dom";
import {
  startCountDown,
  enableDoneBtn,
  setCountDownEnable,
  getUserArtifacts,
  deductArtifact,
  savePlayer,
  setBowlerRecords,
  setBatBosterInningSecond,
  setBowlBosterInningSecond,
} from "../../../redux/user/action";
import { useDispatch, useSelector } from "react-redux";
import socket from "../../../socket";

import WaitingModal from "../../../modals/WaitingModal";
import UserArtifacts from "../../Ground/UserArtifacts";
import SecondInningScores from "../../Ground/SecondInningScores";
import OpponentCard from "../../Ground/OpponentCards";
import OpponentPlayer from "../../Ground/OpponentPlayer";
import YourPlayer from "../../Ground/YourPlayer";
import YourCards from "../../Ground/YourCards";
import PlayerTurnModal from "../../../modals/PlayerTurnModal";
import ScoreBoredModal from "../../../modals/ScoreBoredModal";
import InningsChangeModal from "../../../modals/InningChangeModal";
import { batBoosterFirstInning } from "../../../redux/common/types";

// new flow files
import Oppolistcard from "../GroundCards/Oppolistcard";
import Yourlistcard from "../GroundCards/Yourlistcard";
import Youplaying from "../Playing/Youplaying";
import Opponentplaying from "../Playing/Opponentplaying";
import YourBooster from "../Booster/YourBooster";
import SelectedBooster from "../Booster/SelectedBooster";
import OpponentBooster from "../Booster/OpponentBooster";
import SelectedYourPlayer from "../Playing/SelectedYourPlayer";

import SelectedOpponentPlayer from "../Playing/SelectedOpponentplayer";
import SelectBooster from "../Playing/SelectBooster";
import Message from "../Common/Message";
import BorderLine from "../Common/BoderLine";
import addground from "../../../assets/images/addground.png";
import Overlist from "../Playing/Overlist";
let timerCount = 15;
let scoreStatus = 1;
function BotInningSecond(props) {
  const { playerMatchedData, artifactList } = props;
  let roomData = playerMatchedData?.roomData;
  let roundInfo = roomData?.RoundsInfo;
  let currentRoundData = roomData?.RoundsInfo?.Inning2[roomData?.currentRound];

  if (!playerMatchedData) {
    navigate("/");
  }
  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [borderCount, setBorderCount] = useState(0);

  const [showStartGame, setShowStartGame] = useState(false);
  const [yourPlayer, setYourPlayer] = useState(false);
  const [showArtifact, setShowArtifact] = useState(false);
  const [selectedArtifacts, setSelectedArtifacts] = useState([]);
  const [battingPlayer, setBattingPlayer] = useState({});
  const [bowlingPlayer, setBowlingPlayer] = useState({});
  const [inningRound, setInningRound] = useState("round_1");
  // const [roundInfo, setRoundInfo] = useState({});
  const [timerclose, setTimerClose] = useState(true);
  const [bowlingMessage, setBowlingMessage] = useState("Select a bowler below");
  const [WaitModalForScore, setWaitModalForScore] = useState(false);
  const [scoreShow, setScoreShow] = useState(false);
  const [currentRound, setCurrentRound] = useState({});
  const [checkInningRound, setCheckInningRound] = useState("PENDING");
  const [botSocket, setBotSocket] = useState(false);
  const randomTime = Math.floor(Math.random() * 5) + 1;
  const [counterRun, setCounterRun] = useState(false);

  const [changeBat, setChangeBat] = useState(false);
  // const [boosterDisable, setPlayerDisable] = useState(false);
  const [playerDisable, setPlayerDisable] = useState(false);
  const [everyBallData, setEveryBallData] = useState([]);
  const [ballShow, setBallShow] = useState(false);

  const changeBatRef = useRef(changeBat);
  changeBatRef.current = changeBat;

  let playerASocketId = roomData?.playerASocketId;

  let playerBSocketId = roomData?.playerBSocketId;

  let socketPlayerList =
    playerBSocketId == socket.id ? playerBSocketId : playerASocketId;
  let opponetSocket =
    playerBSocketId == socket.id ? playerASocketId : playerBSocketId;

  let playerData =
    !!playerMatchedData &&
    !!playerMatchedData?.playerIds &&
    !!playerMatchedData?.playerIds[socketPlayerList] &&
    playerMatchedData?.playerIds[socketPlayerList].length > 0
      ? playerMatchedData?.playerIds[socketPlayerList]
      : [];

  const savePlayerInfo = useSelector(
    (state) => state?.userReducer?.informBowlingTeam
  );

  const bowlerRecords = useSelector(
    (state) => state?.userReducer?.bowlerRecords
  );

  const batBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.batBoosterFirstInning
  );
  const bowlBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.bowlBoosterFirstInning
  );

  const batBoosterSecondInning = useSelector(
    (state) => state?.userReducer?.batBoosterSecondInning
  );
  const bowlBoosterSecondInning = useSelector(
    (state) => state?.userReducer?.bowlBoosterSecondInning
  );

  const saveCurrentPlayer = useSelector(
    (state) => state?.userReducer?.enableDoneBtn
  );
  const [currentCount, setCount] = useState(timerCount);
  const timer = () => setCount(currentCount - 1);

  useEffect(() => {
    if (counterRun) {
      if (currentCount < 0) {
        if (Object.keys(bowlingPlayer).length > 0) {
          // setWaitModalForScore(true);
          if (currentRoundData?.batInfo !== null) {
            // setBowlingMessage("");
          } else {
            // setBowlingMessage("Wait for opponent selection");
          }

          if (
            playerASocketId == socket.id &&
            selectedArtifacts &&
            selectedArtifacts.length > 0
          ) {
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning2", round: inningRound },
              0
            );
          }
          setTimeout(() => {
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning2", round: inningRound },
              scoreStatus
            );
          }, 1000);
          setShowArtifact(false);
        }
        return;
      } else {
        if (currentCount == 8) {
          if (roomData?.isBatSelected == 1) {
            if (Object.keys(bowlingPlayer).length == 0) {
              setBowlingMessage("");
              if (playerASocketId == socket.id) {
                randomSelectPlayer("bowler");
              }
            }
          }
        } else if (currentCount == 6) {
          if (playerASocketId == socket.id) {
            setPlayerDisable(true);
            sendNotifyToBattingTeam(
              bowlingPlayer,
              { inning: "Inning2", round: inningRound },
              0
            );
          }
        } else if (currentCount == 5) {
          setPlayerDisable(true);
          setShowArtifact(true);
          setBowlingMessage("Select a booster below");
        } else if (
          !botSocket &&
          currentCount === 12 &&
          roomData?.isSecondPlayerBot &&
          counterRun &&
          roomData?.isBatSelected == 0
        ) {
          setBotSocket(true);
          setTimeout(() => {
            sendNotifyToBowlingTeam(
              "",
              { inning: "Inning2", round: inningRound },
              0
            );
          }, randomTime * 1000);
        } else if (currentCount == 0) {
          setBorderCount(0);
          setShowArtifact(false);
          setBowlingMessage("");
        }
      }
      const id = setInterval(timer, 1000);
      return () => clearInterval(id);
    }
  }, [currentCount, counterRun]);

  //Now enable for  timer for second innging
  useEffect(() => {
    dispatch(getUserArtifacts());
    setTimeout(() => {
      setTimerClose(false);
      setShowStartGame(true);
    }, 3000);

    setTimeout(() => {
      setShowStartGame(false);
      if (roomData?.isSecondPlayerBot) {
        setCounterRun(true);
        // dispatch(setCountDownEnable(false));
        setCount(timerCount);
      }
    }, 6000);
  }, [socket]);

  //send notification to  player2 (bowling team) for batsman is selected and save batsman record
  const sendNotifyToBowlingTeam = (batInfo, round, scoreVal) => {
    let checkBot = roomData?.isSecondPlayerBot ? 1 : 0;
    let batRound = {};
    if (roomData?.isSecondPlayerBot) {
      batRound = {
        isBotResult: checkBot,
        isScore: scoreVal,
        roomId: playerMatchedData?.roomId,
        socketId: playerBSocketId,
        roundInfo:
          !!round && Object.keys(round).length > 0 ? round : currentRound,
      };
    }
    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: batRound,
      }
    );
  };

  useEffect(() => {
    if (!playerMatchedData) {
      navigate("/");
      return;
    }
    getGroundUpdateSockte();
  }, [playerMatchedData?.roomData]);

  const getGroundUpdateSockte = () => {
    //get rounds updated data
    let inningChecked = roomData;
    let checkRound = currentRoundData;
    let roundVal = roomData?.currentRound.split("_")[1];
    let checkNextRound = "round_" + (+roundVal + +1);
    let currentRound = roomData?.currentRound;

    setCheckInningRound("PENDING");

    if (
      playerASocketId === socket.id &&
      roomData?.isBatSelected == 1 &&
      checkRound?.bowlerInfo == null &&
      checkRound?.batInfo != null
    ) {
      if (roomData?.isChanged == 1) {
        setInningRound(roomData?.currentRound);
      }
      setCount(timerCount);
      setBorderCount(timerCount);
      setCounterRun(true);
    } else if (
      playerASocketId == socket.id &&
      roomData?.isChanged == 1 &&
      roomData?.isBatSelected == 1 &&
      checkRound?.batInfo != null &&
      checkRound?.bowlerInfo != null &&
      checkRound?.roundStatus == "PROGRESS" &&
      !checkRound?.overFulfilled &&
      checkRound?.ballsPlayed == 0 &&
      checkRound?.bowlerAgain == 1
    ) {
      setBowlingMessage("");
    }
    // else if (
    //   playerASocketId == socket.id &&
    //   roomData?.isChanged == 1 &&
    //   roundInfo?.Inning2[roomData?.currentRound]?.batInfo != null
    // ) {
    //   setBowlingMessage("");
    // }

    if (inningChecked?.MatchStatus == "TIMEOUT") {
      // dispatch(setCountDownEnable(false));
      setCount(-1);
      navigate("/time-out");
    } else if (inningChecked?.MatchStatus == "COMPLETED") {
      if (
        (inningChecked?.WinnerId == "BOT" &&
          inningChecked?.isSecondPlayerBot &&
          checkRound?.bowlerInfo != null) ||
        (checkRound?.batInfo !== null &&
          checkRound?.bowlerInfo !== null &&
          inningChecked?.looserId == socket.id)
      ) {
        // setScoreShow(true);
        // setWaitModalForScore(false);

        let totalBalls =
          checkRound?.everyBall.length > 0 &&
          checkRound?.everyBall.map((item) => {
            return item;
          });
        setEveryBallData(totalBalls);
        handleBowlWithScore(
          totalBalls,
          "fivethRound",
          inningChecked,
          checkRound?.roundStatus
        );
        // navigate("/lost");
        setTimeout(() => {
          // setScoreShow(true);
          // dispatch(setCountDownEnable(false));
          setCount(-1);
          navigate("/lost");
        }, 5000);
      } else if (
        inningChecked?.winner == "TIE" &&
        checkRound?.batInfo == null &&
        checkRound?.bowlerInfo == null
      ) {
        navigate("/match-tie");
      } else if (
        (checkRound?.batInfo != null &&
          checkRound?.bowlerInfo == null &&
          inningChecked?.WinnerId == socket.id) ||
        (checkRound?.batInfo == null &&
          checkRound?.bowlerInfo != null &&
          inningChecked?.WinnerId == socket.id)
      ) {
        navigate("/winner");
      } else if (
        (checkRound?.batInfo != null &&
          checkRound?.bowlerInfo == null &&
          inningChecked?.looserId == socket.id) ||
        (checkRound?.batInfo == null &&
          checkRound?.bowlerInfo != null &&
          inningChecked?.looserId == socket.id)
      ) {
        navigate("/lost");
      } else if (
        checkRound?.batInfo !== null &&
        checkRound?.bowlerInfo !== null &&
        inningChecked?.WinnerId == socket.id
      ) {
        // setScoreShow(true);
        // setWaitModalForScore(false);

        // setTimeout(() => {
        //   setScoreShow(true);
        //   // dispatch(setCountDownEnable(false));
        //   setCount(-1);
        //   navigate("/winner");
        // }, 5000);
        let totalBalls =
          checkRound?.everyBall.length > 0 &&
          checkRound?.everyBall.map((item) => {
            return item;
          });
        setEveryBallData(totalBalls);
        // setCount(-1);
        handleBowlWithScore(
          totalBalls,
          "fivethRound",
          inningChecked,
          checkRound?.roundStatus
        );
        // navigate("/winner");
        setTimeout(() => {
          // setScoreShow(true);
          // dispatch(setCountDownEnable(false));
          setCount(-1);
          navigate("/winner");
        }, 5000);
      }
    } else {
      //complete round checks
      if (checkNextRound == "round_6" && currentRound == "round_5") {
        if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "COMPLETED"
        ) {
          let totalBalls =
            checkRound?.everyBall.length > 0 &&
            checkRound?.everyBall.map((item) => {
              return item;
            });
          setEveryBallData(totalBalls);
          setCurrentRound({ inning: "Inning2", round: "round_5" });
          setInningRound("round_5");
          handleBowlWithScore(
            totalBalls,
            "fivethRound",
            inningChecked,
            checkRound?.roundStatus
          );
          // showScoreModal("fivethRound", inningChecked, checkRound?.roundStatus);
        } else if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "PROGRESS" &&
          roomData?.isBatSelected == 0 &&
          checkRound?.overFulfilled
        ) {
          let totalBalls =
            checkRound?.everyBall.length > 0 &&
            checkRound?.everyBall.map((item) => {
              return item;
            });
          setEveryBallData(totalBalls);
          setInningRound("round_5");
          setCurrentRound({ inning: "Inning2", round: "round_5" });
          handleBowlWithScore(
            totalBalls,
            "forthRound",
            inningChecked,
            checkRound?.roundStatus
          );
          // showScoreModal("forthRound", inningChecked, checkRound?.roundStatus);
        }
      } else {
        if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "COMPLETED" &&
          checkNextRound?.batInfo == null &&
          checkNextRound?.bowlerInfo == null &&
          checkRound?.overFulfilled
        ) {
          let totalBalls =
            checkRound?.everyBall.length > 0 &&
            checkRound?.everyBall.map((item) => {
              return item;
            });
          setEveryBallData(totalBalls);
          setPlayerDisable(false);
          if (currentRound == "round_1") {
            setInningRound("round_2");
            setCurrentRound({ inning: "Inning2", round: "round_2" });
            handleBowlWithScore(
              totalBalls,
              "firstRound",
              inningChecked,
              checkRound?.roundStatus
            );
            // showScoreModal(
            //   "firstRound",
            //   inningChecked,
            //   checkRound?.roundStatus
            // );
          } else if (currentRound == "round_2") {
            setInningRound("round_3");
            setCurrentRound({ inning: "Inning2", round: "round_3" });
            handleBowlWithScore(
              totalBalls,
              "secondRound",
              inningChecked,
              checkRound?.roundStatus
            );
            // showScoreModal(
            //   "secondRound",
            //   inningChecked,
            //   checkRound?.roundStatus
            // );
          } else if (currentRound == "round_3") {
            setInningRound("round_4");
            setCurrentRound({ inning: "Inning2", round: "round_4" });
            handleBowlWithScore(
              totalBalls,
              "thirdRound",
              inningChecked,
              checkRound?.roundStatus
            );
            // showScoreModal(
            //   "thirdRound",
            //   inningChecked,
            //   checkRound?.roundStatus
            // );
          } else if (currentRound == "round_4") {
            setInningRound("round_5");
            setCurrentRound({ inning: "Inning2", round: "round_5" });
            handleBowlWithScore(
              totalBalls,
              "forthRound",
              inningChecked,
              checkRound?.roundStatus
            );
            // showScoreModal(
            //   "forthRound",
            //   inningChecked,
            //   checkRound?.roundStatus
            // );
          }
        } else if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "COMPLETED" &&
          checkNextRound?.batInfo == null &&
          checkNextRound?.bowlerInfo == null &&
          !checkRound?.overFulfilled
        ) {
          let totalBalls =
            checkRound?.everyBall.length > 0 &&
            checkRound?.everyBall.map((item) => {
              return item;
            });
          setEveryBallData(totalBalls);
          setInningRound("");
          setCurrentRound({});
          if (currentRound == "round_1") {
            setInningRound("round_2");
            setCurrentRound({ inning: "Inning2", round: "round_2" });
            handleBowlWithScore(
              totalBalls,
              "firstRound",
              inningChecked,
              "PENDING",
              "round_2"
            );
            // showScoreModal("firstRound", inningChecked, "PENDING", "round_2");
          } else if (currentRound == "round_2") {
            setInningRound("round_3");
            setCurrentRound({ inning: "Inning2", round: "round_3" });
            handleBowlWithScore(
              totalBalls,
              "secondRound",
              inningChecked,
              "PENDING",
              "round_3"
            );
            // showScoreModal("secondRound", inningChecked, "PENDING", "round_3");
          } else if (currentRound == "round_3") {
            setInningRound("round_4");
            setCurrentRound({ inning: "Inning2", round: "round_4" });
            handleBowlWithScore(
              totalBalls,
              "thirdRound",
              inningChecked,
              "PENDING",
              "round_4"
            );
            // showScoreModal("thirdRound", inningChecked, "PENDING", "round_4");
          } else if (currentRound == "round_4") {
            setInningRound("round_5");
            setCurrentRound({ inning: "Inning2", round: "round_5" });
            handleBowlWithScore(
              totalBalls,
              "forthRound",
              inningChecked,
              "PENDING",
              "round_5"
            );
            // showScoreModal("forthRound", inningChecked, "PENDING", "round_5");
          }
        } else if (
          checkRound?.batInfo != null &&
          checkRound?.bowlerInfo != null &&
          checkRound?.roundStatus == "PROGRESS" &&
          checkNextRound?.batInfo == null &&
          checkNextRound?.bowlerInfo == null &&
          roomData?.isBatSelected == 0 &&
          checkRound?.overFulfilled
        ) {
          let totalBalls =
            checkRound?.everyBall.length > 0 &&
            checkRound?.everyBall.map((item) => {
              return item;
            });
          setEveryBallData(totalBalls);
          setCurrentRound({});
          if (currentRound == "round_1") {
            setInningRound("round_1");
            // setCurrentRound({ inning: "Inning2", round: "round_1" });
            handleBowlWithScore(
              totalBalls,
              "firstRound",
              inningChecked,
              "PROGRESS"
            );
            // showScoreModal("firstRound", inningChecked, "PROGRESS");
          } else if (currentRound == "round_2") {
            setInningRound("round_2");
            // setCurrentRound({ inning: "Inning2", round: "round_2" });
            handleBowlWithScore(
              totalBalls,
              "secondRound",
              inningChecked,
              "PROGRESS"
            );
            // showScoreModal("secondRound", inningChecked, "PROGRESS");
          } else if (currentRound == "round_3") {
            setInningRound("round_3");
            // setCurrentRound({ inning: "Inning2", round: "round_3" });
            handleBowlWithScore(
              totalBalls,
              "thirdRound",
              inningChecked,
              "PROGRESS"
            );
            // showScoreModal("thirdRound", inningChecked, "PROGRESS");
          } else if (currentRound == "round_4") {
            setInningRound("round_4");
            // setCurrentRound({ inning: "Inning2", round: "round_4" });
            handleBowlWithScore(
              totalBalls,
              "forthRound",
              inningChecked,
              "PROGRESS"
            );
            // showScoreModal("forthRound", inningChecked, "PROGRESS");
          }
        }
      }
    }
  };

  const showScoreModal = (round, inningChecked, roundStatus, chkRound) => {
    // dispatch(setCountDownEnable(false));
    setWaitModalForScore(false);
    if (roundStatus === "PENDING") {
      setPlayerDisable(true);
      if (roomData?.isSecondPlayerBot) {
        setTimeout(() => {
          setBowlingMessage("");
          sendNotifyToBowlingTeam(
            "",
            { inning: "Inning2", round: chkRound },
            0
          );
        }, 2000);

        // setTimeout(() => {
        setScoreShow(false);
        setBowlingMessage("Wait for opponent selection");
        sendNotifyToBattingTeam("", { inning: "Inning2", round: chkRound }, 0);
        // }, 4000);

        setTimeout(() => {
          setPlayerDisable(true);
          setBotSocket(false);
          // setScoreShow(false);
          setBowlingMessage("");
          sendNotifyToBattingTeam(
            "",
            { inning: "Inning2", round: chkRound },
            scoreStatus
          );
        }, 5000);
      }
    } else if (
      roundStatus === "PROGRESS" &&
      roomData?.isBatSelected == 0 &&
      inningChecked?.RoundsInfo?.Inning2?.status == "PROGRESS"
    ) {
      // setTimeout(() => {
      setBotSocket(false);
      setScoreShow(false);

      setPlayerDisable(false);
      setSelectedArtifacts([]);
      sendNotifyToBowlingTeam(
        "",
        { inning: "Inning2", round: inningRound, again: 1 },
        1
      );
      setYourPlayer(false);
      setShowArtifact(false);
      setBowlingMessage("Select a bowler below");
      setSelectedArtifacts([]);
      setBowlingPlayer({});
      // }, 5000);
    } else {
      if (inningChecked?.RoundsInfo?.Inning2?.status == "COMPLETED") {
        // setTimeout(() => {
        if (inningChecked?.winner == "TIE") {
          navigate("/match-tie");
        } else if (
          playerASocketId == socket.id &&
          inningChecked?.WinnerId == playerASocketId
        ) {
          navigate("/winner");
        } else if (
          playerASocketId == socket.id &&
          inningChecked?.looserId == playerASocketId
        ) {
          navigate("/lost");
        }
        // }, 5000);
      }

      // setTimeout(() => {
      setSelectedArtifacts([]);
      setBotSocket(false);
      setCheckInningRound("COMPLETED");
      setScoreShow(false);

      if (round == "fivethRound") {
        setBowlingMessage("Second inning is complete");
      } else {
        setBowlingPlayer({});

        if (roomData?.isSecondPlayerBot) {
          // dispatch(setCountDownEnable(false));
          setCount(timerCount);
        }
        setBowlingMessage("Select a bowler below");
      }
      setYourPlayer(true);
      setShowArtifact(false);
      // }, 5000);
    }
  };

  //send notification to  player1 (batting team) for bowler is selected
  const sendNotifyToBattingTeam = (bowlerInfo, round, scoreVal) => {
    let bowlWithArt =
      Object.keys(bowlingPlayer).length > 0
        ? { ...bowlingPlayer, artifacts: selectedArtifacts }
        : bowlerInfo;
    if (scoreVal == 1 && roomData?.overCompleted) {
      dispatch(setBowlerRecords([...bowlerRecords, bowlWithArt?.nftId]));
    }
    // dispatch(setBowlerRecords([...bowlerRecords, bowlWithArt?.nftId]));

    let bowlerRound = {
      isScore: scoreVal,
      roomId: playerMatchedData?.roomId,
      socketId: playerASocketId,
      roundInfo:
        !!round && Object.keys(round).length > 0 ? round : currentRound,
      bowlerInfo: bowlWithArt,
    };
    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: bowlerRound,
      }
    );
  };

  const selectYourPlayer = (
    playerType,
    playerSocketId,
    cardId,
    playerInfo,
    card_Type
  ) => {
    setChangeBat(false);
    setPlayerDisable(false);
    if (roundInfo?.Inning2?.status == "PROGRESS") {
      let roundInfoPlayer = { inning: "Inning2", round: inningRound };
      setCurrentRound(roundInfoPlayer);
      if (playerType == "BOWL" && playerSocketId != socket.id) {
        if (roomData?.isBatSelected == 1) {
          setBowlingPlayer(playerInfo);

          sendNotifyToBattingTeam(playerInfo, roundInfoPlayer, 0);
          setYourPlayer(true);
          // setShowArtifact(true);
          document.body.className = "noBackDrop";
          setBowlingMessage("");
        } else {
          toast.error("Wait for opponent select the batsman", {
            toastId: "error2",
          });
        }
      }
    }
  };

  const artifactCallBack = (data) => {
    if (data?.status == 200) {
      dispatch(getUserArtifacts());
    }
    return null;
  };

  useEffect(() => {
    if (selectedArtifacts.length > 0) {
      sendNotifyToBattingTeam("", { inning: "Inning2", round: inningRound }, 0);
    }
  }, [selectedArtifacts]);

  const showArtEffectHandler = (id, card_type) => {
    if (
      playerASocketId == socket.id &&
      ((batBoosterFirstInning.length == 3 &&
        bowlBoosterSecondInning.length < 2) ||
        (batBoosterFirstInning.length < 3 &&
          bowlBoosterSecondInning.length <= 2))
    ) {
      if (selectedArtifacts.length < 1) {
        setBowlingMessage("");
        setSelectedArtifacts([...selectedArtifacts, id]);
        // dispatch(setBowlBosterInningSecond([...bowlBoosterSecondInning, id]));
        // dispatch(deductArtifact({ artefact_id: id }, artifactCallBack));
      }
    } else {
      toast.error(
        "You can choose a maximum 3 boosters in an inning & 5 in a game.",
        {
          toastId: "error3",
        }
      );
    }
  };

  //change batsman
  const changeBatsman = () => {
    setYourPlayer(false);
    setShowArtifact(false);
    setSelectedArtifacts([]);
    setChangeBat(true);
  };

  //already played ids
  let batPlayerIds = [];
  let bowlerPlayedIds = [];

  for (let i = 1; i <= 5; i++) {
    let round = "round_" + i;
    if (roundInfo?.Inning2?.[round]?.batInfo) {
      batPlayerIds.push(roundInfo?.Inning2?.[round]?.batInfo?.nftId);
    }
    if (roundInfo?.Inning2?.[round]?.bowlerInfo) {
      bowlerPlayedIds.push(roundInfo?.Inning2?.[round]?.bowlerInfo?.nftId);
    }
  }
  const removeArtifact = () => {
    setBowlingMessage("Select a booster below");
    setSelectedArtifacts([]);
  };
  //random bowler selection
  const randomSelectPlayer = (player) => {
    let cardsList = [...playerData];
    let boosterId = [];

    // const nftIndex = cardsList.findIndex(
    //   (item) => item?.nftId == roomData?.currentBowler
    // );
    if (player == "bowler") {
      let roundInfoPlayer = { inning: "Inning2", round: inningRound };
      setYourPlayer(true);
      setCurrentRound(roundInfoPlayer);

      const toFindDuplicates = bowlerRecords.filter(
        (item, index) => bowlerRecords.indexOf(item) !== index
      );

      //remove duplicate value
      toFindDuplicates &&
        toFindDuplicates.length > 0 &&
        toFindDuplicates.map((e) => {
          const cardsListIndex = cardsList.findIndex(
            (item) => item?.nftId == e
          );
          if (cardsListIndex !== -1) {
            cardsList.splice(cardsListIndex, 1);
          }
        });

      // if (nftIndex !== -1) {
      //   cardsList.splice(nftIndex, 1);
      // }

      const randomIndex = Math.floor(Math.random() * cardsList.length);
      const nftData = cardsList[randomIndex];

      let playerInfo = {
        outlineImage: nftData?.outlineImage,
        da_id: nftData?.da_id,
        nftId: nftData?.nftId,
        name: nftData?.title,
        gameTitle: nftData?.gameTitle,
        img: nftData?.nftLogo,
        artifacts: boosterId,
        isArtifact: 0,
      };

      setBowlingPlayer(playerInfo);
      sendNotifyToBattingTeam(
        playerInfo,
        { inning: "Inning2", round: inningRound },
        0
      );

      setPlayerDisable(true);
    }

    // if (
    //   currentRoundData?.batInfo !== null
    // ) {
    //   setBowlingMessage("");
    // } else {
    //   setBowlingMessage("Wait for opponent selection");
    // }
  };

  // Wait function to hold the game till Over ball Data is displayed
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  //handling Over ball-by-ball Data along with continuing the game
  const handleBowlWithScore = (
    roundInfo,
    round,
    inningStatus,
    roundStatus,
    chkRound
  ) => {
    const len = roundInfo[1]?.ballData
      ? roundInfo[0]?.ballData.length + roundInfo[1]?.ballData.length
      : roundInfo[0]?.ballData.length;
    setBallShow(true);
    len <= 4
      ? wait(4 * 1000).then(() => {
          setBallShow(false);
          if (chkRound) {
            showScoreModal(round, inningStatus, roundStatus, chkRound);
          } else {
            showScoreModal(round, inningStatus, roundStatus);
          }
        })
      : wait(len * 1000).then(() => {
          setBallShow(false);
          if (chkRound) {
            showScoreModal(round, inningStatus, roundStatus, chkRound);
          } else {
            showScoreModal(round, inningStatus, roundStatus);
          }
        });
  };

  return (
    <>
      <div className="Firstplayer">
        {!!playerMatchedData &&
          !!playerMatchedData?.playerIds &&
          !!playerMatchedData?.playerIds[opponetSocket] &&
          playerMatchedData?.playerIds[opponetSocket].length > 0 && (
            <Oppolistcard
              playerMatchedData={playerMatchedData?.playerIds[opponetSocket]}
            />
          )}
        <div className="grounPlay">
          <SelectedOpponentPlayer
            playersSocketId={"Bot"}
            roundInfo={
              playerASocketId == socket.id && roomData?.isBatSelected == 1
                ? roundInfo?.Inning2[roomData?.currentRound]
                : playerASocketId == socket.id &&
                  roomData?.isBatSelected == 0 &&
                  roomData?.isChanged == 1 &&
                  roundInfo?.Inning2[roomData?.currentRound]?.batInfo != null &&
                  roundInfo?.Inning2[roomData?.currentRound]?.bowlerInfo != null
                ? roundInfo?.Inning2[roomData?.currentRound]
                : {}
            }
            roomData={roomData}
            socket={socket}
            artifactList={artifactList}
            selectedArtifacts={selectedArtifacts}
            checkInningRound={checkInningRound}
            inning={"second"}
          />

          <div>
            <div className="plaer">
              <div className="ground">
                {borderCount > 0 && <BorderLine borderCount={borderCount} />}

                <img src={addground} alt="addground" />
              </div>
              <div className="main_Contint">
                {bowlingPlayer &&
                  Object.keys(bowlingPlayer).length > 0 &&
                  yourPlayer &&
                  !showArtifact &&
                  bowlingMessage == "" && (
                    <SelectedYourPlayer
                      roomData={roomData}
                      opponent={false}
                      playersSocketId={playerASocketId}
                      socket={socket}
                      bowlingPlayer={bowlingPlayer}
                      // bowlingPlayer={bowlingPlayer}
                      artifactList={artifactList}
                      selectedArtifacts={selectedArtifacts}
                      inning="second"
                      checkInningRound={checkInningRound}
                    />
                  )}

                {showArtifact &&
                  bowlingMessage == "" &&
                  selectedArtifacts &&
                  selectedArtifacts.length > 0 && (
                    <SelectedBooster
                      removeArtifact={removeArtifact}
                      selectedArtifacts={selectedArtifacts}
                      artifactList={artifactList}
                    />
                  )}

                {bowlingMessage != "" && <p>{bowlingMessage}</p>}
              </div>
            </div>
          </div>
        </div>
        {ballShow && !showArtifact && <Overlist Overlist={everyBallData} />}
        {!ballShow && !showArtifact && playerData.length > 0 && (
          <Yourlistcard
            playerDisable={playerDisable}
            batPlayerIds={batPlayerIds}
            bowlerPlayedIds={bowlerPlayedIds}
            playerMatchedData={playerData}
            roomData={roomData}
            roundInfo={roundInfo?.Inning2}
            playerASocketId={playerASocketId}
            playerBSocketId={playerBSocketId}
            socket={socket}
            selectYourPlayer={selectYourPlayer}
            inning="second"
            bowlerRecords={bowlerRecords}
          />
        )}
        {!ballShow && showArtifact && (
          <YourBooster
            // playerDisable={playerDisable}
            selectedArtifacts={selectedArtifacts}
            artifactList={artifactList}
            playerASocketId={playerASocketId}
            playerBSocketId={playerBSocketId}
            inning="second"
            socket={socket}
            disable={true}
            showArtEffectHandler={showArtEffectHandler}
            // boosterFirstInning={boosterFirstInning}
          />
        )}
      </div>
      {scoreShow && currentRoundData?.batInfo && (
        <ScoreBoredModal
          changeBat={changeBat}
          // continueBtn={continueBtn}
          changeBatsman={changeBatsman}
          // continueGame={continueGame}
          playersSocketId={playerASocketId}
          currentRound={roomData?.currentRound}
          inning="Second"
          roomData={roomData}
          roundInfo={currentRoundData}
        />
      )}

      {roundInfo?.Inning2?.round_1 == null && timerclose && (
        <InningsChangeModal playerType={"Bowler"} roomData={roomData} />
      )}

      {roundInfo?.Inning2?.round_1 == null && showStartGame && (
        <PlayerTurnModal playerSocketId={"Bowler"} />
      )}
    </>
  );
}

export default BotInningSecond;
