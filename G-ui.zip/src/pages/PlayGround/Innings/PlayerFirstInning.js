import React, { useState, useEffect, useRef } from "react";
import { toast } from "react-toastify";
import "../../Ground/Ground.scss";
import { useNavigate } from "react-router-dom";
import {
  startCountDown,
  setCountDownEnable,
  getUserArtifacts,
  deductArtifact,
  setBatBosterInningFirst,
  setBowlBosterInningFirst,
  setBowlerRecords,
} from "../../../redux/user/action";
import { useDispatch, useSelector } from "react-redux";
import socket from "../../../socket";
// new flow files
import Oppolistcard from "../GroundCards/Oppolistcard";
import Yourlistcard from "../GroundCards/Yourlistcard";
import YourBooster from "../Booster/YourBooster";
import SelectedYourPlayer from "../Playing/SelectedYourPlayer";
import ScoreBoredModal from "../../../modals/ScoreBoredModal";
import WaitingModal from "../../../modals/WaitingModal";
import SelectedOpponentPlayer from "../Playing/SelectedOpponentplayer";
import SelectedBooster from "../Booster/SelectedBooster";
import addground from "../../../assets/images/addground.png";
import BorderLine from "../Common/BoderLine";
let timerCount = 15;
let scoreStatus = 1;
function PlayerInningFirst(props) {
  const { playerMatchedData, setCheckRound, artifactList } = props;
  let roomData = playerMatchedData?.roomData;
  let roundInfo = roomData?.RoundsInfo;
  let currentRoundData = roomData?.RoundsInfo?.Inning1[roomData?.currentRound];

  const dispatch = useDispatch();
  let navigate = useNavigate();
  const [borderCount, setBorderCount] = useState(0);
  const [showStartGame, setShowStartGame] = useState(false);
  const [yourPlayer, setYourPlayer] = useState(false);
  const [showArtifact, setShowArtifact] = useState(false);
  const [battingPlayer, setBattingPlayer] = useState({});
  const [bowlingPlayer, setBowlingPlayer] = useState({});
  const [cardType, setCartType] = useState();
  const [currentRound, setCurrentRound] = useState({});
  const [timerclose, setTimerClose] = useState(true);
  const [bowlingMessage, setBowlingMessage] = useState("Select a bowler below");
  const [battingMessage, setBattingMessage] = useState(
    "Select a batsman below"
  );
  const [scoreShow, setScoreShow] = useState(false);
  const [inningRound, setInningRound] = useState("round_1");
  const [checkInningRound, setCheckInningRound] = useState("PENDING");
  const [counterRun, setCounterRun] = useState(false);
  const [bowlerBot, setBowlerBot] = useState(false);
  const [playerDisable, setPlayerDisable] = useState(false);
  const [changeBat, setChangeBat] = useState(false);
  const [isChangeBooster, setIsChangeBooster] = useState(false);

  const [emptyArtifact, setEmptyArtifact] = useState(false);

  const changeBatRef = useRef(changeBat);
  changeBatRef.current = changeBat;

  let playerASocketId = roomData?.playerASocketId;
  let playerBSocketId = roomData?.playerBSocketId;

  let socketPlayerList =
    playerASocketId == socket.id ? playerASocketId : playerBSocketId;
  let opponetSocket =
    playerASocketId == socket.id ? playerBSocketId : playerASocketId;

  let playerData =
    !!playerMatchedData &&
    !!playerMatchedData?.playerIds &&
    !!playerMatchedData?.playerIds[socketPlayerList] &&
    playerMatchedData?.playerIds[socketPlayerList].length > 0
      ? playerMatchedData?.playerIds[socketPlayerList]
      : [];

  const [selectedArtifacts, setSelectedArtifacts] = useState([]);

  const batBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.batBoosterFirstInning
  );

  const bowlBoosterFirstInning = useSelector(
    (state) => state?.userReducer?.bowlBoosterFirstInning
  );

  // console.log("boosterFirstInning", boosterFirstInning);
  const bowlerRecords = useSelector(
    (state) => state?.userReducer?.bowlerRecords
  );

  useEffect(() => {
    if (!playerMatchedData) {
      navigate("/");
      return;
    }
    dispatch(getUserArtifacts());
    setTimeout(() => {
      setTimerClose(false);
      setShowStartGame(true);
    }, 3000);

    setTimeout(() => {
      setShowStartGame(false);
      if (playerASocketId == socket.id) {
        setCounterRun(true);
        setCount(timerCount);
        setBorderCount(timerCount);
      }
      if (playerBSocketId == socket.id) {
        setCounterRun(false);
      }
    }, 6000);
  }, [socket]);

  const [currentCount, setCount] = useState(timerCount);
  const timer = () => setCount(currentCount - 1);

  useEffect(() => {
    if (counterRun) {
      if (currentCount < 0) {
        setBorderCount(0);
        if (Object.keys(battingPlayer).length > 0) {
          setPlayerDisable(true);
          if (
            roomData?.RoundsInfo?.Inning1?.[roomData?.currentRound]
              ?.bowlerInfo !== null
          ) {
            setBattingMessage("");
          } else {
            setBattingMessage("Wait for opponent selection");
          }

          if (
            playerASocketId == socket.id &&
            selectedArtifacts &&
            selectedArtifacts.length > 0
          ) {
            if (
              playerASocketId == socket.id &&
              roomData?.RoundsInfo?.Inning1?.[roomData?.currentRound]
                ?.bowlerAgain == 0
            ) {
              dispatch(
                setBatBosterInningFirst([
                  ...batBoosterFirstInning,
                  selectedArtifacts[0],
                ])
              );
              dispatch(
                deductArtifact(
                  { artefact_id: selectedArtifacts[0] },
                  artifactCallBack
                )
              );
            }

            sendNotifyToBowlingTeam(
              "",
              { inning: "Inning1", round: inningRound },
              0
            );
          }

          setTimeout(() => {
            sendNotifyToBowlingTeam(
              "",
              { inning: "Inning1", round: inningRound },
              scoreStatus
            );
          }, 1000);
          setShowArtifact(false);
        }
        //For bowling auto sunmit
        if (Object.keys(bowlingPlayer).length > 0) {
          if (
            playerBSocketId == socket.id &&
            selectedArtifacts &&
            selectedArtifacts.length > 0
          ) {
            dispatch(
              setBowlBosterInningFirst([
                ...bowlBoosterFirstInning,
                selectedArtifacts[0],
              ])
            );

            dispatch(
              deductArtifact(
                { artefact_id: selectedArtifacts[0] },
                artifactCallBack
              )
            );

            sendNotifyToBattingTeam(
              "",
              { inning: "Inning1", round: inningRound },
              0
            );
          }
          setTimeout(() => {
            sendNotifyToBattingTeam(
              "",
              { inning: "Inning1", round: inningRound },
              scoreStatus
            );
          }, 1000);
          setShowArtifact(false);
        }
        return;
      } else {
        if (currentCount == 8) {
          if (
            roomData?.isBatSelected == 0 &&
            Object.keys(battingPlayer).length == 0 &&
            playerASocketId == socket.id
          ) {
            setBattingMessage("");
            randomSelectPlayer("batsman");
          } else if (
            roomData?.isBatSelected == 1 &&
            Object.keys(bowlingPlayer).length == 0 &&
            playerBSocketId == socket.id
          ) {
            setBowlingMessage("");
            randomSelectPlayer("bowler");
          }
        } else if (currentCount == 5) {
          if (
            currentRoundData?.roundStatus == "PROGRESS" &&
            currentRoundData?.bowlerInfo != null &&
            !currentRoundData?.overFulfilled &&
            playerASocketId == socket.id
          ) {
            setCount(-1);
            setBorderCount(0);
          } else {
            if (playerASocketId == socket.id) {
              setShowArtifact(true);
              setBattingMessage("Select a booster below");
            } else {
              setShowArtifact(true);
              setBowlingMessage("Select a booster below");
            }
          }
          setPlayerDisable(true);
        } else if (currentCount == 0) {
          setBorderCount(0);
          setShowArtifact(false);
          setBattingMessage("Wait for opponent selection");
          setBowlingMessage("");
        } else if (currentCount == 6) {
          if (playerASocketId == socket.id) {
            sendNotifyToBowlingTeam(
              battingPlayer,
              { inning: "Inning1", round: inningRound },
              0
            );
          } else if (playerBSocketId == socket.id) {
            sendNotifyToBattingTeam(
              bowlingPlayer,
              { inning: "Inning1", round: inningRound },
              0
            );
          }
        }
      }
    }
    const id = setInterval(timer, 1000);
    return () => clearInterval(id);
  }, [currentCount]);

  //5 second select booster for same batsman

  const [boosterCount, setBoosterCount] = useState(0);
  const timerBooster = () => setBoosterCount(boosterCount - 1);
  useEffect(() => {
    if (isChangeBooster) {
      if (boosterCount < 0) {
        setBorderCount(0);
        sendNotifyToBowlingTeam(
          "",
          { inning: "Inning1", round: inningRound, again: 1 },
          0,
          "withBooster"
        );
        setTimeout(() => {
          sendNotifyToBowlingTeam(
            "",
            { inning: "Inning1", round: inningRound, again: 1 },
            scoreStatus,
            "withBooster"
          );
          setBattingMessage("Wait for opponent selection");
        }, [1000]);
        setShowArtifact(false);
        setIsChangeBooster(false);

        return;
      } else {
        if (boosterCount == 0) {
          setShowArtifact(false);
          setBorderCount(0);
        }
      }
      // setBattingMessage("");

      const id = setInterval(timerBooster, 1000);
      return () => clearInterval(id);
    }
  }, [boosterCount]);

  //send notification to  player2 (bowling team) for batsman is selected and save batsman record
  const sendNotifyToBowlingTeam = (batInfo, round, scoreVal, withBooster) => {
    let batWithArt =
      Object.keys(battingPlayer).length > 0
        ? { ...battingPlayer, artifacts: selectedArtifacts }
        : batInfo;

    let roundInfoData =
      !!round && Object.keys(round).length > 0 ? round : currentRound;
    if (
      roundInfoData?.again == 1 &&
      scoreVal == 0 &&
      playerASocketId == socket.id &&
      selectedArtifacts &&
      selectedArtifacts.length > 0 &&
      !!withBooster
    ) {
      dispatch(
        setBatBosterInningFirst([
          ...batBoosterFirstInning,
          selectedArtifacts[0],
        ])
      );
      dispatch(
        deductArtifact({ artefact_id: selectedArtifacts[0] }, artifactCallBack)
      );
    }

    let batRound = {
      isScore: scoreVal,
      roomId: playerMatchedData?.roomId,
      socketId: playerASocketId,
      roundInfo: roundInfoData,
      batInfo: batWithArt,
    };
    socket.emit(
      playerMatchedData?.roomData?.isSecondPlayerBot
        ? "game_bot_room_update"
        : "game_room_update",
      {
        RoundsInfo: batRound,
      }
    );
  };

  useEffect(() => {
    if (!playerMatchedData) {
      navigate("/");
      return;
    }
    getGroundUpdateSockte();
  }, [playerMatchedData?.roomData]);

  //empty booster selected for is again batsman
  useEffect(() => {
    if (selectedArtifacts && selectedArtifacts.length == 0 && emptyArtifact) {
      sendNotifyToBowlingTeam(
        "",
        { inning: "Inning1", round: inningRound, again: 1 },
        0
      );

      setTimeout(() => {
        sendNotifyToBowlingTeam(
          "",
          { inning: "Inning1", round: inningRound, again: 1 },
          scoreStatus
        );
        setEmptyArtifact(false);
        setBattingMessage("Wait for opponent selection");
      }, 1000);
    }
  }, [emptyArtifact]);

  const getGroundUpdateSockte = () => {
    //get rounds updated data
    let inningChecked = roomData;
    let inningStatus = roomData?.RoundsInfo?.Inning1?.status;
    let checkRound = roomData?.RoundsInfo?.Inning1?.[roomData?.currentRound];
    let roundVal = roomData?.currentRound.split("_")[1];
    let checkNextRound = "round_" + (+roundVal + +1);
    let currentRound = roomData?.currentRound;

    setCheckInningRound("PENDING");
    if (
      roomData?.isBatSelected == 1 &&
      playerBSocketId == socket.id &&
      checkRound?.bowlerInfo == null
    ) {
      if (roomData?.isChanged == 1) {
        setInningRound(roomData?.currentRound);
      }
      setCount(timerCount);
      setBorderCount(timerCount);
      setBowlingMessage("Select a bowler below");
      setCounterRun(true);
    } else if (
      playerASocketId == socket.id &&
      roomData?.isBatSelected == 0 &&
      roomData?.isChanged == 1 &&
      currentRoundData?.batInfo == null &&
      currentRoundData?.bowlerInfo != null
    ) {
      setBattingMessage("Select a batsman below");
    } else if (
      playerBSocketId == socket.id &&
      roomData?.isBatSelected == 0 &&
      roomData?.isChanged == 1 &&
      currentRoundData?.batInfo != null &&
      currentRoundData?.bowlerInfo != null
    ) {
      setBowlingMessage("");
    } else if (
      playerASocketId == socket.id &&
      currentRoundData?.bowlerInfo != null &&
      (roomData?.isBatSelected == 1 || roomData?.isChanged == 1)
    ) {
      setBattingMessage("");
    }
    if (inningChecked?.MatchStatus == "TIMEOUT") {
      dispatch(setCountDownEnable(false));
      setCount(-1);
      navigate("/time-out");
    } else if (inningChecked?.MatchStatus == "COMPLETED") {
      if (
        inningChecked?.WinnerId == "BOT" &&
        inningChecked?.isSecondPlayerBot &&
        checkRound?.batInfo == null
      ) {
        dispatch(setCountDownEnable(false));
        setCount(-1);
        navigate("/lost");
      } else if (
        inningChecked?.winner == "TIE" &&
        checkRound?.batInfo == null &&
        checkRound?.bowlerInfo == null
      ) {
        navigate("/match-tie");
      } else if (
        (checkRound?.batInfo != null &&
          checkRound?.bowlerInfo == null &&
          playerASocketId == socket.id) ||
        (checkRound?.batInfo == null &&
          checkRound?.bowlerInfo != null &&
          playerBSocketId == socket.id)
      ) {
        navigate("/winner");
      } else if (
        (checkRound?.batInfo == null &&
          checkRound?.bowlerInfo != null &&
          playerASocketId == socket.id) ||
        (checkRound?.batInfo != null &&
          checkRound?.bowlerInfo == null &&
          playerBSocketId == socket.id)
      ) {
        navigate("/lost");
      }
    }

    //complete round checks
    if (checkNextRound == "round_6" && currentRound == "round_5") {
      if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED"
      ) {
        setCurrentRound({ inning: "Inning1", round: "round_5" });
        setScoreShow(true);
        setPlayerDisable(false);
        showScoreModal("fivethRound", inningStatus, checkRound?.roundStatus);
      } else if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "PROGRESS" &&
        roomData?.isBatSelected == 0 &&
        checkRound?.overFulfilled
      ) {
        setInningRound("round_5");
        setCurrentRound({ inning: "Inning1", round: "round_5" });
        setScoreShow(true);
        showScoreModal("forthRound", inningStatus, checkRound?.roundStatus);
      }
    } else {
      if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        checkRound?.overFulfilled
      ) {
        setPlayerDisable(false);
        // setPlayerDisable(false); ////dddd
        if (currentRound == "round_1") {
          setInningRound("round_2");
          setCurrentRound({ inning: "Inning1", round: "round_2" });
          setScoreShow(true);
          showScoreModal("firstRound", inningStatus, checkRound?.roundStatus);
        } else if (currentRound == "round_2") {
          setInningRound("round_3");
          setCurrentRound({ inning: "Inning1", round: "round_3" });
          setScoreShow(true);
          showScoreModal("secondRound", inningStatus, checkRound?.roundStatus);
        } else if (currentRound == "round_3") {
          setInningRound("round_4");
          setCurrentRound({ inning: "Inning1", round: "round_4" });
          setScoreShow(true);
          showScoreModal("thirdRound", inningStatus, checkRound?.roundStatus);
        } else if (currentRound == "round_4") {
          setInningRound("round_5");
          setCurrentRound({ inning: "Inning1", round: "round_5" });
          setScoreShow(true);
          showScoreModal("forthRound", inningStatus, checkRound?.roundStatus);
        }
      } else if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "COMPLETED" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        !checkRound?.overFulfilled
        // &&
        // !inningChecked?.isSecondPlayerBot
      ) {
        setInningRound("");
        setCurrentRound({});
        if (currentRound == "round_1") {
          setInningRound("round_2");
          setCurrentRound({ inning: "Inning1", round: "round_2" });
          setScoreShow(true);
          showScoreModal("firstRound", inningStatus, "PENDING", "round_2");
        } else if (currentRound == "round_2") {
          setInningRound("round_3");
          setCurrentRound({ inning: "Inning1", round: "round_3" });
          setScoreShow(true);
          showScoreModal("secondRound", inningStatus, "PENDING", "round_3");
        } else if (currentRound == "round_3") {
          setInningRound("round_4");
          setCurrentRound({ inning: "Inning1", round: "round_4" });
          setScoreShow(true);
          showScoreModal("thirdRound", inningStatus, "PENDING", "round_4");
        } else if (currentRound == "round_4") {
          setInningRound("round_5");
          setCurrentRound({ inning: "Inning1", round: "round_5" });
          setScoreShow(true);
          showScoreModal("forthRound", inningStatus, "PENDING", "round_5");
        }
      } else if (
        checkRound?.batInfo != null &&
        checkRound?.bowlerInfo != null &&
        checkRound?.roundStatus == "PROGRESS" &&
        checkNextRound?.batInfo == null &&
        checkNextRound?.bowlerInfo == null &&
        roomData?.isBatSelected == 0 &&
        checkRound?.overFulfilled
      ) {
        setCurrentRound({});
        if (currentRound == "round_1") {
          setInningRound("round_1");
          // setCurrentRound({ inning: "Inning1", round: "round_1", again: 1 });
          setScoreShow(true);
          showScoreModal("firstRound", inningStatus, "PROGRESS");
        } else if (currentRound == "round_2") {
          setInningRound("round_2");
          // setCurrentRound({ inning: "Inning1", round: "round_2", again: 1 });
          setScoreShow(true);
          showScoreModal("secondRound", inningStatus, "PROGRESS");
        } else if (currentRound == "round_3") {
          setInningRound("round_3");
          // setCurrentRound({ inning: "Inning1", round: "round_3", again: 1 });
          setScoreShow(true);
          showScoreModal("thirdRound", inningStatus, "PROGRESS");
        } else if (currentRound == "round_4") {
          setInningRound("round_4");
          // setCurrentRound({ inning: "Inning1", round: "round_4", again: 1 });
          setScoreShow(true);
          showScoreModal("forthRound", inningStatus, "PROGRESS");
        }
      }
    }
  };

  const checkPlayerChange = () => {
    //ddddd
    if (!changeBatRef.current) {
      setCheckInningRound("COMPLETED");
      if (batBoosterFirstInning.length > 2 && playerASocketId == socket.id) {
        setEmptyArtifact(true);
      } else {
        setBorderCount(5);
        setBattingMessage("Select a booster below");
        setShowArtifact(true);
        setIsChangeBooster(true);
        setBoosterCount(5);
      }
      // setPlayerDisable(true);
      setPlayerDisable(true);
    } else {
      setBorderCount(timerCount);
      let roundVal = roomData?.currentRound.split("_")[1];
      let checkNextRound = "round_" + (+roundVal + +1);
      setInningRound(checkNextRound);
      setYourPlayer(false);
      setShowArtifact(false);
      setSelectedArtifacts([]);
      setBattingPlayer({});
      setChangeBat(!changeBatRef.current);
      dispatch(startCountDown(timerCount));
      dispatch(setCountDownEnable(true));
      setCount(timerCount);
      // setBowlingMessage("Select Bowler");
      setBattingMessage("Select a batsman below");
      setCheckInningRound("COMPLETED");
      setPlayerDisable(false); ////dddd
    }
  };

  const showScoreModal = (round, inningStatus, roundStatus, chkRound) => {
    if (roundStatus === "PENDING") {
      if (playerASocketId == socket.id) {
        setBattingPlayer({});
        setPlayerDisable(false);
        setBattingMessage("Select a batsman below");
        setTimeout(() => {
          setScoreShow(false);
          setYourPlayer(false);
          setShowArtifact(false);
          setCount(timerCount);
          setBorderCount(10);
        }, 6000);
      } else if (playerBSocketId == socket.id) {
        setPlayerDisable(true);
        setTimeout(() => {
          setBowlingMessage("Wait for opponent selection");
          setScoreShow(false);
          sendNotifyToBattingTeam(
            "",
            { inning: "Inning1", round: chkRound, again: 1 },
            0
          );
        }, 4000);

        setTimeout(() => {
          setBowlingMessage("Wait for opponent selection");
          sendNotifyToBattingTeam(
            "",
            { inning: "Inning1", round: chkRound, again: 1 },
            scoreStatus
          );
        }, 5000);
      }

      // setTimeout(() => {
      //   sendNotifyToBattingTeam("", { inning: "Inning1", round: chkRound }, 1);
      // }, 9000);
    } else if (roundStatus == "PROGRESS" && roomData?.isBatSelected == 0) {
      setTimeout(() => {
        setSelectedArtifacts([]);
        setScoreShow(false);
        if (playerASocketId == socket.id) {
          checkPlayerChange();
        } else if (playerBSocketId == socket.id) {
          setYourPlayer(false);
          setShowArtifact(false);
          setBowlingMessage("Select a bowler below");
          setBowlingPlayer({});
          setPlayerDisable(false);
        }
      }, 5000);
    } else if (roundStatus == "COMPLETED") {
      setYourPlayer(false);
      setShowArtifact(false);
      setSelectedArtifacts([]);
      if (inningStatus == "COMPLETED") {
        setTimeout(() => {
          setCheckRound(inningStatus);
          dispatch(setBowlerRecords([]));
        }, 4000);
      }
      setTimeout(() => {
        setPlayerDisable(false);
        setCheckInningRound("COMPLETED");
        setScoreShow(false);
        if (round == "fivethRound") {
          setBowlingMessage("First inning is complete");
          setBattingMessage("First inning is complete");
        } else {
          setBattingPlayer({});
          setBowlingPlayer({});
          if (playerASocketId == socket.id) {
            setCount(timerCount);
            setBorderCount(timerCount);
          }
          setBowlingMessage("Select a Bowler below");
          setBattingMessage("Select a Batsman below");
        }
      }, 5000);
    }
  };

  //send notification to  player1 (batting team) for bowler is selected
  const sendNotifyToBattingTeam = (bowlerInfo, round, scoreVal) => {
    // setCount(-1);
    let bowlWithArt =
      Object.keys(bowlingPlayer).length > 0
        ? { ...bowlingPlayer, artifacts: selectedArtifacts }
        : bowlerInfo;
    if (scoreVal == 1 && roomData?.overCompleted) {
      dispatch(setBowlerRecords([...bowlerRecords, bowlWithArt?.nftId]));
    }

    let bowlerRound = {
      isScore: scoreVal,
      roomId: playerMatchedData?.roomId,
      socketId: playerBSocketId,
      roundInfo:
        !!round && Object.keys(round).length > 0 ? round : currentRound,
      bowlerInfo: bowlWithArt,
    };

    socket.emit("game_room_update", {
      RoundsInfo: bowlerRound,
    });
  };

  const selectYourPlayer = (
    playerType,
    playerSocketId,
    cardId,
    playerInfo,
    card_Type,
    alreadyPlayed
  ) => {
    if (alreadyPlayed == "alredyPlay") {
      return;
    }
    setPlayerDisable(false);
    setCartType(card_Type);
    if (roundInfo?.Inning1?.status == "PROGRESS") {
      let roundInfoPlayer = { inning: "Inning1", round: inningRound };
      setCurrentRound(roundInfoPlayer);
      if (playerType == "BAT" && playerSocketId == socket.id) {
        setYourPlayer(true);
        setBattingPlayer(playerInfo);
        document.body.className = "noBackDrop";
        setBattingMessage("");
      }
      if (playerType == "BOWL" && playerSocketId != socket.id) {
        if (roomData?.isBatSelected == 1) {
          setBowlingMessage("");
          setBowlingPlayer(playerInfo);
          setYourPlayer(true);
          document.body.className = "noBackDrop";
        } else {
          toast.error("Wait for opponent select the batsman", {
            toastId: "error2",
          });
        }
      }
    }
  };

  //deducted artifact call back
  const artifactCallBack = (data) => {
    if (data?.status == 200) {
      dispatch(getUserArtifacts());
    }
    return null;
  };
  let count = 0;

  const showArtEffectHandler = (id) => {
    if (
      (batBoosterFirstInning.length > 2 && playerASocketId == socket.id) ||
      (bowlBoosterFirstInning.length > 2 && playerBSocketId == socket.id)
    ) {
      toast.error("You can choose a maximum 3 boosters in an inning", {
        toastId: "error2",
      });
    } else {
      // if (id) {
      if (selectedArtifacts.length < 1) {
        setSelectedArtifacts([...selectedArtifacts, id]);
        setBattingMessage("");
        setBowlingMessage("");
      } else {
        toast.error("Choose one booster", {
          toastId: "error1",
        });
      }
      // }
    }
  };

  //change batsman
  const changeBatsman = () => {
    setYourPlayer(false);
    setShowArtifact(false);
    setSelectedArtifacts([]);
    setChangeBat(true);
  };

  //already played ids
  let batPlayerIds = [];
  let bowlerPlayedIds = [];

  for (let i = 1; i <= 5; i++) {
    let round = "round_" + i;
    if (roundInfo?.Inning1?.[round]?.batInfo) {
      let batRound = roundInfo?.Inning1?.[round]?.batInfo;
      batPlayerIds.push({
        playerId: batRound?.nftId,
        checkOutStatus: roundInfo?.Inning1?.[round]?.WicketOut,
      });
    }
    if (roundInfo?.Inning1?.[round]?.bowlerInfo) {
      let bowlRound = roundInfo?.Inning1?.[round]?.bowlerInfo;

      bowlerPlayedIds.push({
        playerId: bowlRound?.nftId,
        checkOutStatus: bowlRound?.WicketOut,
      });
    }
  }

  //random batsman selection
  const randomSelectPlayer = (player) => {
    let cardsList = [...playerData];
    let boosterId = [];
    let roundInfoPlayer = { inning: "Inning1", round: inningRound };
    setYourPlayer(true);
    setCurrentRound(roundInfoPlayer);
    if (player == "batsman") {
      batPlayerIds &&
        batPlayerIds.length > 0 &&
        batPlayerIds.map((e) => {
          const nftIndex = cardsList.findIndex(
            (item) => item?.nftId == e?.playerId
          );
          if (nftIndex !== -1) {
            cardsList.splice(nftIndex, 1);
          }
        });

      const randomIndex = Math.floor(Math.random() * cardsList.length);
      let nftData = cardsList[randomIndex];
      // let nftData = cardsList[0];
      let playerInfo = {
        outlineImage: nftData?.outlineImage,
        da_id: nftData?.da_id,
        nftId: nftData?.nftId,
        name: nftData?.title,
        gameTitle: nftData?.gameTitle,
        img: nftData?.nftLogo,
        artifacts: boosterId,
        isArtifact: 0,
      };

      setBattingPlayer(playerInfo);

      if (
        currentRoundData?.roundStatus == "PROGRESS" &&
        currentRoundData?.bowlerInfo != null &&
        !currentRoundData?.overFulfilled
      ) {
        setTimeout(() => {
          setCount(-1);
          setBorderCount(0);
        }, 3000);
        sendNotifyToBowlingTeam(playerInfo, roundInfoPlayer, 0);
      } else {
        sendNotifyToBowlingTeam(playerInfo, roundInfoPlayer, 0);
      }
      setPlayerDisable(true);
    } else if (player == "bowler") {
      const toFindDuplicates = bowlerRecords.filter(
        (item, index) => bowlerRecords.indexOf(item) !== index
      );
      //remove duplicate value
      toFindDuplicates &&
        toFindDuplicates.length > 0 &&
        toFindDuplicates.map((e) => {
          const cardsListIndex = cardsList.findIndex(
            (item) => item?.nftId == e
          );
          if (cardsListIndex !== -1) {
            cardsList.splice(cardsListIndex, 1);
          }
        });

      const randomIndex = Math.floor(Math.random() * cardsList.length);
      const nftData = cardsList[randomIndex];

      let playerInfo = {
        outlineImage: nftData?.outlineImage,
        da_id: nftData?.da_id,
        nftId: nftData?.nftId,
        name: nftData?.title,
        gameTitle: nftData?.gameTitle,
        img: nftData?.nftLogo,
        artifacts: boosterId,
        isArtifact: 0,
      };
      setYourPlayer(true);
      // setShowArtifact(true);
      setBowlingPlayer(playerInfo);
      setPlayerDisable(true);

      sendNotifyToBattingTeam(
        playerInfo,
        { inning: "Inning1", round: inningRound },
        0
      );

      if (currentRoundData?.batInfo !== null) {
        // setBowlingMessage("");
      } else {
        // setBowlingMessage("Wait for opponent selection");
      }
    }
  };

  const removeArtifact = () => {
    if (playerASocketId == socket.id) {
      setBattingMessage("Select a booster below");
    } else {
      setBowlingMessage("Select a booster below");
    }

    setSelectedArtifacts([]);
  };

  // console.log("batPlayerIds", batPlayerIds, bowlerPlayedIds);
  return (
    <>
      <div className="Firstplayer">
        {!!playerMatchedData &&
          !!playerMatchedData?.playerIds &&
          !!playerMatchedData?.playerIds[opponetSocket] &&
          playerMatchedData?.playerIds[opponetSocket].length > 0 && (
            <Oppolistcard
              playerMatchedData={playerMatchedData?.playerIds[opponetSocket]}
            />
          )}
        {/* <OpponentBooster /> */}
        <div className="grounPlay">
          <SelectedOpponentPlayer
            playersSocketId={playerASocketId}
            roundInfo={
              playerBSocketId == socket.id && roomData?.isBatSelected == 1
                ? currentRoundData
                : playerASocketId == socket.id
                ? !!currentRoundData
                  ? currentRoundData
                  : {}
                : playerBSocketId == socket.id &&
                  roomData?.isBatSelected == 0 &&
                  roomData?.isChanged == 1 &&
                  currentRoundData?.batInfo != null &&
                  currentRoundData?.bowlerInfo != null
                ? currentRoundData
                : {}
            }
            roomData={roomData}
            socket={socket}
            artifactList={artifactList}
            selectedArtifacts={selectedArtifacts}
            checkInningRound={checkInningRound}
            inning={"first"}
          />

          <div>
            <div className="plaer">
              <div className="ground">
                {borderCount > 0 && <BorderLine borderCount={borderCount} />}
                <img src={addground} alt="addground" />
              </div>
              <div className="main_Contint">
                {((battingPlayer &&
                  Object.keys(battingPlayer).length > 0 &&
                  yourPlayer &&
                  !showArtifact &&
                  battingMessage == "") ||
                  (bowlingPlayer &&
                    Object.keys(bowlingPlayer).length > 0 &&
                    yourPlayer &&
                    !showArtifact &&
                    bowlingMessage == "")) && (
                  <SelectedYourPlayer
                    roomData={roomData}
                    opponent={false}
                    playersSocketId={playerASocketId}
                    socket={socket}
                    bowlingPlayer={bowlingPlayer}
                    battingPlayer={battingPlayer}
                    yourPlayer={yourPlayer}
                    artifactList={artifactList}
                    selectedArtifacts={selectedArtifacts}
                    checkInningRound={checkInningRound}
                    inning="first"
                  />
                )}
                {showArtifact &&
                  (battingMessage == "" || bowlingMessage == "") &&
                  selectedArtifacts &&
                  selectedArtifacts.length > 0 && (
                    <SelectedBooster
                      removeArtifact={removeArtifact}
                      selectedArtifacts={selectedArtifacts}
                      artifactList={artifactList}
                    />
                  )}
                {/* {playerASocketId == socket.id && roomData?.isBatSelected == 1 ? <p>{battingMessage}</p> : <p>{bowlingMessage}</p>} */}
                {battingMessage != "" && playerASocketId == socket.id && (
                  <p>{battingMessage}</p>
                )}
                {bowlingMessage !== "" && playerBSocketId == socket.id && (
                  <p>{bowlingMessage}</p>
                )}
              </div>
            </div>
          </div>
        </div>
        {/* <Yourlistcard /> */}
        {/* {console.log("inning-", playerMatchedData)} */}

        {!showArtifact && playerData.length > 0 && (
          <Yourlistcard
            playerDisable={playerDisable}
            batPlayerIds={batPlayerIds}
            bowlerPlayedIds={bowlerPlayedIds}
            playerMatchedData={playerData}
            roomData={roomData}
            roundInfo={roundInfo?.Inning1}
            playerASocketId={playerASocketId}
            playerBSocketId={playerBSocketId}
            socket={socket}
            selectYourPlayer={selectYourPlayer}
            inning="first"
            bowlerRecords={bowlerRecords}
          />
        )}
        {showArtifact && (
          <YourBooster
            // playerDisable={playerDisable}
            selectedArtifacts={selectedArtifacts}
            artifactList={artifactList}
            playerASocketId={playerASocketId}
            playerBSocketId={playerBSocketId}
            inning="first"
            socket={socket}
            disable={true}
            showArtEffectHandler={showArtEffectHandler}
            // boosterFirstInning={boosterFirstInning}
          />
        )}
      </div>
      {scoreShow && currentRoundData?.batInfo && (
        <ScoreBoredModal
          changeBat={changeBat}
          // continueBtn={continueBtn}
          changeBatsman={changeBatsman}
          // continueGame={continueGame}
          playersSocketId={playerASocketId}
          currentRound={roomData?.currentRound}
          inning="First"
          roomData={roomData}
          roundInfo={currentRoundData}
        />
      )}
      {!!playerMatchedData &&
        roundInfo?.Inning1?.round_1 == null &&
        timerclose && <WaitingModal message={"First Inning"} subMessage={""} />}

      {roundInfo?.Inning1?.round_1 == null && showStartGame && (
        <WaitingModal
          message={"Game about to start"}
          subMessage={
            playerASocketId == socket.id ? "Select Batsman" : "Select Bowler"
          }
        />
      )}
    </>
  );
}

export default PlayerInningFirst;
