import React from "react";
import Kane2 from "../../../assets/images/Kane2.png";
import hardik from "../../../assets/images/hardik.png";

import googly_ball from "../../../assets/images/booster/googly_ball.png";
import "./playing.scss";

const SelectedOpponentplayer = ({
  roomData,
  playersSocketId,
  socket,
  roundInfo,
  checkInningRound,
  artifactList,
  inning,
}) => {
  let playedBalls =
    inning == "first"
      ? roomData?.totalBallsPlayedByPlayerA
      : roomData?.totalBallsPlayedByPlayerB;
  if (playedBalls > 60) {
    playedBalls = 60;
  }

  let currentRound = roomData.currentRound;
  var findPlayerSCore;
  if (roomData?.RoundsInfo?.Inning1?.status == "COMPLETED") {
    findPlayerSCore =
      checkInningRound == "PENDING"
        ? roomData?.RoundsInfo?.Inning2[currentRound]?.score
        : 0;
  } else {
    findPlayerSCore =
      checkInningRound == "PENDING"
        ? roomData?.RoundsInfo?.Inning1[currentRound]?.score
        : 0;
  }

  let overs = parseInt(playedBalls / 6) + "." + (playedBalls % 6);

  return (
    <>
      <div className="oppoPlay">
        {playersSocketId == socket.id && checkInningRound == "PENDING"
          ? roundInfo?.bowlerInfo?.artifacts &&
            roundInfo?.bowlerInfo?.artifacts.length > 0 &&
            roundInfo?.bowlerInfo?.artifacts.map((id, index) => {
              let findBooster =
                artifactList &&
                artifactList.length > 0 &&
                artifactList.find((item) => item.ds_id == id);
              return (
                <div className="boostersel">
                  <img src={findBooster?.image} alt="googly_ball" />
                </div>
              );
            })
          : checkInningRound == "PENDING" &&
            roundInfo?.batInfo?.artifacts &&
            roundInfo?.batInfo?.artifacts.length > 0 &&
            roundInfo?.batInfo?.artifacts.map((id, index) => {
              let findBooster =
                artifactList &&
                artifactList.length > 0 &&
                artifactList.find((item) => item.ds_id == id);
              return (
                <div className="boostersel">
                  <img src={findBooster?.image} alt="googly_ball" />
                </div>
              );
            })}

        {playersSocketId == socket.id && checkInningRound == "PENDING" ? (
          !!roomData?.currentRound ? (
            <>
              <div className="playerImg">
                <img
                  src={
                    roundInfo?.bowlerInfo?.outlineImage
                      ? roundInfo?.bowlerInfo?.outlineImage
                      : hardik
                  }
                  alt="Kane2"
                />
              </div>
              <div className="texting">
                <p>
                  {roundInfo?.bowlerInfo?.gameTitle
                    ? roundInfo?.bowlerInfo?.gameTitle
                    : ""}
                  <br />
                  {
                    inning == "second" &&
                      `Target ${roomData?.totalScoreByPlayerA} runs in 10 overs`
                    // `${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA} in 10 overs`
                  }
                </p>
              </div>
            </>
          ) : (
            <>
              <div className="playerImg">
                <img src={hardik} alt="Kane2" />
              </div>
              <div className="texting"></div>
            </>
          )
        ) : !!roomData?.currentRound && checkInningRound == "PENDING" ? (
          <>
            <div className="playerImg">
              <img
                src={
                  roundInfo?.batInfo?.outlineImage
                    ? roundInfo?.batInfo?.outlineImage
                    : hardik
                }
                alt={roundInfo?.batInfo?.gameTitle}
              />
            </div>
            <div className="texting">
              <p>
                {roundInfo?.batInfo?.gameTitle
                  ? roundInfo?.batInfo?.gameTitle
                  : ""}

                {roundInfo?.batInfo?.gameTitle && inning == "second"
                  ? ` (${
                      roomData?.currentRound && findPlayerSCore > 0
                        ? findPlayerSCore
                        : 0
                    })*`
                  : ""}
                <br />
                {
                  inning == "second" &&
                    `Target ${roomData?.totalScoreByPlayerA} runs in 10 overs`

                  /* `${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA} in 10 overs` */
                }
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="playerImg">
              <img src={hardik} alt="Kane2" />
            </div>
            <div className="texting"></div>
          </>
        )}
      </div>
    </>
  );
};

export default SelectedOpponentplayer;
