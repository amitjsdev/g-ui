import React from "react";
import "./playing.scss";
import rohit from "../../../assets/images/rohit.png";
import Slider from "react-slick";

const SelectYourPlayer = ({
  playersSocketId,
  battingPlayer,
  opponent,
  bowlingPlayer,
  socket,
  roomData,
}) => {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  let playedBalls = roomData?.totalBallsPlayedByPlayerA;
  if (playedBalls > 60) {
    playedBalls = 60;
  }
  let currentRound = roomData.currentRound;
  var findPlayerSCore;
  if (roomData?.RoundsInfo?.Inning1?.status == "COMPLETED") {
    findPlayerSCore = roomData?.RoundsInfo?.Inning2[currentRound]?.score
  } else {
    findPlayerSCore = roomData?.RoundsInfo?.Inning1[currentRound]?.score
  }

  // console.log("---------------------round score-----", battingPlayer,bowlingPlayer, playersSocketId, socket.id, findPlayerSCore, battingPlayer?.gameTitle, bowlingPlayer?.gameTitle)
  let overs = parseInt(playedBalls / 6) + "." + (playedBalls % 6);
  return (
    <div>
      {opponent ? (
        <Slider {...settings}>
          <div className="selectplayer">
            <div className="playerImg">
              <img src={battingPlayer?.outlineImage} alt="rohit" />
            </div>
            <div className="texting">
              <p>
                Rohit Sharma (54*)
                <br />
                108/2 in 6.1 overs
              </p>
            </div>
          </div>
        </Slider>
      ) : (
        <Slider {...settings}>

          {playersSocketId == socket.id && battingPlayer? (
            <div className="selectplayer">
              <div className="playerImg">
                <img src={battingPlayer?.outlineImage || bowlingPlayer?.outlineImage} alt="Batsman" />
              </div>
              <div className="texting">
                <p>
                  {battingPlayer?.gameTitle
                      ? battingPlayer?.gameTitle
                      : "You "}

                  {` (${roomData?.currentRound && findPlayerSCore})*`}
                  {/* <span>*</span> */}
                  <br />
                  {`${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA
                    } in ${!!overs ? overs : 0} overs`}
                </p>
              </div>
            </div>
          ) : (
            <div className="selectplayer">
              <div className="playerImg">
                <img src={battingPlayer?.outlineImage || bowlingPlayer?.outlineImage} alt="Bowler" />
              </div>
              <div className="texting">
                <p>
                  {bowlingPlayer?.gameTitle
                      ? bowlingPlayer?.gameTitle
                      : "You "}

                  {` ${findPlayerSCore}/1 in ${!!overs ? overs : 0} Overs`}
                  {/* <span>*</span> */}
                  <br />
                  {`${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA
                    } in ${!!overs ? overs : 0} overs`}
                </p>
              </div>
            </div>
          )}
        </Slider>
      )}
    </div>
  );
};

export default SelectYourPlayer;


// <div className="playerImg">
// <img src={battingPlayer?.outlineImage || bowlingPlayer?.outlineImage} alt="rohit" />
// </div>
// <div className="texting">
// <p>
//   {playersSocketId == socket.id
//     ? battingPlayer?.gameTitle
//       ? battingPlayer?.gameTitle
//       : "You "
//     : bowlingPlayer?.gameTitle
//       ? bowlingPlayer?.gameTitle
//       : "You "}

//   {` (${roomData?.currentRound && findPlayerSCore})*`}
//   {/* <span>*</span> */}
//   <br />
//   {`${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA
//     } in ${!!overs ? overs : 0} overs`}
// </p>
// </div>