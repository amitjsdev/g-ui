import React from "react";
import "./playing.scss";
import rohit from "../../../assets/images/rohit.png";
import PowerPlay from "../../../assets/images/booster/PowerPlay.png";

import Slider from "react-slick";

const SelectedYourPlayer = ({
  playersSocketId,
  battingPlayer,
  opponent,
  bowlingPlayer,
  socket,
  roomData,
  selectedArtifacts,
  artifactList,
  checkInningRound,
  inning,
}) => {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  let playedBalls =
    inning == "first"
      ? roomData?.totalBallsPlayedByPlayerA
      : roomData?.totalBallsPlayedByPlayerB;
  if (playedBalls > 60) {
    playedBalls = 60;
  }

  let overs = parseInt(playedBalls / 6) + "." + (playedBalls % 6);

  let currentRound = roomData.currentRound;
  var findPlayerSCore;
  if (roomData?.RoundsInfo?.Inning1?.status == "COMPLETED") {
    findPlayerSCore =
      checkInningRound == "PENDING"
        ? roomData?.RoundsInfo?.Inning2[currentRound]?.score
        : 0;
  } else {
    findPlayerSCore =
      checkInningRound == "PENDING"
        ? roomData?.RoundsInfo?.Inning1[currentRound]?.score
        : 0;
  }

  return (
    <div>
      <Slider {...settings}>
        {playersSocketId == socket.id &&
        battingPlayer &&
        Object.keys(battingPlayer).length > 0 ? (
          <div className="selectplayer">
            {selectedArtifacts &&
              selectedArtifacts.length > 0 &&
              selectedArtifacts.map((id, index) => {
                let findBooster =
                  artifactList &&
                  artifactList.length > 0 &&
                  artifactList.find((item) => item.ds_id == id);
                return (
                  <div className="boostersel">
                    <img src={findBooster?.image} alt="PowerPlay" />
                  </div>
                );
              })}
            <div className="playerImg">
              <img
                src={battingPlayer?.outlineImage || bowlingPlayer?.outlineImage}
                alt="Batsman"
              />
            </div>
            <div className="texting">
              <p>
                {battingPlayer?.gameTitle ? battingPlayer?.gameTitle : "You "}
                {` (${
                  roomData?.currentRound && findPlayerSCore > 0
                    ? findPlayerSCore
                    : 0
                })*`}
                <br />
                {inning == "first"
                  ? `${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA}`
                  : `${roomData?.totalScoreByPlayerB}/${roomData?.totalWicketsPlayerB}`}{" "}
                {`in ${!!overs ? overs : 0} overs`}
              </p>
            </div>
          </div>
        ) : (
          bowlingPlayer &&
          Object.keys(bowlingPlayer).length > 0 && (
            <div className="selectplayer">
              {selectedArtifacts &&
                selectedArtifacts.length > 0 &&
                selectedArtifacts.map((id, index) => {
                  let findBooster =
                    artifactList &&
                    artifactList.length > 0 &&
                    artifactList.find((item) => item.ds_id == id);
                  return (
                    <div className="boostersel">
                      <img src={findBooster?.image} alt="PowerPlay" />
                    </div>
                  );
                })}
              <div className="playerImg">
                <img
                  src={
                    battingPlayer?.outlineImage || bowlingPlayer?.outlineImage
                  }
                  alt="Bowler"
                />
              </div>
              <div className="texting">
                <p>
                  {bowlingPlayer?.gameTitle ? bowlingPlayer?.gameTitle : "You "}
                  {/* {` ${findPlayerSCore}/1 in ${!!overs ? overs : 0} Overs`}
                  <br />
                  {`${roomData?.totalScoreByPlayerA}/${
                    roomData?.totalWicketsPlayerA

                  } in ${!!overs ? overs : 0} overs`} */}
                  <br />
                  {inning == "first"
                    ? `${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA}`
                    : `${roomData?.totalScoreByPlayerB}/${roomData?.totalWicketsPlayerB}`}{" "}
                  {`in ${!!overs ? overs : 0} overs`}
                </p>
              </div>
            </div>
          )
        )}
      </Slider>
    </div>
  );
};

export default SelectedYourPlayer;
