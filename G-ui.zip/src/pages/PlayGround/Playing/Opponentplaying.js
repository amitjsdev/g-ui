import React from 'react';
import "./playing.scss";

const Opponentplaying = () => {
    return (
        <>
            <div>
                <div className='OppoPlays'>
                    <p>Select a Bowler<br /> Below</p>
                </div>
            </div>
        </>
    )
}

export default Opponentplaying