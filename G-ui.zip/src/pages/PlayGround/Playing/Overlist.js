import React, { useState, useEffect, memo } from "react";
//Showing ball-by-ball data
const Overlist = memo(
  ({ overList, round }) => {
    const [currentBalls, setCurrentBalls] = useState([]);
    const [intervalInitialized, setIntervalInitialized] = useState(false);

    const [preFilledBalls, setPreFilledBalls] = useState([]);
    const [count, setCount] = useState(null);

    useEffect(() => {
      if (overList && overList?.[round]?.everyBall?.length) {
        let currentBalls = overList?.[round]?.everyBall?.reduce(
          (com, item) => [...com, ...item.ballData],
          []
        );
        setCurrentBalls(currentBalls);
        let prefilledBalls = [];
        let r = Number(round.split("_")[1]);
        for (let i = 1; i <= r; i++) {
          if (overList?.[`round_${i}`]?.previousBalls?.length) {
            prefilledBalls = overList?.[`round_${i}`]?.previousBalls?.reduce(
              (com, item) => {
                return [...com, ...item.ballData];
              },
              prefilledBalls
            );
          }
          if (overList?.[`round_${i}`]?.everyBall?.length && i !== r) {
            prefilledBalls = overList?.[`round_${i}`]?.everyBall?.reduce(
              (com, item, index) => {
                return [...com, ...item.ballData];
              },
              prefilledBalls
            );
          }
        }
        let pFB = prefilledBalls?.length % 12;
        if (pFB) {
          setPreFilledBalls(
            prefilledBalls.slice(
              prefilledBalls.length - pFB,
              prefilledBalls.length
            )
          );
          setCount(pFB);
        } else {
          setPreFilledBalls([]);
          setCount(0);
        }
      }
    }, [overList]);

    let interval = null;
    useEffect(() => {
      if (count !== null && !intervalInitialized) {
        setIntervalInitialized(true);
        let counter = count;
        interval = setInterval(() => {
          if (counter >= preFilledBalls.length + currentBalls.length) {
            clearInterval(interval);
            setCount(null);
            setIntervalInitialized(false);
            interval = null;
          } else {
            setCount((count) => count + 1);
            counter++; // local variable that this closure will see
          }
        }, 900);
      }
    }, [count]);

    let mapsBallData =
      count !== null ? (
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((ball, i) => {
          let text =
            i < count
              ? i < preFilledBalls?.length
                ? preFilledBalls[i] === -999
                  ? "W"
                  : preFilledBalls[i]
                : currentBalls[i - preFilledBalls?.length] === -999
                ? "W"
                : currentBalls[i - preFilledBalls?.length]
              : ".";
          return (
            <li>
              <div
                className={`scoreBord ${
                  i < count && (text || text === 0) ? "numbers" : "not_num"
                }`}
              >
                <p>{text || text === 0 ? `${text}` : "."}</p>
              </div>
            </li>
          );
        })
      ) : (
        <></>
      );
    return (
      <>
        <div className="overlist">{mapsBallData}</div>
      </>
    );
  },
  (pp, np) => {
    return (
      pp.round === np.round &&
      JSON.stringify(pp.overList) === JSON.stringify(np.overList)
    );
  }
);

export default Overlist;
