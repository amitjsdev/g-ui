import React from "react";
import "./playing.scss";
import rohit from "../../../assets/images/rohit.png";
import PowerPlay from "../../../assets/images/booster/PowerPlay.png";

const Selected = () => {
  return (
    <>
      <div className="selplayer">
        <div className="boostersel">
          <img src={PowerPlay} alt="PowerPlay" />
        </div>
        <div className="playerImg">
          <img src={rohit} alt="rohit" />
        </div>
        <div className="texting">
          <p>
            Rohit Sharma (54*)
            <br />
            108/2 in 6.1 overs
          </p>
        </div>
      </div>
    </>
  );
};

export default Selected;
