import React from "react";
import "./playing.scss";
import Slider from "react-slick";

const SelectBooster = () => {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  return (
    <>
      <Slider {...settings}>
        <div className="selectplayer">
          <div className="texting">
            <p>
              Select a Booster
              <br /> Below
            </p>
          </div>
        </div>
      </Slider>
    </>
  );
};

export default SelectBooster;
