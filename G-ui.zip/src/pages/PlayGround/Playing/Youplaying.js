import React from "react";
import "./playing.scss";
import Lottie from "react-lottie";
import * as animationFrame from "../../../assets/images/grounsplay.json";
import addground from "../../../assets/images/addground.png";

const Youplaying = ({
  playersSocketId,
  socket,
  yourPlayer,
  bowlingPlayer,
  battingPlayer,
  selectedArtifacts,
  artifactList,
  inning,
}) => {
  const frameAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationFrame,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  return (
    <>
      <div>
        <div className="plaer">
          <div className='ground'>
            {/* <div className="adflip">
              <Lottie options={frameAnimation} />
            </div> */}
            <div className='bordgrd'>
              <svg xmlns="http://www.w3.org/2000/svg" width="292" height="239" viewBox="0 0 292 239">
                <g id="Rectangle_12196" data-name="Rectangle 12196" fill="none" stroke="#2bff2f" stroke-width="5">
                  <rect id="path" width="292" height="239" rx="20" stroke="none" />
                  <rect id="num" x="1" y="1" width="290" height="237" rx="20" fill="none"
                    style={{
                      strokeDasharray: "1020",
                      strokeDashoffset: "1020",
                      animation: "dash 10s linear infinite"
                    }}
                  />
                </g>
              </svg>
            </div>
            <img src={addground} alt="addground" />
          </div>
          <div className='main_Contint'>
            <p>
              Select a Batsman
              <br /> Below
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Youplaying;
