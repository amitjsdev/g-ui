import React from "react";
import "./Teamlist.scss";
import Oppolistcard from "./Oppolistcard";
import Yourlistcard from "./Yourlistcard";
import Youplaying from "../Playing/Youplaying";
// import Selectplayer from "../Playing/Selectplayer";
import Yourbooster from "../Playing/SelectBooster";
import Bowlerbooster from "../Booster/OpponentBooster";
import Batsmanbooster from "../Booster/YourBooster";
import Selectedboost from "../Booster/SelectedBooster";
import Opponentplayer from "../Playing/SelectedOpponentplayer";
import Opponentplaying from "../Playing/Opponentplaying";

const GroundCards = () => {
  return (
    <>
      <div className="Firstplayer">
        <Oppolistcard />
        {/* <Bowlerbooster /> */}
        <div className="grounPlay">
          <Opponentplaying />
          {/* <Opponentplayer /> */}
          {/* <Selectplayer /> */}
          <Youplaying />
          {/* <Yourbooster /> */}
          {/* <Selectedboost /> */}
        </div>
        <Yourlistcard />
        {/* <Batsmanbooster /> */}
      </div>
    </>
  );
};

export default GroundCards;
