import React from "react";
import KL_Rahul from "../../../assets/images/KL_Rahul.png";
import "./Teamlist.scss";

const Yourlistcard = ({
  playerMatchedData,
  roomData,
  roundInfo,
  playerASocketId,
  playerBSocketId,
  socket,
  selectYourPlayer,
  inning,
  batPlayerIds,
  bowlerPlayedIds,
  bowlerRecords,
  playerDisable,
}) => {
  return (
    <>
      <div className="listingOppo">
        {
          // first inning start
          inning == "first"
            ? playerMatchedData?.map((item, index) => {
                let currentRound = roomData?.currentRound;
                let infoInRound = roundInfo?.[currentRound];
                const toFindDuplicates = bowlerRecords.filter(
                  (val, index) => bowlerRecords.indexOf(val) !== index
                );
                let card_type = playerASocketId == socket.id ? "BAT" : "BOWL";

                let playerInfo = {
                  outlineImage: item?.outlineImage,
                  da_id: item?.da_id,
                  nftId: item?.nftId,
                  name: item?.title,
                  gameTitle: item?.gameTitle,
                  img: item?.nftLogo,
                  artifacts: [],
                  isArtifact: 0,
                };
                let alreadyPlayed;
                if (infoInRound && playerASocketId == socket.id) {
                  alreadyPlayed =
                    batPlayerIds &&
                    batPlayerIds.length > 0 &&
                    batPlayerIds.find((val) => val?.playerId == item?.nftId)
                      ? batPlayerIds.find(
                          (val) =>
                            val?.checkOutStatus == 1 &&
                            val?.playerId == item?.nftId
                        )
                        ? "out alredyPlay"
                        : "alredyPlay"
                      : playerDisable
                      ? "alredyPlay"
                      : "";
                }

                if (infoInRound && playerBSocketId == socket.id) {
                  alreadyPlayed =
                    roomData?.previousBowler == item?.nftId
                      ? "alredyPlay"
                      : toFindDuplicates.includes(item?.nftId)
                      ? "alredyPlay"
                      : playerDisable
                      ? "alredyPlay"
                      : "";
                }
                return (
                  <li
                    className={alreadyPlayed}
                    key={index}
                    onClick={() => {
                      selectYourPlayer(
                        card_type,
                        playerASocketId,
                        item?.nftId,
                        playerInfo,
                        item?.card_type,
                        alreadyPlayed
                      );
                    }}
                  >
                    <div className="playerList">
                      <div className={`playerCard ${alreadyPlayed}`}>
                        <img className="cards" src={item?.nftLogo} />
                      </div>
                      <p>{item?.gameTitle}</p>
                    </div>
                  </li>
                );
                // }
              })
            : // second inning start
              playerMatchedData?.map((item, index) => {
                let currentRound = roomData?.currentRound;
                let infoInRound = roundInfo?.[currentRound];

                const toFindDuplicates = bowlerRecords.filter(
                  (val, index) => bowlerRecords.indexOf(val) !== index
                );
                let card_type = playerBSocketId == socket.id ? "BAT" : "BOWL";

                let batInfo = {
                  outlineImage: item?.outlineImage,
                  da_id: item?.da_id,
                  nftId: item?.nftId,
                  name: item?.title,
                  gameTitle: item?.gameTitle,
                  img: item?.nftLogo,
                  artifacts: [],
                  isArtifact: 0,
                };

                let alreadyPlayed;
                //check for batsman
                if (infoInRound && playerBSocketId == socket.id) {
                  alreadyPlayed =
                    batPlayerIds &&
                    batPlayerIds.length > 0 &&
                    batPlayerIds.find((val) => val?.playerId == item?.nftId)
                      ? batPlayerIds.find((val) => val?.checkOutStatus == 1)
                        ? "out alredyPlay"
                        : "alredyPlay"
                      : playerDisable
                      ? "alredyPlay"
                      : "";
                }
                //check for bowler
                if (infoInRound && playerASocketId == socket.id) {
                  alreadyPlayed =
                    roomData?.previousBowler == item?.nftId
                      ? "alredyPlay"
                      : toFindDuplicates.includes(item?.nftId)
                      ? "alredyPlay"
                      : playerDisable
                      ? "alredyPlay"
                      : playerDisable
                      ? "alredyPlay"
                      : "";
                }

                return (
                  <li
                    className={`playerCard ${alreadyPlayed}`}
                    key={index}
                    onClick={() => {
                      selectYourPlayer(
                        card_type,
                        playerBSocketId,
                        item?.nftId,
                        batInfo,
                        item?.card_type
                      );
                    }}
                  >
                    <div className="playerList active">
                      <div className={`playerCard ${alreadyPlayed}`}>
                        <img className="cards" src={item?.nftLogo} />
                      </div>
                      <p>{item?.gameTitle}</p>
                    </div>
                  </li>
                );
                // }
              })
        }
      </div>
    </>
  );
};

export default Yourlistcard;
