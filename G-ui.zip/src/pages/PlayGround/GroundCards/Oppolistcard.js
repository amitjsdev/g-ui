import React from "react";
import Kane from "../../../assets/images/Kane_Williamso.png";
import "./Teamlist.scss";

const Oppolistcard = ({ playerMatchedData }) => {
  return (
    <>
      <div className="listingOppo">
        {playerMatchedData.map((item, index) => (
          <li key={index}>
            <div className="playerList active">
              <div className="playerCard">
                <img className="cards" src={item?.nftLogo} />
              </div>
              <p>{item?.gameTitle}</p>
            </div>
          </li>
        ))}
      </div>
    </>
  );
};

export default Oppolistcard;
