import React from "react";
import "./Teamlist.scss";
import SelectedOpponentplayer from "../Playing/SelectedOpponentplayer";
import Selected from "../Playing/Selected";
import Overlist from "../Playing/Overlist";

const Screenplayer = () => {
  return (
    <>
      <div className="Screenplayer">
        <div className="grounPlay">
          <SelectedOpponentplayer />
          <Selected />
        </div>
      </div>
    </>
  );
};

export default Screenplayer;
