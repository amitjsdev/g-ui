import React, { useState, useEffect } from "react";
import Slider from "react-slick";
import InfiniteScroll from "react-infinite-scroller";

const RentedCards = React.memo(
  ({ fetchRentData, addSelectedPlayer, setModalImg, handleShow, rented }) => {
    return (
      <div className="imagepick">
        {/* <p>Rented Cards</p> */}
        <div
          id="scrollableDivRent"
          style={{
            display: "flex",
            height: 500,
            overflow: "auto",
          }}
        >
          <InfiniteScroll
            // dataLength={rented.length}
            pageStart={0}
            // useWindow={false}
            loadMore={fetchRentData}
            // style={{ display: "flex", flexDirection: "column-reverse" }} //To put endMessage and loader to the top.
            // inverse={true}
            hasMore={true}
            // loader={rented.length < rentCount ? <h4>Loading...</h4> : ""}
            // scrollableTarget="scrollabletarget"
            className="screens_Cards"
            useWindow={true}
          >
            {rented &&
              rented.length > 0 &&
              rented?.map((player, index) => (
                <div className="first" key={index}>
                  <div onClick={() => addSelectedPlayer(player)}>
                    <img src={player?.nftLogo} alt="KL_Rahul" />
                    <button
                      className="ViewButton"
                      onClick={() => {
                        setModalImg(player?.nftLogo);
                        handleShow();
                      }}
                    >
                      View
                    </button>
                  </div>
                  {/* <p className="playerName">{player?.gameTitle}</p> */}
                </div>
              ))}
          </InfiniteScroll>
        </div>
      </div>
    );
  },
  (prevProps, nextProps) => {
    const A = JSON.stringify(prevProps);
    const B = JSON.stringify(nextProps);
    return (
      A === B
      // prevProps?.roundResult?.length === nextProps?.roundResult?.length &&
      // prevProps.selectedCard === nextProps.selectedCard
    );
  }
);

export default RentedCards;
