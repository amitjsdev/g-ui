import React, { useEffect, useState } from "react";
import search from "../../assets/images/search.svg";
import Slider from "react-slick";
import "./BuildTeam.scss";
import {
  Button,
  Container,
  Dropdown,
  Form,
  FormControl,
  Modal,
} from "react-bootstrap";
import icon_plus from "../../assets/images/icon_plus.png";
import drop from "../../assets/images/drop.svg";
import * as animationData from "../../assets/images/Planet.json";
import cross from "../../assets/images/cross_icon.svg";
import crossWit from "../../assets/images/crose.svg";
import eyeIcon from "../../assets/images/eyeIcon.png";
import { Link, useNavigate } from "react-router-dom";
import {
  finalSubmit,
  getCountry,
  getStadiumList,
  matchedData,
  enableDoneBtn,
  getSearchedNfts,
  savePlayer,
  startCountDown,
  setCountDownEnable,
  getLastFivePlayer,
} from "../../redux/user/action";

import { useDispatch, useSelector } from "react-redux";
import CardModal from "../../modals/CardModal";
// import CardModal from "../../modals/CardModal";
import { toast } from "react-toastify";
import socket from "../../socket";
import PlayerVsModal from "../PlayerVsModal/PlayerVsModal";
import InfiniteScroll from "react-infinite-scroll-component";
import WaitingModal from "../../modals/WaitingModal";
import Modalcard from "../CardInfo/Modal/Modalcard";

function BuildTeam() {
  const splitLocation = window.location.pathname.split("/");
  const [bottomHeight, setBottomHeight] = useState(true);

  const BottomBarHandler = () => {
    setBottomHeight(!bottomHeight);
  };
  let timerCount = 125;
  let navigate = useNavigate();
  const [bar, setBar] = useState(true);
  const dispatch = useDispatch();
  const [opponent, setOpponent] = useState(false);
  const [show, setShow] = useState(false);
  const [getData, setGetData] = useState(true);
  const [enableSearch, setEnableSearch] = useState(false);
  const [modalImg, setModalImg] = useState();
  const [seletedPlayer, setSeletedPlayer] = useState([]);
  const [rarity, setRarity] = useState();
  const [searchvalue, setSearchvalue] = useState();
  const [type, setType] = useState("");
  const [ownerShip, setOwnerShip] = useState();
  const [countryList, setCountryList] = useState([]);
  const [selectedCountries, setSelectedCountries] = useState({});
  const [owned, setOwned] = useState([]);
  const [ownerShipPage, setOwnerShipPage] = useState(0);
  

  const [rented, setRented] = useState([]);

  const stadium = useSelector(
    (state) => state?.userReducer?.currentStadiumRarity
  );

  const playerMatchedData = useSelector(
    (state) => state?.userReducer?.matchedData?.data
  );

  const [ownedData, setOwnedData] = useState([]);
  const [rentedData, setRentedData] = useState([]);
  const [showVsModal, setShowVsModal] = useState(true);
  const [offset, setOffset] = useState(1);
  const [limit, setLimit] = useState(12);

  const [ownedCount, setOwnedCount] = useState(0);
  const [rentCount, setRentCount] = useState(0);
  const [showConifrm, setShowConifrm] = useState(false);
  const [waitModal, setWaitModal] = useState(false);
  const [intervalIntialized, setIntervalIntialized] = useState(false);
  const [searchInput, setSearchInput] = useState("");
  const [playerStats, setPlayerStats] = useState({});

  
  // if (!stadium) {
  //   navigate("/");
  // }

  const handleClose = () => setShow(false);
 
  const timerclose = () => {
    setOpponent(false);
  };
  const timershow = () => setOpponent(true);

  const [currentCount, setCount] = useState(timerCount);

  let timeToLapse = timerCount;
  let bTInterval = null;
  useEffect(() => {
    if (currentCount <= 0) {
      socket.removeListener("room_destroyed");
      if (seletedPlayer.length != 5) {
        //will show popop for try again times up
        toast.error("Select five players to build your team");
        navigate("/");
        socket.disconnect();
      }

      if (seletedPlayer.length == 5 && !waitModal) {
        toast.error("Hm, you did not make your move");
        socket.disconnect();
        navigate("/");
      }
      if (seletedPlayer.length == 5 && waitModal) {
        toast.error("Opponent did not make his move");
        socket.disconnect();
        navigate("/");
      }

      return;
    } else {
      if (currentCount < 10) {
        dispatch(startCountDown(0 + "" + currentCount));
      } else {
        dispatch(startCountDown(currentCount));
      }
    }
  }, [currentCount]);

  useEffect(() => {
    bTInterval = setInterval(() => {
      timeToLapse -= 1;
      if (timeToLapse === 0) {
        if (bTInterval) {
          clearInterval(bTInterval);
        }
      }
      setCount(timeToLapse);
    }, 1000);
  }, []);

  const timeAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  const callback = (data) => {
    if (data) {
      if (data?.data?.owned?.nfts) {
        let buyMe = data?.data?.owned?.nfts;
        setOwnedCount(data?.data?.owned?.count);
        setOwned(buyMe);
        setOwnedData(buyMe);
      }

      if (data?.data?.rented?.nfts) {
        let rentData = data?.data?.rented?.nfts;
        setRentCount(data?.data?.rented?.count);
        setRented(rentData);
        setRentedData(rentData);
      }

      if (ownerShipPage == 1) {
        let buyMe = data?.data?.nfts;
        setOwnedCount(data?.data?.count);
        setOwned(owned.concat(buyMe));
        setOwnedData(owned.concat(buyMe));
      }

      if (ownerShipPage == 2) {
        let rentData = data?.data?.nfts;
        setRentCount(data?.data?.count);
        setRented(rented.concat(rentData));
        setRentedData(rented.concat(rentData));
      }

      if (ownerShip == 1) {
        let buyMe = data?.data?.nfts;
        setOwnedCount(data?.data?.count);
        setOwned(buyMe);
        setOwnedData(buyMe);
        setRented([]);
      }

      if (ownerShip == 2) {
        let rentData = data?.data?.nfts;
        setRentCount(data?.data?.count);
        setRented(rentData);
        setRentedData(rentData);
        setOwned([]);
        setOwnedData([]);
      }
    }
    return null;
  };
  const callSearch = (data) => {
    if (data) {
      if (data?.data?.rented?.nfts) {
        let searchedData = data?.data?.rented?.nfts;
        setRented(searchedData);
        setRentCount(data?.data?.rented?.count);
      }
    }
  };

  const fetchPlayerList = async () => {
    let param = {
      mintType: "PLAYER",
    };

    if (rarity) {
      param.rarity = rarity;
    }

    if (ownerShip) {
      param.userType = ownerShip;
      param.offset = offset;
      param.limit = limit;
    }
    if (searchInput) {
      param.searchText = searchInput;
      // setOffset(1);
    }

    if (ownerShipPage != 0) {
      param.userType = ownerShipPage;
      param.offset = offset;
      param.limit = limit;
    } else {
      param.offset = offset;
      param.limit = limit;
    }

    if (type !== "ALL" && type !== "") {
      param.cardType = type === "ALLROUNDER" ? "ALL" : type;
      param.offset = offset;
      param.limit = limit;
    }

    if (Object.keys(selectedCountries).length > 0) {
      // const query = await selectedCountries
      //   .map((item) => {
      //     return item.id;
      //   })
      //   .join(",");
      param.country = selectedCountries?.id;
    }

    dispatch(getStadiumList(param, callback));
  };

  const fetchSearchedPlayerList = async () => {
    let param = {
      mintType: "PLAYER",
      offset: offset,
      limit: limit,
    };
    if (searchInput) {
      param.searchText = searchInput;
      setOffset(1);
    }
    if (type !== "ALL" && type !== "") {
      param.cardType = type === "ALLROUNDER" ? "ALL" : type;
      param.offset = offset;
      param.limit = limit;
    }
    if (Object.keys(selectedCountries).length > 0) {
      // const query = await selectedCountries
      //   .map((item) => {
      //     return item.id;
      //   })
      //   .join(",");
      param.country = selectedCountries?.id;
    }

    dispatch(getSearchedNfts(param, callSearch));
  };

  // const confirmMatch = async () => {
  //   const players = await seletedPlayer.map((item) => item?.nftId).join(",");
  //   let param = {
  //     stadium_id: playerMatchedData?.roomData?.stadiumNftId.toString(),
  //     players,
  //   };
  //   dispatch(finalSubmit(param));

  //   socket.emit(
  //     playerMatchedData?.roomData?.isSecondPlayerBot
  //       ? "save_confirm_bot"
  //       : "save_confirm",
  //     {
  //       roomId: playerMatchedData?.roomId,
  //       players: players,
  //       socketId: socket.id,
  //     }
  //   );

  //   //  setShowConifrm(false)
  //   setWaitModal(true);
  // };

  const handleSubmit = async () => {
    if (seletedPlayer.length === 5) {
      const players = await seletedPlayer.map((item) => item?.nftId).join(",");
      let param = {
        stadium_id: playerMatchedData?.roomData?.stadiumNftId.toString(),
        players,
      };
      dispatch(finalSubmit(param));
      socket.emit(
        playerMatchedData?.roomData?.isSecondPlayerBot
          ? "save_confirm_bot"
          : "save_confirm",
        {
          roomId: playerMatchedData?.roomId,
          players: players,
          socketId: socket.id,
        }
      );

      socket.on("match_detail", (data) => {
        if (data?.data?.roomData?.MatchStatus == "INPROGRESS") {
          dispatch(matchedData(data));
          navigate("/playground");
        }
      });

      //  setShowConifrm(false)
      setWaitModal(true);

      // setCount(50);
      // setShowConifrm(true);
    } else {
      toast("Select atleast 5 players", {
        toastId: "errorBuild3",
      });
    }
  };

  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 7,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 680,
        settings: {
          slidesToShow: 5,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 5,
          slidesToScroll: 1,
        },
      },
    ],
  };

  const addSelectedPlayer = (player) => {
    const checkPlayer = seletedPlayer.filter(
      (item) => player?.nftId === item?.nftId
    );
    if (checkPlayer.length > 0) {
      toast("The player is already selected!", {
        toastId: "errorBuild1",
      });
    } else {
      if (seletedPlayer.length > 4) {
        toast("You have already selected 5 players", {
          toastId: "errorBuild2",
        });
      } else {
        const newData = [...seletedPlayer, player];
        setSeletedPlayer(newData);
      }
    }
  };

  const handleRemovePlayer = (index) => {
    seletedPlayer.splice(index, 1);
    const newData = [...seletedPlayer];
    setSeletedPlayer(newData);
  };

  const handleCountry = (country) => {
    setOffset(1);
    if (selectedCountries?.id == country?.id) {
      setSelectedCountries({});
    } else {
      setSelectedCountries(country);
    }
  };
  const callbackLastFivePlayer = (data) => {
    if (data) {
      let playerIds = [];
      let res = data?.data?.nfts;
      res &&
        res.length > 0 &&
        res.map((item) => {
          return playerIds.push({ ...item, nftId: item?.id });
        });
      setSeletedPlayer(playerIds);
      return;
    }
    return null;
  };

  useEffect(() => {
    dispatch(getCountry((data) => setCountryList(data?.data?.nfts)));
    dispatch(getLastFivePlayer(callbackLastFivePlayer));
    socket.removeListener("room_destroyed");
    socket.on("room_destroyed", (data) => {
      if (data?.data?.roomData?.MatchStatus == "COMPLETED") {
        if (splitLocation[1] == "build-team") {
          toast.error(data?.message);
          setTimeout(() => {
            window.location.replace("/");
          }, 3000);
        }
      }
    });
    setTimeout(() => {
      setEnableSearch(true);
      setShowVsModal(false);
      dispatch(setCountDownEnable(true));
      setCount(timeToLapse);
    }, 5000);
  }, [getData]);

  useEffect(() => {
    if (enableSearch) {
      fetchSearchedPlayerList();
    }
  }, [searchInput]);

  useEffect(() => {
    if (!!playerMatchedData) {
      dispatch(enableDoneBtn({}));
    } else {
      socket.disconnect();
      socket.removeListener("game_status");
      navigate("/");
    }
  }, [playerMatchedData]);

  useEffect(() => {
    setOffset(1);
    setOwnerShipPage(0);
    fetchPlayerList();
    setSearchInput("");
    if (rented.length > 0) {
      var myDiv = document.getElementById("scrollableDivRent");
      myDiv.scrollTop = 0;
    }
  }, [type, rarity, ownerShip, selectedCountries]);

  const searchShow = (e) => {
    setBar(true);
    setSearchInput("");
    setOwned(ownedData);
    setRented(rentedData);
  };

  const searchHide = (e) => {
    e.preventDefault();
    setBar(false);
    setSearchInput("");
    setOwned(ownedData);
    setRented(rentedData);
  };

  useEffect(() => {
    if (ownerShipPage != 0) {
      fetchPlayerList();
      setOwnerShipPage(0);
    }
  }, [ownerShipPage]);

  const fetchOwnedData = () => {
    if (owned.length < ownedCount) {
      setOffset(offset + 1);
      setLimit(limit);
      setOwnerShipPage(1);
    }
  };

  const fetchRentData = () => {
    if (rented.length < rentCount) {
      setOffset(offset + 1);
      setLimit(limit);
      setOwnerShipPage(2);
    }
  };

  const handleSearch = (e) => {
    var myDiv = document.getElementById("scrollableDivRent");
    myDiv.scrollTop = 0;

    setOffset(1);
    let val = e.target.value;
    if (val != "") {
      setSearchInput(val.toLowerCase());
    } else {
      setSearchInput("");
    }

    // if (val != "") {
    //   setBar(false);

    //   let newOwnedData =
    //     ownedData &&
    //     ownedData.length > 0 &&
    //     ownedData.filter((item) =>
    //       item?.gameTitle.toLowerCase().includes(val.toLowerCase())
    //     );

    //   let newRentedData =
    //     rentedData &&
    //     rentedData.length > 0 &&
    //     rentedData.filter((item) =>
    //       item?.gameTitle.toLowerCase().includes(val.toLowerCase())
    //     );

    //     // if(newnftData){
    //     //   setRented(newnftData);
    //     // }
    //     // else{
    //     //   setRented(rentedData);
    //     // }
    //   setOwned(newOwnedData);

    // } else {
    //   setBar(true);
    //   setOwned(ownedData);
    //   setRented(rentedData);
    // }
  };

  const closeModal = () => {
    setShowConifrm(false);
  };

  const handleSubmitSearch = (event) => {
    event.preventDefault();
    return false;
  };
  return (
    <>
      {waitModal && (
        <WaitingModal
          message={"Waiting for opponent to select team"}
          subMessage={""}
          opponent={true}
          currentCount={currentCount}
          showTimer={true}
          // timerclose={timerclose}
        />
      )}

      

      {/* {showConifrm && (
        <ConfirmModal
          showConifrm={showConifrm}
          timeAnimation={timeAnimation}
          confirmMatch={confirmMatch}
          closeModal={closeModal}
          currentCount={currentCount}
        />
      )} */}
      {showVsModal && !!stadium && (
        <PlayerVsModal
          socket={socket}
          matchedData={playerMatchedData}
          showVsModal={showVsModal}
        />
      )}
      <CardModal show={show} handleClose={handleClose} imgSrc={modalImg} />

      {/* <MatchingModal
        countDown={countDown}
        opponent={opponent}
        timerclose={timerclose}
        timeAnimation={timeAnimation}
      /> */}
      <div className={`BuildTeam ${bottomHeight ? "TeamHeight" : ""}`}>
        <h3>Build Your Team</h3>
        <div className="country">
          {/* <div className="search">
            <h6>Country</h6>
            <div className="buttonsearch">
              <button
                className={bar ? "search-Hide " : "search-Show"}
                onClick={() => {
                  searchShow();
                }}
              >
                <img src={search} alt="search" />
              </button>
            </div>
            <div className={bar ? "search-Show " : "search-Hide"}>
              <Form className="d-flex align-center">
                <FormControl
                  onChange={handleSearch}
                  // type="search"
                  placeholder="Search"
                  className="me-2"
                  aria-label="Search"
                  value={searchInput}
                />
                <button onClick={searchHide}>
                  <img src={crose} alt="crose" className="crose" />
                </button>
              </Form>
            </div>
          </div> */}
          <ul className="countryList">
            <Slider {...settings}>
              {countryList &&
                countryList.length > 0 &&
                countryList?.map((item, index) => (
                  <li key={index}>
                    <div
                      className={`flagCountry ${
                        selectedCountries?.id == item?.id ? "active" : ""
                      }`}
                      onClick={() => handleCountry(item)}
                    >
                      <img className="Flags" src={item?.logo} />
                      <p>{item?.code}</p>
                    </div>
                  </li>
                ))}
            </Slider>
          </ul>
          <div className="selectare">
            {/* <div className="Rarity">
              <Dropdown onSelect={(e) => setRarity(e)}>
                <Dropdown.Toggle id="dropdown-basic">
                  {" "}
                  {rarity ? rarity : "Rarity"}
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item eventKey="Epic">Epic</Dropdown.Item>
                  <Dropdown.Item eventKey="Rare">Rare</Dropdown.Item>
                  <Dropdown.Item eventKey="SuperRare">Super Rare</Dropdown.Item>
                  <Dropdown.Item eventKey="Common">Common</Dropdown.Item>
                  <Dropdown.Item eventKey="">All</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div> */}
            <div className="SearchBar">
              <div className="serch_field">
                <Form
                  onSubmit={handleSubmitSearch}
                  className="d-flex align-center"
                >
                  <FormControl
                    onChange={handleSearch}
                    // type="search"
                    placeholder="Search"
                    className="me-2"
                    aria-label="Search"
                    value={searchInput}
                  />
                  {bar ? (
                    <button type="submit" className="icon_Search">
                      <img src={search} alt="search" />
                    </button>
                  ) : (
                    <button
                      type="cross"
                      onClick={searchShow}
                      className="icon_cross"
                    >
                      <img src={crossWit} alt="search" />
                    </button>
                  )}
                </Form>
              </div>
            </div>
            <div className="type_Drop">
              <Dropdown
                onSelect={(e) => {
                  setOffset(1);
                  setType(e);
                }}
              >
                <Dropdown.Toggle id="dropdown-basic">
                  {type
                    ? type == "BAT"
                      ? "Batsman"
                      : type == "BOWL"
                      ? "Bowler"
                      : type == "ALLROUNDER"
                      ? "All Rounder"
                      : "All"
                    : "All"}
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item eventKey="BAT">Batsman</Dropdown.Item>
                  <Dropdown.Item eventKey="BOWL">Bowler</Dropdown.Item>
                  <Dropdown.Item eventKey="ALLROUNDER">
                    All Rounder
                  </Dropdown.Item>
                  <Dropdown.Item eventKey="ALL">All</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
            {/* <div className="Rarity">
              <Dropdown onSelect={(e) => setOwnerShip(e)}>
                <Dropdown.Toggle id="dropdown-basic">
                  {ownerShip == 1
                    ? "Buy Me"
                    : ownerShip == 2
                    ? "Rented"
                    : "Ownership"}
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item eventKey="1">Buy Me</Dropdown.Item>
                  <Dropdown.Item eventKey="2">Rented</Dropdown.Item>
                  <Dropdown.Item eventKey="">All</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div> */}
          </div>
          {/* {owned.length > 0 && (
            <div className="imagepick">
              <p>Owned Cards</p>

              <div
                id="scrollableDivOwned"
                style={{ display: "flex", height: 500, overflow: "auto" }}
              >
                <InfiniteScroll
                  dataLength={owned.length}
                  // dataLength={4}

                  next={fetchOwnedData}
                  hasMore={true}
                  loader={owned.length < ownedCount ? <h4>Loading...</h4> : ""}
                  scrollableTarget="scrollableDivOwned"
                >
                  {owned &&
                    !!owned &&
                    owned.map((player, index) => {
                      return (
                        <>
                          <div className="first" key={index}>
                            <div onClick={() => addSelectedPlayer(player)}>
                              <img src={player?.nftLogo} alt="KL_Rahul" />
                              <button
                                className="ViewButton"
                                onClick={() => {
                                  setModalImg(player?.nftLogo);
                                  handleShow();
                                }}
                              >
                                View
                              </button>
                              <div className="iconWallet">
                                <button className="wallIcon">
                                  <img src={walleticon} alt="walleticon" />
                                </button>
                              </div>
                            </div>
                            <p className="playerName">{player?.gameTitle}</p> 
                          </div>
                        </>
                      );
                    })}
                </InfiniteScroll>
              </div>
            </div>
          )} */}
          {rented.length > 0 ? (
            <div className="imagepick">
              {/* <p>Rented Cards</p> */}
              <div
                id="scrollableDivRent"
                style={{
                  // display: "flex",

                  height: 500,
                  overflow: "auto",
                }}
              >
                <InfiniteScroll
                  dataLength={rented.length}
                  next={fetchRentData}
                  // style={{ display: "flex", flexDirection: "column-reverse" }} //To put endMessage and loader to the top.
                  // inverse={true}
                  hasMore={rented.length < rentCount ? true : false}
                  scrollableTarget="scrollableDivRent"
                >
                  {rented &&
                    rented.length > 0 &&
                    rented?.map((player, index) => (
                      <div className="first" key={index}>
                        <div onClick={() => addSelectedPlayer(player)}>
                          <img src={player?.nftLogo} alt="KL_Rahul" />
                        </div>
                        {/* <button
                          className="ViewButton"
                          onClick={() => {
                            setModalImg(player?.nftLogo);
                            handleShow();
                          }}
                        >
                          View
                        </button> */}
                        <button
                          className="ViewButton"
                          onClick={() => {
                            setShow(true)
                            setPlayerStats(player)
                          }}
                        >
                          <img src={eyeIcon} alt="info" />
                        </button>
                        {/* <Modalcard/> */}
                        {/* <p className="playerName">{player?.gameTitle}</p> */}
                      </div>
                    ))}
                </InfiniteScroll>
              </div>
            </div>
          ) : (
            <p className="recordFound">No Record Found!</p>
          )}
        </div>
      </div>

      <Container>
        <div className="contin_button">
          <div className={`cardFixe ${bottomHeight ? "setHeight" : ""}`}>
            <div onClick={() => BottomBarHandler()} className="arrowHeader">
              <img src={drop} alt="ballfire" className="Bat cursre" />
            </div>
            <div className="listingFile">
              <ul>
                {Array.apply(null, Array(5))?.map((item, index) =>
                  seletedPlayer[index] ? (
                    <li key={index} className="isSelected">
                      <button
                        className="btnClose"
                        onClick={() => handleRemovePlayer(index)}
                      >
                        <img src={cross} alt="close" />
                      </button>
                      <div className="imageBack">
                        <img
                          src={seletedPlayer[index]?.nftLogo}
                          alt={seletedPlayer[index]?.name}
                        />
                      </div>
                      {/* <p>{seletedPlayer[index]?.gameTitle}</p> */}
                    </li>
                  ) : (
                    <li>
                      <div className="icons">
                        <img src={icon_plus} alt="Virat" />
                      </div>
                    </li>
                  )
                )}
              </ul>
            </div>
          </div>
          <div className="editbutton">
            <button onClick={() => handleSubmit()}>Continue</button>
          </div>
        </div>
      </Container>
      {/* {console.log('playerStats',playerStats)} */}
      {show && <Modalcard handleClose={handleClose} show={show} playerStats={playerStats}/>}

    </>
  );
}

export default BuildTeam;
