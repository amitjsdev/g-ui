import React, { useEffect, useState } from "react";
import search from "../../assets/images/search.svg";
import India from "../../assets/images/countryFlag/India.png";
import WI from "../../assets/images/countryFlag/WI.png";
import Eng from "../../assets/images/countryFlag/Eng.png";
import Slider from "react-slick";
import "././BuildTeamS1.scss";
import { Button, Dropdown, Modal } from "react-bootstrap";
import KL_Rahul from "../../assets/images/KL_Rahul.png";
import FafDu_Plessis from "../../assets/images/FafDu_Plessis.png";
import Kane_Williamso from "../../assets/images/Kane_Williamso.png";
import icon_plus from "../../assets/images/icon_plus.png";
import flip from "../../assets/images/flip.svg";
import timer from "../../assets/images/timer.png";
import Lottie from "react-lottie";
import * as animationData from "../../assets/images/Planet.json";
import vpopy from "../../assets/images/v-pixell copy.png";
import cross from "../../assets/images/cross_icon.svg";
import icnSelect from "../../assets/images/icon_selected.png";
import { useNavigate } from "react-router-dom";

function BuildTeamS1() {
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [opponent, setOpponent] = useState(false);
  const timerclose = () => setOpponent(false);
  const timershow = () => setOpponent(true);

  let navigate = useNavigate();

  const timeAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  var settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 7,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 680,
        settings: {
          slidesToShow: 7,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 5,
          slidesToScroll: 1,
        },
      },
    ],
  };
  const CountryContent = [
    {
      title: "IND",
      img: India,
    },
    {
      title: "WI",
      img: WI,
    },
    {
      title: "ENG",
      img: Eng,
    },
    {
      title: "IND",
      img: India,
    },
    {
      title: "WI",
      img: WI,
    },
  ];
  const goToNext = () => {
    setTimeout(() => {
      navigate("/ground");
    }, 2000);
    setOpponent({ opponent: true });
  };
  // useEffect()

  return (
    <>
      <div className="BuildTeam">
        <h3>Build Team</h3>
        <div className="country">
          <div className="search">
            <h6>Country</h6>
            <img src={search} alt="search" className="searchIcon" />
          </div>
          <ul className="countryList">
            <Slider {...settings}>
              {CountryContent.map((item, idx) => (
                <li>
                  <div className="flagCountry active">
                    <img className="Flags" src={item?.logo} />
                    <p>{item?.code}</p>
                  </div>
                </li>
              ))}
            </Slider>
          </ul>
          <div className="selectare">
            <div className="Rarity">
              <Dropdown>
                <Dropdown.Toggle id="dropdown-basic">Rarity</Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1">Epic</Dropdown.Item>
                  <Dropdown.Item href="#/action-2">Rare</Dropdown.Item>
                  <Dropdown.Item href="#/action-3">Super Rare</Dropdown.Item>
                  <Dropdown.Item href="#/action-4">Common</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
            <div className="Rarity">
              <Dropdown>
                <Dropdown.Toggle id="dropdown-basic">Type</Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1">Batsman</Dropdown.Item>
                  <Dropdown.Item href="#/action-2">Bowler</Dropdown.Item>
                  <Dropdown.Item href="#/action-3">All Rounder</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
            <div className="Rarity">
              <Dropdown>
                <Dropdown.Toggle id="dropdown-basic">Ownership</Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1">Buy Me</Dropdown.Item>
                  <Dropdown.Item href="#/action-2">All</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>
          </div>
          <div className="imagepick">
            <div className="first">
              <img src={icnSelect} className="imgSelected" />
              <img src={KL_Rahul} alt="KL_Rahul" />
              <button onClick={handleShow}>View</button>
            </div>
            <div className="first">
              <img src={icnSelect} className="imgSelected" />
              <img src={FafDu_Plessis} alt="FafDu_Plessis" />
              <button onClick={handleShow}>View</button>
            </div>
            <div className="first">
              <img src={icnSelect} className="imgSelected" />
              <img src={Kane_Williamso} alt="KL_Rahul" />
              <button onClick={handleShow}>View</button>
            </div>
            <div className="first">
              <img src={icnSelect} className="imgSelected" />
              <img src={KL_Rahul} alt="KL_Rahul" />
              <button onClick={handleShow}>View</button>
            </div>
            <div className="first">
              <img src={icnSelect} className="imgSelected" />
              <img src={FafDu_Plessis} alt="FafDu_Plessis" />
              <button onClick={handleShow}>View</button>
            </div>
            <div className="first">
              <img src={Kane_Williamso} alt="KL_Rahul" />
              <button onClick={handleShow}>View</button>
            </div>
            <div className="first">
              <img src={Kane_Williamso} alt="KL_Rahul" />
              <button onClick={handleShow}>View</button>
            </div>
            <div className="first">
              <img src={Kane_Williamso} alt="KL_Rahul" />
              <button onClick={handleShow}>View</button>
            </div>
            <div className="first">
              <img src={Kane_Williamso} alt="KL_Rahul" />
              <button onClick={handleShow}>View</button>
            </div>
          </div>
        </div>
        <Modal
          show={show}
          centered={true}
          className="frontBack_modal"
          onHide={handleClose}
        >
          <Modal.Header closeButton>
            {/* <Modal.Title>Front View</Modal.Title> */}
          </Modal.Header>
          <Modal.Body>
            {/* <img src={flip} alt="flip" className="flip" /> */}
            <div className="bodytype">
              <img src={Kane_Williamso} alt="KL_Rahul" />
            </div>
          </Modal.Body>
        </Modal>
        <Modal
          className="second"
          show={opponent}
          centered={true}
          onHide={timerclose}
        >
          <Modal.Body className="LookOppo">
            <div className="looking">
              <div className="opponent">
                <h6>LOOKING FOR</h6>
                <h3>OPPONENT</h3>
              </div>
            </div>
            <div className="globAnimation">
              <Lottie options={timeAnimation} height={250} width={250} />
            </div>
            <div className="starting">
              <div className="backtim">
                <h2>00</h2>
              </div>
              :
              <div className="backtim">
                <h2>00</h2>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      </div>
      <div className="cardFixe">
        <div className="listingFileTe">
          <ul>
            <li className="isSelected">
              <button className="btnClose">
                <img src={cross} alt="close" />
              </button>
              <img src={FafDu_Plessis} alt="FafDu_Plessis" />
            </li>
            <li className="isSelected">
              <button className="btnClose">
                <img src={cross} alt="close" />
              </button>
              <img src={Kane_Williamso} alt="KL_Rahul" />
            </li>
            <li className="isSelected">
              <button className="btnClose">
                <img src={cross} alt="close" />
              </button>
              <img src={KL_Rahul} alt="KL_Rahul" />
            </li>
            <li className="isSelected">
              <button className="btnClose">
                <img src={cross} alt="close" />
              </button>
              <img src={FafDu_Plessis} alt="FafDu_Plessis" />
            </li>
            <li className="isSelected">
              <button className="btnClose">
                <img src={cross} alt="close" />
              </button>
              <img src={Kane_Williamso} alt="KL_Rahul" />
            </li>
          </ul>
        </div>
        <div className="editbutton">
          <button onClick={() => goToNext()}>Continue</button>
        </div>
      </div>
    </>
  );
}

export default BuildTeamS1;
