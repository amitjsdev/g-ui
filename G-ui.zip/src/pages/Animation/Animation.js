import React from "react";
import "./Animation.scss";
import gedborder from "../../assets/images/gedborder.svg";
import Lottie from "react-lottie";
import * as animationFrame from "../../assets/images/grounsplay.json";
import addground from "../../assets/images/addground.png";
import { ReactComponent as Lotty } from "../../assets/images/gedborder.svg";
import Overlist from "../PlayGround/Playing/Overlist";
const Animation = () => {
  const frameAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationFrame,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  const myStyle = {
    animation: "dash 10s linear infinite",
  };
  return (
    <>
      <div>
        <div className="plaer">
          <div className="ground">
            {/* <div className="adflip">
                            <Lottie options={frameAnimation} />
                        </div> */}
            <div className="bordgrd">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="292"
                height="239"
                viewBox="0 0 292 239"
              >
                <g
                  id="Rectangle_12196"
                  data-name="Rectangle 12196"
                  fill="none"
                  stroke="#2bff2f"
                  stroke-width="5"
                >
                  <rect
                    id="path"
                    width="292"
                    height="239"
                    rx="20"
                    stroke="none"
                  />
                  <rect
                    id="num"
                    x="1"
                    y="1"
                    width="290"
                    height="237"
                    rx="20"
                    fill="none"
                    style={{
                      strokeDashoffset: "1020",
                      strokeDasharray: "1020",
                      animation: "dash 10s linear infinite",
                    }}
                  />
                </g>
              </svg>
              {/* <Lotty style={myStyle} /> */}
              {/* <img src={gedborder} alt="gedborder" /> */}
            </div>
            <img src={addground} alt="addground" />
          </div>
          <div className="main_Contint">
            <p>
              Tap below if you wish
              <br /> to change player
            </p>
          </div>
        </div>
      </div>
      <Overlist />
    </>
  );
};

export default Animation;
