import React, { useState } from 'react';
import { Button, Modal } from 'react-bootstrap';
import ViratVe from "../../assets/images/ViratVe.png";
import Kane from "../../assets/images/Kane2.png";
import Bat from "../../assets/images/Bat.svg";
import ball from "../../assets/images/ball.svg";
import Out from "../../assets/images/Out.svg";
import "./SelectPlayer.scss";

function ScoreBoard() {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return (
        <>
            <Button variant="primary" onClick={handleShow}>
                Launch demo modal
            </Button>
            <Modal
                className="second"
                centered={true} show={show} onHide={handleClose}
            // onHide={timerclose}
            >
                <Modal.Header>
                </Modal.Header>
                <Modal.Body className="Team_Score">
                    <div className="scoreBoard">
                        <div className='Title'>
                            <h3>Score Board</h3>
                        </div>
                        <div className="Cards">
                            <div className="Player">
                                <div className='Match'>
                                    <img src={Bat} alt="Bat" className="Bat" /> &nbsp; &nbsp;
                                    <h6>You</h6>
                                </div>
                                <img src={ViratVe} alt="ViratVe" className="ViratVe" />
                                <div className='out_Icon'>
                                    <img src={Out} alt="Out" />

                                </div>
                            </div>
                            <div className="Player_Opponent">
                                <div className='Match'>
                                    <img src={ball} alt="Bat" className="ball" /> &nbsp; &nbsp;
                                    <h6>Opponent</h6>
                                </div>
                                <img src={Kane} alt="Kane" className="Kane" />
                            </div>
                        </div>
                        <div className='scoring'>
                            <div className='over_score'>
                                <h5>Over</h5>
                                <h6>1</h6>
                            </div>
                            <div className='over_score'>
                                <h5>Score</h5>
                                <h6>47/1</h6>
                            </div>
                            <div className='over_score'>
                                <h5>Shivam Dube</h5>
                                <h6>44(25)</h6>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>
        </>
    )
}

export default ScoreBoard