import React, { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import Bowler_Icon from "../../assets/images/Bowler_Icon.svg";
import "./SelectPlayer.scss";

function Bowler() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Launch demo modal
      </Button>
      <Modal
        className="second"
        centered={true}
        show={show}
        onHide={handleClose}
        // onHide={timerclose}
      >
        <Modal.Header></Modal.Header>
        <Modal.Body className="Select_Team">
          <div className="Batsman">
            <div className="Title">
              <h3>
                It's your turn <br />
                to BOWL!
              </h3>
            </div>
            <div className="Playing">
              <img src={Bowler_Icon} alt="Bowler_Icon" />
            </div>
            <div className="batsman_Button">
              <h5>Select Your Bowler</h5>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default Bowler;
