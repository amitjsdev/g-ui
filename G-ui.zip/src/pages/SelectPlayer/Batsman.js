import React, { useState } from 'react';
import { Button, Modal } from 'react-bootstrap';
import Batsman_icon from "../../assets/images/Batsman_icon.svg";
import "./SelectPlayer.scss";

function Batsman() {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    return (
        <>
            <Button variant="primary" onClick={handleShow}>
                Launch demo modal
            </Button>
            <Modal
                className="second"
                centered={true} show={show} onHide={handleClose}
            // onHide={timerclose}
            >
                <Modal.Header>
                </Modal.Header>
                <Modal.Body className="Select_Team">
                    <div className="Batsman">
                        <div className='Title'>
                            <h3>It's your turn <br />to BAT!</h3>
                        </div>
                        <div className='Playing'>
                            <img src={Batsman_icon} alt="Batsman_icon" />
                        </div>
                        <div className='batsman_Button'>
                            <h5>Select Your Batsman</h5>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>
        </>
    )
}

export default Batsman