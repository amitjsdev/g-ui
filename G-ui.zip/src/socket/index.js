import { ACCESS_TOKEN, SOCKET_URL, SOCKET_PATH } from "../utils/constant";
import io from "socket.io-client";
import { getToken } from "../Helpers/storageHelper";

const socket = io.connect(SOCKET_URL, {
  path: SOCKET_PATH,
  reconnection: true,
  reconnectionDelay: 1000,
  reconnectionDelayMax: 5000,
  reconnectionAttempts: 99999,
  query: { "access-token": getToken(ACCESS_TOKEN) },
  transports: ["websocket"],
});
console.log("scoket--", socket, "url", SOCKET_URL);

socket.on("connect", (data) => {
  console.log("connected to server", data);
});

socket.on("connect_error", (err) => {
  console.log(`connect_error due to ${err.message}`);
});

socket.on("disconnect", () => {
  console.log("disconnected to server");
});

export default socket;
