export const startLoader = 'START_LOADER';
export const stopLoader = 'STOP_LOADER';
