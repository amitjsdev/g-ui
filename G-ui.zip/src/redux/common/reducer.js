import { startLoader, stopLoader } from './types';

// initial state
const initialCommonState = {
  isLoading: false,
  theme: null,
};

// Common Reducer function
export const commonReducer = (state = { ...initialCommonState }, action) => {
  switch (action.type) {
    case startLoader:
      return {
        ...state,
        isLoading: true,
      };
    case stopLoader:
      return {
        ...state,
        isLoading: false,
      };
    // case setTheme:
    //   return {
    //     ...state,
    //     theme: action.data,
    //   };
    default:
      return state;
  }
};

export default commonReducer;
