// third party
import { takeLatest, throttle, all, put } from "redux-saga/effects";
import { toast } from "react-toastify";
// Application
import * as type from "./types";
import { startLoading, stopLoading } from "../common/actions";
import * as action from "./action";
import { setUserDetails } from "./action";
import { httpGet, httpPost } from "../../utils/https";
import URLS from "../../utils/urls";
import { getAccessToken } from "../../utils/helper";
import {
  ACCESS_TOKEN,
  MARKET_PLACE_URL,
  STATUS_CODE,
} from "../../utils/constant";
import { getToken } from "../../Helpers/storageHelper";

// Get User Details dummy api
function* getUserDetails({ callback }) {
  try {
    yield put(startLoading());
    const response = yield httpGet(`${URLS.USER.testApi}`, "", {});
    yield put(stopLoading());
    callback(response?.data);
  } catch (error) {
    yield put(stopLoading());
  }
}

//Get Stadium list
function* getStadiumList({ param, callback }) {
  try {
    yield put(startLoading());
    const response = yield httpGet(
      `${URLS.USER.NFT_LIST}`,
      getToken(ACCESS_TOKEN),
      {},
      param
    );
    yield put(stopLoading());
    callback(response?.data);
  } catch (error) {
    yield put(stopLoading());
  }
}
//search player nft
function* getSearchedNfts({ param, callSearch }) {
  try {
    // yield put(startLoading());
    const response = yield httpGet(
      `${URLS.USER.SEARCHED_PLAYER_NFT}`,
      getToken(ACCESS_TOKEN),
      {},
      param
    );
    yield put(stopLoading());
    callSearch(response?.data);
  } catch (error) {
    yield put(stopLoading());
  }
}

//Get user balance
function* getUserBalance({ param }) {
  try {
    yield put(startLoading());
    const response = yield httpGet(
      `${URLS.USER.BALANCE}`,
      getToken(ACCESS_TOKEN),
      {},
      param
    );
    if (response?.data?.status === STATUS_CODE.successful) {
      yield put(action.setUserBalance(response?.data?.data));
      yield put(stopLoading());
    } else if (
      response?.status === STATUS_CODE?.unAuthorized ||
      response?.status === STATUS_CODE.forbidden ||
      response?.status === STATUS_CODE.badRequest
    ) {
      toast.error(response?.data?.message);
      yield put(stopLoading());
      window.location.replace(MARKET_PLACE_URL);
    } else {
      toast.error(response?.data?.message);
      yield put(stopLoading());
    }
  } catch (error) {
    yield put(stopLoading());
  }
}

//getCountry
function* getCountry({ callback }) {
  try {
    yield put(startLoading());
    const response = yield httpGet(
      `${URLS.USER.GET_COUNTRY}`,
      getToken(ACCESS_TOKEN),
      "",
      ""
    );
    if (
      response?.status === STATUS_CODE?.unAuthorized ||
      response?.status === STATUS_CODE.forbidden ||
      response?.status === STATUS_CODE.badRequest
    ) {
      toast.error(response?.data?.message);
      window.location.replace(MARKET_PLACE_URL);
    }
    yield put(stopLoading());
    callback(response?.data);
  } catch (error) {
    yield put(stopLoading());
  }
}

//get last five player list
function* getLastFivePlayer({ callbackLastFivePlayer }) {
  try {
    yield put(startLoading());
    const response = yield httpGet(
      `${URLS.USER.GET_PLAYER_HISTORY}`,
      getToken(ACCESS_TOKEN),
      "",
      ""
    );
    if (
      response?.status === STATUS_CODE?.unAuthorized ||
      response?.status === STATUS_CODE.forbidden ||
      response?.status === STATUS_CODE.badRequest
    ) {
      toast.error(response?.data?.message);
      window.location.replace(MARKET_PLACE_URL);
    }
    yield put(stopLoading());
    callbackLastFivePlayer(response?.data);
  } catch (error) {
    yield put(stopLoading());
  }
}
//Sumit for matching players
function* finalSubmit({ param }) {
  try {
    yield put(startLoading());
    const response = yield httpPost(
      URLS.USER.SAVE_PLAYER,
      getToken(ACCESS_TOKEN),
      param,
      ""
    );

    if (response?.data?.status === STATUS_CODE.successful) {
      yield put(action.setUserBalance(response?.data?.data));
      yield put(stopLoading());
    } else if (
      response?.status === STATUS_CODE?.unAuthorized ||
      response?.status === STATUS_CODE.forbidden ||
      response?.status === STATUS_CODE.badRequest
    ) {
      toast.error(response?.data?.message);
      yield put(stopLoading());
      window.location.replace(MARKET_PLACE_URL);
    } else {
      toast.error(response?.data?.message);
      yield put(stopLoading());
    }
  } catch (error) {
    yield put(stopLoading());
  }
}

//Get Artefacts list
function* getArtifactsList({ callback }) {
  try {
    yield put(startLoading());
    const response = yield httpGet(
      `${URLS.USER.GET_ARTEFACTS}`,
      getToken(ACCESS_TOKEN),
      {},
      ""
    );
    if (
      response?.status === STATUS_CODE?.unAuthorized ||
      response?.status === STATUS_CODE.forbidden ||
      response?.status === STATUS_CODE.badRequest
    ) {
      toast.error(response?.data?.message);
      window.location.replace(MARKET_PLACE_URL);
    }
    yield put(stopLoading());
    callback(response?.data);
  } catch (error) {
    yield put(stopLoading());
  }
}

//Buy atifacts
function* buyArtifacts({ param, callback }) {
  try {
    yield put(startLoading());
    const response = yield httpPost(
      URLS.USER.SAVE_ARTIFACTS,
      getToken(ACCESS_TOKEN),
      param,
      ""
    );

    if (response?.data?.status === STATUS_CODE.successful) {
      toast.success("Successfully purchased");
      callback(response?.data);
      //  yield put(stopLoading());
    } else if (
      response?.status === STATUS_CODE?.unAuthorized ||
      response?.status === STATUS_CODE.forbidden ||
      response?.status === STATUS_CODE.badRequest
    ) {
      toast.error(response?.data?.message);
      yield put(stopLoading());
      window.location.replace(MARKET_PLACE_URL);
    } else {
      toast.error(response?.data?.message);
      yield put(stopLoading());
    }
  } catch (error) {
    yield put(stopLoading());
  }
}

//get user purchased artifacts
function* getUserArtifacts(data) {
  try {
    yield put(startLoading());
    const response = yield httpGet(
      `${URLS.USER.GET_USER_ARTEFACTS}`,
      getToken(ACCESS_TOKEN),
      {},
      ""
    );
    if (
      response?.status === STATUS_CODE?.unAuthorized ||
      response?.status === STATUS_CODE.forbidden ||
      response?.status === STATUS_CODE.badRequest
    ) {
      toast.error(response?.data?.message);
      yield put(stopLoading());
      window.location.replace(MARKET_PLACE_URL);
    }
    yield put(action.setUserAritfacts(response?.data?.data));
    if (data?.param == "loadingTrue") {
      yield put(startLoading());
    } else {
      yield put(stopLoading());
    }
  } catch (error) {
    yield put(stopLoading());
  }
}

//deduct atifacts
function* deductArtifact({ param, callback }) {
  try {
    yield put(startLoading());
    const response = yield httpPost(
      URLS.USER.USER_DEDUCT_ARTIFACT,
      getToken(ACCESS_TOKEN),
      param,
      ""
    );

    if (response?.data?.status === STATUS_CODE.successful) {
      //toast.success('Request successful');
      callback(response?.data);
      yield put(
        setTimeout(() => {
          stopLoading();
        })
      );
    } else if (
      response?.status === STATUS_CODE?.unAuthorized ||
      response?.status === STATUS_CODE.forbidden ||
      response?.status === STATUS_CODE.badRequest
    ) {
      toast.error(response?.data?.message);
      yield put(stopLoading());
      window.location.replace(MARKET_PLACE_URL);
    } else {
      toast.error(response?.data?.message);
      yield put(stopLoading());
    }
  } catch (error) {
    yield put(stopLoading());
  }
}

export default function* userSaga() {
  yield all([takeLatest(type.userBalance, getUserBalance)]);
  yield all([takeLatest(type.stadiumList, getStadiumList)]);
  yield all([takeLatest(type.searchedNfts,getSearchedNfts)]);

  yield all([takeLatest(type.userDetails, getUserDetails)]);
  yield all([takeLatest(type.getCountry, getCountry)]);
  yield all([takeLatest(type.getLastFivePlayer, getLastFivePlayer)]);
  yield all([takeLatest(type.finalSubmit, finalSubmit)]);
  yield all([takeLatest(type.getArtifactsList, getArtifactsList)]);
  yield all([takeLatest(type.buyArtifacts, buyArtifacts)]);
  yield all([takeLatest(type.getUserArtifacts, getUserArtifacts)]);
  yield all([takeLatest(type.deductArtifact, deductArtifact)]);
}
