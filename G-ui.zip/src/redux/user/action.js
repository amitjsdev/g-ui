import * as type from "./types";
// import { UserService } from "../../services/UserService";

export const userRegisterAction = (data, callback) => ({
  type: type.userRegister,
  data,
  callback,
});

export const setRegisterUserAction = (data) => ({
  type: type.setRegisterUser,
  data,
});

export const setUserDetails = (data) => ({
  type: type.setUserDetails,
  data,
});

export const setCurrentStadiumRarity = (data) => ({
  type: type.currentStadiumRarity,
  data,
});

//get user balance dispatch data
export const setUserBalance = (data) => ({
  type: type.setUserBalance,
  data,
});

//get user balance dispatch data
export const startCountDown = (data) => ({
  type: type.startCountDownTimer,
  data,
});

//enable done button
export const enableDoneBtn = (data) => ({
  type: type.enableDoneButton,
  data,
});

//countDown enable
export const setCountDownEnable = (data) => ({
  type: type.countDownEnable,
  data,
});

//user artifacts
export const setUserAritfacts = (data) => ({
  type: type.userArtifacts,
  data,
});

//get user balance
export const getUserBalance = (param) => ({ type: type.userBalance, param });

export const savePlayer = (data) => ({ type: type.savePlayer, data });

//get stdaium list
export const getUserDetails = (callback) => ({
  type: type.userDetails,
  callback,
});

export const getStadiumList = (param, callback) => ({
  type: type.stadiumList,
  param,
  callback,
});

export const getSearchedNfts = (param, callSearch) => ({
  type: type.searchedNfts,
  param,
  callSearch,
});

export const getCountry = (callback) => ({
  type: type.getCountry,
  callback,
});

export const getLastFivePlayer = (callbackLastFivePlayer) => ({
  type: type.getLastFivePlayer,
  callbackLastFivePlayer,
});

export const finalSubmit = (param) => ({
  type: type.finalSubmit,
  param,
});

export const matchedData = (param) => ({
  type: type.matchedData,
  data: param,
});

export const checkForDoneBtn = (data) => ({
  type: type.checkForDoneBtn,
  data,
});

export const getArtifactsList = (callback) => ({
  type: type.getArtifactsList,
  callback,
});

export const buyArtifacts = (param, callback) => ({
  type: type.buyArtifacts,
  param,
  callback,
});

//GET USER ARTIFACTS
export const getUserArtifacts = (param) => ({
  type: type.getUserArtifacts,
  param,
});

//DEDUCT ARTIFACT
export const deductArtifact = (param, callback) => ({
  type: type.deductArtifact,
  param,
  callback,
});

// bowler
export const setBowlerRecords = (data) => ({
  type: type.bowlerRecords,
  data,
});

export const setBatBosterInningFirst = (data) => ({
  type: type.batBoosterFirstInning,
  data,
});

export const setBowlBosterInningFirst = (data) => ({
  type: type.bowlBoosterFirstInning,
  data,
});

export const setBatBosterInningSecond = (data) => ({
  type: type.batBoosterSecondInning,
  data,
});

export const setBowlBosterInningSecond = (data) => ({
  type: type.bowlBoosterSecondInning,
  data,
});
