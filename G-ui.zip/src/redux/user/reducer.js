import * as types from "./types";

const initialState = {
  enableDoneBtn: {},
  informBowlingTeam: false,
  bowlerRecords: [],
  batBoosterFirstInning: [],
  bowlBoosterFirstInning: [],
  batBoosterSecondInning: [],
  bowlBoosterSecondInning: [],
};

export const userReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.setUserDetails:
      return { ...state, userDetails: action?.data };

    case types.currentStadiumRarity:
      return { ...state, currentStadiumRarity: action?.data };

    case types.setUserBalance:
      return { ...state, userBalance: action?.data };

    case types.startCountDownTimer:
      return { ...state, startCountDown: action?.data };

    case types.matchedData:
      return { ...state, matchedData: action?.data };

    case types.enableDoneButton:
      return { ...state, enableDoneBtn: action?.data };

    case types.countDownEnable:
      return { ...state, countDownEnable: action?.data };

    case types.savePlayer:
      return { ...state, informBowlingTeam: action?.data };

    case types.userArtifacts:
      return { ...state, userArtifacts: action?.data };
    case types.bowlerRecords:
      return { ...state, bowlerRecords: action?.data };
    case types.batBoosterFirstInning:
      return { ...state, batBoosterFirstInning: action?.data };
    case types.bowlBoosterFirstInning:
      return { ...state, bowlBoosterFirstInning: action?.data };

    case types.batBoosterSecondInning:
      return { ...state, batBoosterSecondInning: action?.data };
    case types.bowlBoosterSecondInning:
      return { ...state, bowlBoosterSecondInning: action?.data };

    default:
      return state;
  }
};
