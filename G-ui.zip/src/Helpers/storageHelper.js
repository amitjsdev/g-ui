import {ENCRYPT_KEY} from "../utils/constant"


// set user type

export const setUserType = (userType, userTypeValue) => {
    window.sessionStorage.setItem(userType, userTypeValue);
    return true;
  };
  
  export const getUserType = (userType) =>
    window.sessionStorage.getItem(userType);
  
  export const removeUserType = (userType) =>
    window.sessionStorage.removeItem(userType);
  
  
  //cookie
  
  
  export const setToken = (token) => {
    localStorage.setItem('token',token);

  }
  
  
  
  export const getToken = (ACCESS_TOKEN) => {
    let tokenVal =  localStorage.getItem(ACCESS_TOKEN);
    return tokenVal;
 
  }
  
  export const removeToken = (ACCESS_TOKEN) => {
    localStorage.removeItem(ACCESS_TOKEN);

  }
  
  //set localstorage
  
  export const setLocalStorage = (value) => {
    localStorage.setItem('currentIp',value)
  }



export function requestEncryption(data) {
  
  let CryptoJS = require("crypto-js");
  // Encrypt
  let ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), ENCRYPT_KEY);
  return ciphertext.toString();

  // // Decrypt
  // var bytes  = CryptoJS.AES.decrypt(ciphertext.toString(), ENCRYPT_KEY);
  // var plaintext = bytes.toString(CryptoJS.enc.Utf8);
  // console.log('ciphertext--',plaintext)
  // debugger
}