import React from "react";
import { Modal } from "react-bootstrap";
import Lottie from "react-lottie";

function MatchingModal({ opponent, timeAnimation, countDown }) {
  return (
    <Modal
      className="second"
      show={opponent}
      centered={true}
      // onHide={timerclose}
    >
      <Modal.Body className="LookOppo">
        <div className="looking">
          <div className="opponent">
            <h6>LOOKING FOR</h6>
            <h3>OPPONENT</h3>
          </div>
        </div>

        <div className="globAnimation">
          <Lottie options={timeAnimation} height={250} width={250} />
        </div>
        <div className="starting">
          <div className="backtim">
            <h2>00</h2>
          </div>
          :
          <div className="backtim">
            <h2>{countDown < 10 ? 0+''+countDown : countDown}</h2>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

export default MatchingModal;
