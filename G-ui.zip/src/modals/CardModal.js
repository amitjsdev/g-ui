import React from "react";
import { Modal } from "react-bootstrap";
import flip from "../assets/images/flip.svg";

function CardModal({ show, handleClose, imgSrc }) {
  return (
    <Modal
      show={show}
      centered={true}
      className="frontBack_modal"
      onHide={handleClose}
    >
      <Modal.Header closeButton>
        {/* <Modal.Title>Front View</Modal.Title> */}
      </Modal.Header>
      <Modal.Body>
        {/* <img src={flip} alt="flip" className="flip" /> */}
        <div className="bodytype">
          <img src={imgSrc} alt="KL_Rahul" />
        </div>
      </Modal.Body>
    </Modal>
  );
}

export default CardModal;
