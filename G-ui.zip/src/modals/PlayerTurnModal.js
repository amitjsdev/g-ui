import React, { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import Batsman_icon from "../assets/images/Batsman_icon.svg";
import Bowler_Icon from "../assets/images/Bowler_Icon.svg";
import "./SelectPlayer.scss";

function Batsman({ playerSocketId }) {
  return (
    <>
      <Modal
        className="second"
        centered={true}
        show={true}
        // onHide={handleClose}
        // onHide={timerclose}
      >
        <Modal.Body className="Select_Team">
          <div className="Batsman">
            {playerSocketId == "Batsman" ? (
              <>
                <div className="Title">
                  <h3>
                    It's your turn <br />
                    to BAT!
                  </h3>
                </div>
                <div className="Playing">
                  <img src={Batsman_icon} alt="Batsman_icon" />
                </div>
                <div className="batsman_Button">
                  <h5>Select Your Batsman</h5>
                </div>
              </>
            ) : (
              <>
                {Bowler_Icon && (
                  <div className="Batsman">
                    <div className="Title">
                      <h3>
                        It's your turn <br />
                        to BOWL!
                      </h3>
                    </div>
                    <div className="Playing">
                      <img src={Bowler_Icon} alt="Bowler_Icon" />
                    </div>
                    <div className="batsman_Button">
                      <h5>Select Your Bowler</h5>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default Batsman;
