import React from "react";
import { Modal } from "react-bootstrap";
import Lottie from "react-lottie";
import * as animationData from "../assets/images/Planet.json";
import exit from "../assets/images/exit.png";
import "./TimeOutModal.scss";
import feedback from "../assets/images/feedback.png";

function TimeOutModal({ message, timeOut, subMessage }) {
  const timeAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };
  const leaveGame = () => {
    window.location.replace("/");
  };
  return (
    <Modal
      className="second timeOut"
      show={true}
      centered={true}
      onHide={timeOut}
    >
      <Modal.Body className="LookOppo Timer">
        <div className="looking">
          <div className="opponent waitng">
            <h5 className="gmaStrt_Heading">Timeout</h5>
            <p className="gmaStrt">You have not selected a player</p>

            {/* <br></br> */}
            <br />
            <botton onClick={leaveGame} className="GameDone">
              <img title="Exit Game" src={exit} alt="exit" className="exit" />
            </botton>
            {/* <div className="feedback">
              <a href="https://tally.so/r/w81dLl" target="_blank">
                <button>Provide Feedback</button>
              </a>
            </div> */}
          </div>
        </div>

        {/* <div className="globAnimation">
          <Lottie options={timeAnimation} height={250} width={250} />
        </div> */}
      </Modal.Body>
    </Modal>
  );
}

export default TimeOutModal;
