import React from "react";
import { Modal } from "react-bootstrap";
import Lottie from "react-lottie";
import * as animationData from "../assets/images/Planet.json";

function WaitingModal({ message, subMessage, showTimer, currentCount }) {
  const timeAnimation = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice",
    },
  };

  let minutes = 0;
  let seconds = 0;
  if (currentCount > 60) {
    minutes = parseInt(currentCount / 60);
    seconds = currentCount % 60;
  } else {
    minutes = 0;
    seconds = currentCount;
  }

  return (
    <Modal className="second" show={true} centered={true}>
      <Modal.Body className="LookOppo">
        <div className="looking">
          <div className="opponent waitng">
            <h5 className="gmaStrt_Heading">{message}</h5>
            <p className="gmaStrt">{subMessage}</p>
          </div>
        </div>

        <div className="globAnimation">
          <Lottie options={timeAnimation} height={250} width={250} />
        </div>
        {showTimer && (
          <div className={`starting ${currentCount < 6 ? "lastFvMnt" : ""}`}>
            <div className="backtim">
              <h2>0{minutes}</h2>
            </div>
            :
            <div className="backtim">
              <h2>{seconds < 10 ? 0 + "" + seconds : seconds}</h2>
            </div>
          </div>
        )}
      </Modal.Body>
    </Modal>
  );
}

export default WaitingModal;
