import React, { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import ViratVe from "../assets/images/backup/ViratVe.png";
import Kane from "../assets/images/Kane2.png";
import Bat from "../assets/images/Bat.svg";
import ball from "../assets/images/ball.svg";
import Out from "../assets/images/Out.svg";
import "./SelectPlayer.scss";
import socket from "../socket";

function ScoreBoardModal({
  roomData,
  inning,
  roundInfo,
  currentRound,
  playersSocketId,
  changeBatsman,
  // continueGame,
  changeBat,
  // continueBtn,
}) {
  let currentRoundWicket = !!currentRound ? currentRound.split("_")[1] : 0;
  let playedBalls =
    inning == "First"
      ? roomData?.totalBallsPlayedByPlayerA
      : roomData?.totalBallsPlayedByPlayerB;
  if (playedBalls > 60) {
    playedBalls = 60;
  }
  let overs = parseInt(playedBalls / 6) + "." + (playedBalls % 6);
  return (
    <>
      <Modal
        className="second"
        centered={true}
        show={true}
        // onHide={handleClose}
        // onHide={timerclose}
      >
        <Modal.Body className="Team_Score">
          <div className="scoreBoard">
            <div className="Title">
              <h3>Score Board</h3>
            </div>
            <div className="Cards">
              <div className="Player">
                <div className="Match">
                  <img src={Bat} alt="Bat" className="Bat" /> &nbsp; &nbsp;
                  <h6>
                    {roundInfo?.batInfo?.gameTitle
                      ? roundInfo?.batInfo?.gameTitle
                      : "You"}
                  </h6>
                </div>
                <div className="player_Image">
                  <img
                    src={
                      roundInfo?.batInfo?.outlineImage
                        ? roundInfo?.batInfo?.outlineImage
                        : ViratVe
                    }
                    alt="ViratVe"
                    className="ViratVe"
                  />
                </div>

                {inning == "First" ? (
                  roomData?.totalWicketsPlayerA > 0 &&
                  roundInfo?.WicketOut == 1 ? (
                    <div className="out_Icon">
                      <img src={Out} alt="Out" />
                    </div>
                  ) : (
                    ""
                  )
                ) : roomData?.totalWicketsPlayerB > 0 &&
                  roundInfo?.WicketOut == 1 ? (
                  <div className="out_Icon">
                    <img src={Out} alt="Out" />
                  </div>
                ) : (
                  ""
                )}
              </div>
              <div className="Player_Opponent">
                <div className="Match">
                  <img src={ball} alt="Bat" className="ball" /> &nbsp; &nbsp;
                  <h6>
                    {roundInfo?.bowlerInfo?.gameTitle
                      ? roundInfo?.bowlerInfo?.gameTitle
                      : `Opponent`}
                  </h6>
                </div>

                <div className="player_Image">
                  <img
                    src={
                      roundInfo?.bowlerInfo?.outlineImage
                        ? roundInfo?.bowlerInfo?.outlineImage
                        : Kane
                    }
                    alt="Kane"
                    className="Kane"
                  />
                </div>
              </div>
            </div>
            <div className="scoring">
              <div className="over_score">
                <h5>Over</h5>
                <h6>{!!overs ? overs : 0}</h6>
              </div>
              <div className="over_score">
                <h5>Score</h5>
                {inning == "First" ? (
                  <h6>{`${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA}`}</h6>
                ) : (
                  <h6>{`${roomData?.totalScoreByPlayerB}/${roomData?.totalWicketsPlayerB}`}</h6>
                )}
              </div>
              <div className="over_score">
                <h5>{roundInfo?.batInfo?.gameTitle}</h5>
                <h6>
                  {roundInfo?.score}({roundInfo?.ballsPlayed})
                </h6>
              </div>
            </div>
            {roomData?.currentRound != "round_5" && (
              <div className="playerChange">
                {inning == "First" ? (
                  playersSocketId == socket.id &&
                  roundInfo?.WicketOut == 0 &&
                  roomData?.totalBallsPlayedByPlayerA < 60 ? (
                    !changeBat ? (
                      <button onClick={changeBatsman} className="chngBtn">
                        Change Batsman
                      </button>
                    ) : (
                      <button onClick={changeBatsman} className="chngBtn">
                        Please wait...
                      </button>
                    )
                  ) : (
                    ""
                    // <button className="chngBtn">Change Bowler</button>
                  )
                ) : inning == "Second" &&
                  playersSocketId == socket.id &&
                  roundInfo?.WicketOut == 0 &&
                  roomData?.totalBallsPlayedByPlayerB < 60 &&
                  roomData?.MatchStatus != "COMPLETED" &&
                  !roomData?.isSecondPlayerBot ? (
                  !changeBat ? (
                    <button onClick={changeBatsman} className="chngBtn">
                      Change Batsman
                    </button>
                  ) : (
                    <button onClick={changeBatsman} className="chngBtn">
                      Please wait...
                    </button>
                  )
                ) : (
                  ""
                )}

                {/* {!continueBtn ? (
                  <button onClick={continueGame} className="contBtn">
                    Continue
                  </button>
                ) : (
                  <button className="contBtn">Please wait...</button>
                )} */}
              </div>
            )}
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default ScoreBoardModal;
