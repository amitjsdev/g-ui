import React from "react";
import { Modal } from "react-bootstrap";
import Lottie from "react-lottie";
import "./modal.scss";

function ConfirmModal({
  confirmMatch,
  showConifrm,
  timeAnimation,
  closeModal,
  currentCount,
}) {
  return (
    <Modal className="second" show={showConifrm} centered={true}>
      <Modal.Body className="LookOppo">
        <div className="looking">
          <div className="oppnt">
            <h6 className="textColor">
              Please select confirm button to start game
            </h6>
            <div className="btnDiv">
              <button
                onClick={() => {
                  confirmMatch();
                }}
                className="confmBtn"
              >
                Confirm
              </button>
              <button onClick={closeModal} className="cancelBtn">
                Cancel
              </button>
            </div>
            <div className={`starting ${currentCount < 6 ? "lastFvMnt" : ""}`}>
              <div className="backtim">
                <h2>00</h2>
              </div>
              :
              <div className="backtim">
                <h2>
                  {currentCount < 10 ? 0 + "" + currentCount : currentCount}
                </h2>
              </div>
            </div>
          </div>
        </div>

        {/* <div className="globAnimation">
          <Lottie options={timeAnimation} height={250} width={250} />
        </div> */}
      </Modal.Body>
    </Modal>
  );
}

export default ConfirmModal;
