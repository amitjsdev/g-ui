import React, { useState } from "react";
import { Button, Modal } from "react-bootstrap";
import innings from "../assets/images/innings.png";
import "./innings.scss";

function InningsChangeModal({ roomData, playerType }) {
  return (
    <>
      <Modal
        className="second"
        centered={true}
        show={true}
        // onHide={timerclose}
      >
        <Modal.Body className="Inning_Game">
          <div className="Innings_Changes">
            <div className="headings">
              <h5>1st Innings Over</h5>
            </div>
            <div className="Back_innings">
              <img src={innings} alt="innings" className="innings" />
              <div className="data_Inning">
                <h4>INNINGS CHANGE</h4>
                <p>{`${roomData?.totalScoreByPlayerA}/${roomData?.totalWicketsPlayerA}`}</p>
              </div>
            </div>
            <div className="footer">
              {playerType == "Batsman" ? (
                <h5>Its Your Turn to Bat!</h5>
              ) : (
                <h5>Its Your Turn to Bowl!</h5>
              )}
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default InningsChangeModal;
