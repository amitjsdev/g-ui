import React from 'react'
import { Routes, Route } from "react-router-dom";
import BuildTeam from './pages/BuildTeam/BuildTeam';
import YouWon from './pages/YouWon/YouWon';
import Ground from './pages/Ground/Ground';
import Home from './pages/Home/Home';
import BuildTeamS1 from './pages/BuildTeamS1/BuildTeamS1';
// import Playermatch from './pages/PlayerVsModal/PlayerVsModal';
import Artifacts from './pages/Artifacts/Artifacts';
import YouLost from './pages/YouWon/YouLost';
import MatchTie from './pages/YouWon/MatchTie';
import TimeOut from './pages/YouWon/TimeOut';


import Batsman from './pages/SelectPlayer/Batsman';
import Bowler from './pages/SelectPlayer/Bowler';
import PlayGround from './pages/PlayGround';
import MatchGround from './pages/PlayGround/MatchGround';
import Winner from './pages/YouWon/Winner';
import Loser from './pages/YouWon/Loser';
import Animation from './pages/Animation/Animation';
import Cardinfo from './pages/CardInfo/Cardinfo';

export const Routers = () => {
    return (
        <Routes>
            <Route path={"/"} element={<Home />} />
            <Route path={"/build-team"} element={<BuildTeam />} />
            <Route path={"/team-selected"} element={<BuildTeamS1 />} />
            <Route path={"/ground"} element={<Ground />} />
            <Route path={"/you-won"} element={<YouWon />} />
            {/* <Route path={"/playermatch"} element={<Playermatch />} /> */}
            <Route path={"/artefacts"} element={<Artifacts />} />
            <Route path={"/you-lost"} element={<YouLost />} />
            <Route path={"/match-tie"} element={<MatchTie />} />
            <Route path={"/time-out"} element={<TimeOut />} />
            <Route path={"/batsman"} element={<Batsman />} />
            <Route path={"/bowler"} element={<Bowler />} />
            {/* new flow changes start*/}
            <Route path={"/playground"} element={<PlayGround />} />
            <Route path={"/matchground"} element={<MatchGround />} />
            <Route path={"/winner"} element={<Winner />} />
            <Route path={"/lost"} element={<Loser />} />
            <Route path={"/animation"} element={<Animation />} />
            <Route path={"/cardinfo"} element={<Cardinfo />} />

            {/* new flow changes end*/}

        </Routes>
    )
}
